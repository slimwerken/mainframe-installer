/* Mainframe-installer: de voorkant. Eén startscherm, daarna loopt de installatie
   vanzelf (regie.py op de lokale server). Alleen als de gebruiker iets moet doen
   verschijnt er een kaart met één knop. Praat alleen met de server op deze
   computer, met de sleutel uit het adres na het hekje. */
(function () {
  "use strict";

  const SLEUTEL = (location.hash || "").slice(1);
  const scherm = document.getElementById("scherm");
  const kopRechts = document.getElementById("kopRechts");
  let BEGIN = {};
  let invoerOnthouden = {};
  let peil = null;
  let logVanaf = 0;
  let logTekst = "";
  let laatsteActie = "";
  let laatsteFase = "";
  let laatsteProcent = 0;
  let welkomStem = null;
  let holo = null;          // Jarvis in opbouw (hologram.js); null als 3D niet lukt
  let holoBezig = null;

  const $ = (sel, el) => (el || document).querySelector(sel);
  const $$ = (sel, el) => Array.from((el || document).querySelectorAll(sel));
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  const wacht = (ms) => new Promise((r) => setTimeout(r, ms));
  const VINK = '<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 6.2l2.4 2.4 4.6-5"/></svg>';

  async function api(pad, body) {
    const r = await fetch(pad, {
      method: body === undefined ? "GET" : "POST",
      headers: Object.assign({ "X-Wizard": SLEUTEL }, body === undefined ? {} : { "Content-Type": "application/json" }),
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw Object.assign(new Error(data.fout || "Dat lukte niet."), { data });
    return data;
  }

  // Mapkiezer in de browser zelf (Bart, 11 nov 2026, VIP-installatie op Windows: op Kies een map
  // drukken deed niets en de knop bleef hangen). Geen venster van Windows of macOS nodig. Geeft het
  // gekozen pad terug, of null bij Annuleren.
  function kiesMapInBrowser(titel, start) {
    return new Promise((klaar) => {
      const achter = document.createElement("div");
      achter.className = "mapkiezer-achter";
      document.body.appendChild(achter);
      let huidig = "";
      const sluit = (pad) => { achter.remove(); klaar(pad); };
      const teken = async (pad) => {
        let d;
        try { d = await api("/api/map/bladeren", { pad }); }
        catch (e) { d = { pad, mappen: [], plekken: [], fout: e.message }; }
        // Meteen in de eerste plek (meestal Documenten) beginnen, niet bij een lege lijst.
        if (!pad && !d.pad && (d.plekken || []).length) return teken(d.plekken[0].pad);
        huidig = d.pad || "";
        const plekken = (d.plekken || []).map((p) => `<button type="button" data-pad="${esc(p.pad)}">${esc(p.naam)}</button>`).join("");
        const mappen = (d.mappen || []).map((m) => `<button type="button" data-pad="${esc(m.pad)}">${esc(m.naam)}</button>`).join("");
        achter.innerHTML = `<div class="actie mapkiezer" role="dialog" aria-modal="true">
          <h2>${esc(titel)}</h2>
          <p>${huidig ? "Klik op een map om erin te kijken. Staat je map open? Klik dan op Kies deze map." : "Begin bij een van deze plekken."}</p>
          <div class="plekken">${plekken}</div>
          ${huidig ? `<p class="pad">${esc(huidig)}</p>` : ""}
          <div class="lijst">${d.ouder ? `<button type="button" data-pad="${esc(d.ouder)}">&larr; Terug</button>` : ""}${mappen ||
            (huidig ? `<div class="leeg">${esc(d.fout || "Hier staan geen mappen in. Je kunt deze map gewoon kiezen.")}</div>` : "")}</div>
          <div class="rij">${huidig ? `<button class="knop" type="button" data-kies>Kies deze map</button>` : ""}
            <button class="tekstknop" type="button" data-annuleer>Annuleren</button></div></div>`;
        achter.querySelectorAll("[data-pad]").forEach((b) => b.addEventListener("click", () => teken(b.dataset.pad)));
        const k = achter.querySelector("[data-kies]");
        if (k) k.addEventListener("click", () => sluit(huidig));
        achter.querySelector("[data-annuleer]").addEventListener("click", () => sluit(null));
      };
      teken(start || "");
    });
  }

  // Het gewone mapvenster op de Mac (dat werkt daar goed); op Windows en Linux altijd de kiezer in de browser.
  const browserKiezer = () => BEGIN.systeem !== "mac";

  function toon(html) {
    scherm.innerHTML = `<div class="inhoud">${html}</div>`;
  }

  function groetWoord() {
    const u = new Date().getHours();
    return u < 6 ? "Goedenacht" : u < 12 ? "Goedemorgen" : u < 18 ? "Goedemiddag" : "Goedenavond";
  }

  // ---------------------------------------------------------------- Jarvis in opbouw
  function startHolo() {
    const el = $("#holo");
    if (holo || holoBezig || !el) return;
    el.hidden = false;
    $("#podium").classList.add("met-holo");
    holoBezig = import("/assets/hologram.js")
      .then((m) => m.maakHologram($("#holoPlek"), {
        figuur: m.figuurVoorStem(BEGIN.stem),
        altijd: new URLSearchParams(location.search).get("3d") === "altijd",
        bijTraag: () => { holo = null; verbergHolo(); },
      }))
      .then((h) => { holo = h; if (!h) verbergHolo(); else holo.voortgang(laatsteProcent / 100); })
      .catch(() => verbergHolo());
  }

  function verbergHolo() {
    if (holo) holo.stop();
    holo = null; holoBezig = null;
    const el = $("#holo");
    if (el) { el.hidden = true; el.classList.remove("klein"); }
    $("#podium").classList.remove("met-holo");
  }

  // ---------------------------------------------------------------- startscherm
  function startscherm() {
    clearInterval(peil);
    verbergHolo();
    const al = BEGIN.mainframe_staat;
    let vast = BEGIN.vaste_computer === "ja";
    // Vanzelf starten staat standaard aan (Bart, 14 okt 2026); alleen een eerder nee blijft nee.
    let vanzelf = BEGIN.vanzelf !== "nee";
    kopRechts.textContent = BEGIN.systeem_naam || "";
    toon(`
      <h1>${al ? "Je Mainframe afmaken" : "Mainframe installeren"}</h1>
      <p class="sub">${al ? "Ik kijk wat er nog mist en maak het af." : "Vul dit in. De rest gaat vanzelf."}</p>
      <div class="veld"><label for="voornaam">Je voornaam</label>
        <input class="invoer" id="voornaam" autocomplete="given-name" value="${esc(BEGIN.voornaam)}"></div>
      <div class="veld"><label for="aanspreek">Jarvis praat over je als</label>
        <select class="invoer" id="aanspreek">
          <option value="" ${!BEGIN.aanspreek ? "selected" : ""}>neutraal</option>
          <option value="hij" ${BEGIN.aanspreek === "hij" ? "selected" : ""}>hij</option>
          <option value="zij" ${BEGIN.aanspreek === "zij" ? "selected" : ""}>zij</option>
        </select></div>
      ${al ? "" : `
      <div class="veld"><label for="code">Licentiecode</label>
        <input class="invoer code" id="code" placeholder="MF-XXXX-XXXX" autocomplete="off" spellcheck="false" value="${esc(BEGIN.code)}"></div>
      <div class="veld"><label for="email">E-mailadres van je aankoop</label>
        <input class="invoer" id="email" type="email" autocomplete="email" value="${esc(BEGIN.email)}"></div>
      <div class="adres-vraag" id="adresVraag" hidden></div>
      <div class="oud-blok" id="oudBlok">
        <p id="oudTekst"></p>
        <div class="oud-knoppen">
          <button class="knop licht klein-knop" type="button" id="oudKies"></button>
          <button class="tekst-knop" type="button" id="oudWeg" hidden>Niet meenemen</button>
        </div>
        <button class="schakel" type="button" role="switch" id="meenemen" aria-checked="true" hidden>
          <span><b>Neem alles mee wat ik heb ingericht</b><small>Je skills, CLAUDE.md, kennis, projecten, klanten, scripts, verbindingen, wachtwoorden en automatiseringen. We kopieren alles; je oude map blijft precies zoals hij is.</small></span>
          <span class="knopje" aria-hidden="true"></span>
        </button>
      </div>
      <div class="veld"><label>Waar komt je Mainframe?</label>
        <div class="mapkeuze">
          <div class="map-pad" id="mapPad"></div>
          <button class="knop licht klein-knop" type="button" id="mapKies">Andere plek</button>
        </div>
        <p class="map-noot" id="mapNoot"></p>
        <p class="map-let-op">Niet in een gedeelde of gesynchroniseerde map, zoals OneDrive, iCloud Drive, Dropbox, Google Drive of een netwerkschijf. Kies een map op deze computer zelf.</p>
      </div>`}
      <button class="schakel" type="button" role="switch" id="vast" aria-checked="${vast}">
        <span><b>Deze computer blijft altijd aan</b><small>Dan werkt Jarvis ook als je weg bent.</small></span>
        <span class="knopje" aria-hidden="true"></span>
      </button>
      <button class="schakel" type="button" role="switch" id="vanzelf" aria-checked="${vanzelf}">
        <span><b>Jarvis start vanzelf als je je computer aanzet</b><small>Zet je dit uit, dan start je Jarvis na een herstart zelf met /app in Claude Code.</small></span>
        <span class="knopje" aria-hidden="true"></span>
      </button>
      <button class="uitleg-knop" type="button" id="uitlegKnop">Wat is het verschil?</button>
      <div class="uitleg" id="uitleg" hidden>
        <div><b>Blijft aan</b><ul><li>Jarvis op je telefoon, overal</li><li>Klussen lopen door als je weg bent</li><li>Automatiseringen ook 's nachts</li></ul></div>
        <div><b>Laptop</b><ul><li>Telefoon werkt alleen als de laptop open is</li><li>Een klus stopt bij dichtklappen</li><li>Automatiseringen slaan dan over</li></ul></div>
      </div>
      <button class="knop breed" type="button" id="installeer">${al ? "Afmaken" : "Installeren"}</button>
      <p class="melding-fout" id="startFout"></p>
      <div id="overzicht">${overzicht()}</div>`);
    // Code en adres bekend (nu of zodra ze ingevuld zijn): de lijst hierboven past zich aan.
    const sloten = () => void kijkSloten((($("#code") || {}).value || "").trim(), (($("#email") || {}).value || "").trim());
    ["#code", "#email"].forEach((id) => { const el = $(id); if (el) el.addEventListener("change", sloten); });
    sloten();
    let gekozenMap = (BEGIN.map || {}).map || "";
    // Een oude Mainframe verhuist straks in de kennismaking van de app (Bart, 20 okt 2026).
    let oudeMap = (BEGIN.map || {}).oud || "";
    let meenemen = true;
    const toonOud = () => {
      if (!$("#oudBlok")) return;
      $("#oudTekst").innerHTML = oudeMap
        ? `<b>Je hebt al een Mainframe</b> in ${esc(kortPad(oudeMap))}. Geen probleem. Mainframe 2.0 komt in een nieuwe map ernaast. Je oude map raken we niet aan: we lezen hem alleen en kopieren wat je meeneemt. Gaat er iets mis, dan werkt je oude Mainframe gewoon nog.`
        : `<b>Heb je al een Mainframe?</b> Geen probleem. Wijs hem hier aan, dan nemen we alles wat je hebt ingericht mee naar Mainframe 2.0. Je oude map blijft precies zoals hij is.`;
      $("#oudKies").textContent = oudeMap ? "Een andere oude map" : "Ja, kies mijn Mainframe";
      $("#oudWeg").hidden = !oudeMap;
      $("#meenemen").hidden = !oudeMap;
    };
    toonOud();
    const toonMap = (m) => {
      if (!$("#mapPad")) return;
      gekozenMap = m.map || gekozenMap;
      // Een oude Mainframe gekozen als plek: die wordt de map om mee te nemen, 2.0 komt ernaast.
      if (m.oud) { oudeMap = m.oud; toonOud(); }
      $("#mapPad").textContent = kortPad(gekozenMap);
      $("#mapPad").title = gekozenMap;
      $("#mapNoot").textContent = m.gedeeld ? "" : m.bestaand ? "Hier staat al Mainframe 2.0. Die werken we bij; je eigen bestanden blijven zoals ze zijn." : "";
      $("#startFout").textContent = m.fout || (m.gedeeld ? `Die map staat in ${m.gedeeld}. ${BEGIN.gedeeld_uitleg || ""}` : "");
      $("#installeer").disabled = !!m.gedeeld;
    };
    if (BEGIN.map) toonMap(BEGIN.map);
    const mk = $("#mapKies");
    if (mk) mk.addEventListener("click", async () => {
      mk.disabled = true; mk.textContent = "Kies een map";
      try {
        if (browserKiezer()) {
          const pad = await kiesMapInBrowser("Kies waar je Mainframe komt", "");
          if (pad) toonMap(await api("/api/map/controleer", { map: pad }));
        } else {
          const m = await api("/api/map/kies", {});
          if (m.geannuleerd) {
            // Het venster van de Mac werkte niet: dan de kiezer in de browser.
            const pad = m.geen_venster ? await kiesMapInBrowser("Kies waar je Mainframe komt", "") : null;
            if (pad) toonMap(await api("/api/map/controleer", { map: pad }));
          } else toonMap(m);
        }
      } catch (e) { $("#startFout").textContent = e.message; }
      mk.disabled = false; mk.textContent = "Andere plek";
    });
    const ok = $("#oudKies");
    if (ok) ok.addEventListener("click", async () => {
      ok.disabled = true;
      try {
        let m;
        if (browserKiezer()) {
          const pad = await kiesMapInBrowser("Kies je oude Mainframe", "");
          m = pad ? await api("/api/map/oud", { map: pad }) : {};
        } else {
          m = await api("/api/map/oud", {});
          if (m.geannuleerd && m.geen_venster) {
            const pad = await kiesMapInBrowser("Kies je oude Mainframe", "");
            m = pad ? await api("/api/map/oud", { map: pad }) : {};
          }
        }
        if (m.fout) $("#startFout").textContent = m.fout;
        else if (m.oud) {
          oudeMap = m.oud;
          $("#startFout").textContent = "";
          // Stond de nieuwe map op de oude, dan komt 2.0 op de logische plek ernaast.
          if (!gekozenMap || gekozenMap === m.oud) toonMap({ map: m.doel, bestaand: false });
          toonOud();
        }
      } catch (e) { $("#startFout").textContent = e.message; }
      ok.disabled = false;
    });
    const ow = $("#oudWeg");
    if (ow) ow.addEventListener("click", () => { oudeMap = ""; toonOud(); });
    const mn = $("#meenemen");
    if (mn) mn.addEventListener("click", () => { meenemen = !meenemen; mn.setAttribute("aria-checked", String(meenemen)); });
    const s = $("#vast");
    s.addEventListener("click", () => { vast = !vast; s.setAttribute("aria-checked", String(vast)); });
    const vz = $("#vanzelf");
    vz.addEventListener("click", () => { vanzelf = !vanzelf; vz.setAttribute("aria-checked", String(vanzelf)); });
    $("#uitlegKnop").addEventListener("click", () => { const u = $("#uitleg"); u.hidden = !u.hidden; });
    $("#installeer").addEventListener("click", async () => {
      const invoer = {
        voornaam: $("#voornaam").value.trim(),
        code: ($("#code") || {}).value || "",
        email: ($("#email") || {}).value || "",
        vaste_computer: vast ? "ja" : "nee",
        vanzelf: vanzelf ? "ja" : "nee",
        aanspreek: ($("#aanspreek") || {}).value || "",
        map: al ? "" : gekozenMap,
        oud: al || oudeMap === gekozenMap ? "" : oudeMap,
        meenemen: meenemen ? "ja" : "nee",
      };
      if (!invoer.voornaam) { $("#startFout").textContent = "Vul je voornaam in."; return; }
      await begin(invoer);
    });
    // Code en adres gaan eerst langs de server. Klopt de code maar hoort het adres er niet bij, dan
    // geen fout maar een keuze: Ga door met mijn adres (de server koppelt het aan de code) of Adres
    // aanpassen (Richard, Björn, Johanna, 10 nov 2026: vast op "hoort niet bij deze code").
    async function begin(invoer) {
      $("#installeer").disabled = true;
      $("#startFout").textContent = "";
      try {
        await api("/api/regie/start", { invoer });
        invoerOnthouden = invoer;
        installatiescherm();
      } catch (e) {
        $("#installeer").disabled = false;
        const vraag = e.data && e.data.adres_vraag;
        if (vraag) toonAdresVraag(vraag, invoer);
        else $("#startFout").textContent = e.message;
      }
    }
    function toonAdresVraag(v, invoer) {
      const vak = $("#adresVraag");
      vak.hidden = false;
      vak.innerHTML = `<h3>Dit adres hoort niet bij je code</h3>
        <p>Je code is gekocht met <b>${esc(v.hint || "een ander adres")}</b>. Kocht je werkgever of iemand anders hem voor je, of gebruik je liever een ander adres? Geen probleem.</p>
        <p>Klik op <b>Ga door met mijn adres</b>, dan koppel ik <b>${esc(v.email || invoer.email)}</b> aan je code en installeer ik verder. Je mails van ons blijven gewoon naar je aankoopadres gaan.</p>
        <p>Tikfout gemaakt? Pas je adres hierboven aan en klik opnieuw op Installeren.</p>
        <p class="klein">${esc(v.weet_niet || "")}</p>
        <div class="rij"><button class="knop" type="button" id="adresDoor">Ga door met mijn adres</button>
          <button class="knop licht" type="button" id="adresAnders">Adres aanpassen</button></div>`;
      vak.scrollIntoView({ block: "center", behavior: "smooth" });
      $("#adresDoor").addEventListener("click", async () => {
        $("#adresDoor").disabled = true; $("#adresDoor").textContent = "Even geduld";
        await begin(Object.assign({}, invoer, { ander_adres_ok: true }));
        const knop = $("#adresDoor");
        if (knop) { knop.disabled = false; knop.textContent = "Ga door met mijn adres"; }
      });
      $("#adresAnders").addEventListener("click", () => {
        vak.hidden = true;
        const veld = $("#email"); veld.focus(); veld.select();
      });
    }
    const ev = $("#email");
    if (ev) ev.addEventListener("input", () => { const vak = $("#adresVraag"); if (vak) vak.hidden = true; });
    const eerste = $("input", scherm);
    if (eerste && !eerste.value) eerste.focus();
  }

  function kortPad(p) {
    const thuis = BEGIN.thuis || "";
    return thuis && p.startsWith(thuis) ? "~" + p.slice(thuis.length) : p;
  }

  // Stappen die voor deze licentie niet in beeld horen (Orca tot week 8 bij een cursus vanaf november;
  // Bart, 31 okt 2026). De server zegt het zodra code en adres er staan.
  let verborgenStappen = [];
  let slotenVraag = "";
  async function kijkSloten(code, email) {
    const sleutel = `${code}|${email}`;
    if (sleutel === slotenVraag) return;
    slotenVraag = sleutel;
    try {
      const r = await api("/api/sloten", { code, email });
      if (slotenVraag !== sleutel) return;
      verborgenStappen = Array.isArray(r.verborgen) ? r.verborgen : [];
    } catch (_) {
      verborgenStappen = [];
    }
    const vak = document.getElementById("overzicht");
    if (vak) vak.innerHTML = overzicht();
  }

  // Wat er gaat gebeuren, voor je op Installeren klikt (12 okt 2026), met de principes en de 4 V's (13 okt).
  function overzicht() {
    const st = (BEGIN.stappen || []).filter((s) => !verborgenStappen.includes(s.id));
    if (!st.length) return "";
    const principes = (BEGIN.principes || []).length ? `<section class="overzicht principes">
      <h2>Zo werkt je Mainframe</h2>
      <ul>${BEGIN.principes.map((p) => `<li>${esc(p)}</li>`).join("")}</ul>
      <div class="vier-v">${(BEGIN.vier_v || []).map(([v, w]) => `<div><b>${esc(v)}</b><span>${esc(w)}</span></div>`).join("")}</div>
    </section>` : "";
    const min = Math.round(st.reduce((t, s) => t + (s.seconden || 0), 0) / 60);
    return principes + `<section class="overzicht">
      <h2>Dit gaan we doen</h2>
      <p class="sub">Ongeveer ${Math.max(10, min)} minuten. Alleen als jij iets moet doen, vraag ik het.</p>
      <ol>${st.map((s) => `<li><b>${esc(s.titel)}</b><span>${esc(s.wat)}</span></li>`).join("")}</ol>
    </section>`;
  }

  // ---------------------------------------------------------------- installatiescherm
  function installatiescherm() {
    clearInterval(peil);
    laatsteActie = ""; laatsteFase = ""; logVanaf = 0; logTekst = "";
    toon(`
      <h1 id="titel">Je Mainframe wordt geïnstalleerd</h1>
      <p class="regel" id="regel">Even opstarten</p>
      <p class="wissel" id="wissel"></p>
      <div class="voortgang"><div class="balk"><div class="balk-vul" id="vul"></div></div>
        <div class="balk-tekst"><span id="procent">0%</span><span id="resterend"></span></div></div>
      <div id="kaart"></div>
      <ul class="lijst" id="lijst"></ul>
      <details class="details"><summary>Details</summary><div class="logboek" id="logboek"></div></details>`);
    startHolo();
    ververs();
    peil = setInterval(ververs, 900);
    // Tussendoor de principes en de 4 V's in beeld, rustig wisselend.
    const zinnen = BEGIN.wissel || [];
    let nr = 0;
    clearInterval(window.__wissel);
    const toonWissel = () => { const w = $("#wissel"); if (!w || !zinnen.length) return; w.classList.remove("in"); setTimeout(() => { w.textContent = zinnen[nr++ % zinnen.length]; w.classList.add("in"); }, 250); };
    toonWissel();
    window.__wissel = setInterval(toonWissel, 9000);
  }

  async function ververs() {
    let st;
    try { st = await api("/api/regie?vanaf=" + logVanaf); } catch (_) { return; }
    // voortgang
    $("#vul").style.width = st.procent + "%";
    $("#procent").textContent = st.procent + "%";
    laatsteProcent = st.procent;
    if (holo) holo.voortgang(st.procent / 100);
    $("#holo").classList.toggle("klein", st.fase === "actie" || st.fase === "fout");
    $("#holoLabel").textContent = st.fase === "klaar" ? "Jarvis · klaar" : "Jarvis · in opbouw";
    const min = Math.ceil((st.nog_seconden || 0) / 60);
    $("#resterend").textContent = st.fase === "klaar" ? "" : min > 1 ? `Nog ongeveer ${min} minuten` : "Bijna klaar";
    if (st.fase === "actie") $("#regel").textContent = "Daarna ga ik vanzelf verder.";
    else if (st.regel) $("#regel").textContent = st.regel;
    // stappen
    const stand = { wacht: "", bezig: "Bezig", actie: "Jij bent aan zet", klaar: "Klaar", overgeslagen: "Later", fout: "Niet gelukt" };
    $("#lijst").innerHTML = st.stappen.map((s) =>
      `<li data-s="${esc(s.status)}"><span class="ico">${VINK}</span><span class="naam">${esc(s.titel)}${
        (s.status === "bezig" || s.status === "actie") && s.wat ? `<small class="wat">${esc(s.wat)}</small>` : ""
      }</span><span class="stand">${esc(s.status === "overgeslagen" && s.notitie ? s.notitie : stand[s.status] || "")}</span></li>`).join("");
    // logboek
    if (st.log && st.log.length) {
      logVanaf = st.log_aantal;
      logTekst += st.log.join("\n") + "\n";
      const lb = $("#logboek"); lb.textContent = logTekst; lb.scrollTop = lb.scrollHeight;
    }
    // fase
    if (st.fase === "actie" && st.actie) {
      const sleutelActie = JSON.stringify(st.actie);
      if (sleutelActie !== laatsteActie) { laatsteActie = sleutelActie; tekenActie(st.actie); }
      $("#titel").textContent = "Jij bent even aan zet";
    } else if (st.fase === "fout") {
      if (laatsteFase !== "fout") tekenFout(st.fout || {});
      $("#titel").textContent = "Even een probleem";
    } else if (st.fase === "klaar") {
      clearInterval(peil);
      klaarscherm(st);
    } else {
      if (laatsteActie) { $("#kaart").innerHTML = ""; laatsteActie = ""; }
      if (laatsteFase === "fout") $("#kaart").innerHTML = "";
      $("#titel").textContent = "Je Mainframe wordt geïnstalleerd";
    }
    laatsteFase = st.fase;
  }

  function tekenActie(a) {
    // Een vscode://-link (Laat Claude het oplossen) opent in hetzelfde tabblad, anders blijft er een leeg tabblad staan.
    const eigen = a.knop && /^vscode:/i.test(a.knop.url || "");
    const knop = a.knop && a.knop.url
      ? `<a class="knop${eigen ? " licht" : ""}" href="${esc(a.knop.url)}"${eigen ? "" : ` target="_blank" rel="noopener"`}>${esc(a.knop.tekst)}</a>` : "";
    const knop2 = a.knop2 && a.knop2.url
      ? `<a class="knop" href="${esc(a.knop2.url)}" target="_blank" rel="noopener">${esc(a.knop2.tekst)}</a>` : "";
    const keuzes = (a.keuzes || []).map((k, i) =>
      `<button class="knop ${i ? "licht" : ""}" type="button" data-keuze="${esc(k.id)}">${esc(k.tekst)}</button>`).join("");
    const qrs = (a.qr || []).map((q, i) => `<div class="qr"><div id="qr${i}"></div>${esc(q.tekst)}</div>`).join("");
    const klaarKnop = a.knop_klaar ? `<button class="knop licht" type="button" data-klaar>${esc(a.knop_klaar)}</button>` : "";
    const overslaan = a.overslaan ? `<button class="tekstknop" type="button" data-overslaan>${esc(a.overslaan)}</button>` : "";
    const lang = a.invoer && a.invoer.veld === "geheugen";
    const invoer = !a.invoer ? "" : a.invoer.geheim ? `
      <div class="plak"><input class="invoer" id="plakveld" type="password" autocomplete="current-password" placeholder="${esc(a.invoer.label)}">
        <button class="knop" type="button" data-plak>Koppelen</button></div>` : lang ? `
      <div class="plak lang"><textarea class="invoer" id="plakveld" rows="6" placeholder="${esc(a.invoer.label)}"></textarea>
        <button class="knop" type="button" data-plak>Meenemen</button></div>` : `
      <button class="tekstknop" type="button" data-plakopen>${esc(a.invoer.label)}</button>
      <div class="plak" hidden><input class="invoer" id="plakveld" autocomplete="off" spellcheck="false">
        <button class="knop" type="button" data-plak>Verstuur</button></div>`;
    // Sleutels veilig (25 okt 2026): de hoofdsleutel een keer tonen, met Kopieer en een vinkje.
    const sleutelvak = a.sleutel ? `<div class="sleutelvak"><code id="hoofdsleutel">${esc(a.sleutel)}</code>
      <button class="knop" type="button" data-kopieer>Kopieer</button></div>` : "";
    const vinkje = a.vinkje ? `<label class="vinkje"><input type="checkbox" id="bewaardvink"> <span>${esc(a.vinkje)}</span></label>` : "";
    $("#kaart").innerHTML = `<div class="actie">
      <h2>${esc(a.titel)}</h2><p>${esc(a.tekst)}</p>${sleutelvak}${vinkje}
      ${(a.stappen || []).length ? `<ol class="kaart-stappen">${a.stappen.map((s) => `<li>${esc(s)}</li>`).join("")}</ol>` : ""}
      ${qrs ? `<div class="qrs">${qrs}</div>` : ""}
      <div class="rij">${eigen ? "" : knop}${knop2}${keuzes}${eigen ? knop : ""}${klaarKnop}${overslaan}</div>
      ${invoer}
      ${a.klein ? `<p class="klein">${esc(a.klein)}</p>` : ""}
      ${a.link && a.link.url ? `<p class="klein"><a href="${esc(a.link.url)}" target="_blank" rel="noopener">${esc(a.link.tekst)}</a></p>` : ""}
    </div>`;
    (a.qr || []).forEach((q, i) => tekenQr($("#qr" + i), q.url));
    $$("[data-keuze]").forEach((b) => b.addEventListener("click", () => stuur({ soort: "keuze", waarde: b.dataset.keuze }, b)));
    const k = $("[data-klaar]"); if (k) k.addEventListener("click", () => stuur({ soort: "klaar" }, k));
    const vink = $("#bewaardvink");
    if (vink && k) { k.disabled = true; vink.addEventListener("change", () => { k.disabled = !vink.checked; }); }
    const kop = $("[data-kopieer]");
    if (kop) kop.addEventListener("click", async () => {
      const tekst = $("#hoofdsleutel").textContent;
      try { await navigator.clipboard.writeText(tekst); } catch (_) {
        const r = document.createRange(); r.selectNodeContents($("#hoofdsleutel"));
        const s = getSelection(); s.removeAllRanges(); s.addRange(r); document.execCommand("copy");
      }
      kop.textContent = "Gekopieerd"; setTimeout(() => { kop.textContent = "Kopieer"; }, 1800);
    });
    const o = $("[data-overslaan]"); if (o) o.addEventListener("click", () => stuur({ soort: "overslaan" }, o));
    const po = $("[data-plakopen]");
    if (po) po.addEventListener("click", () => { po.hidden = true; $(".plak").hidden = false; $("#plakveld").focus(); });
    const pl = $("[data-plak]");
    if (pl) pl.addEventListener("click", () => {
      const v = $("#plakveld").value.trim(); if (!v) return;
      stuur({ soort: a.invoer.veld, waarde: v }, pl);
    });
    const kaartKnop = $(".actie .knop"); if (kaartKnop) kaartKnop.focus({ preventScroll: true });
  }

  async function stuur(antwoord, knop) {
    if (knop) { knop.disabled = true; knop.textContent = "Even geduld"; }
    try { await api("/api/regie/antwoord", antwoord); } catch (_) {}
  }

  function tekenFout(f) {
    // f.terug: de invoer zelf klopt niet (verkeerd adres, onbekende code). Dan is Gegevens aanpassen
    // de hoofdknop en gaat Opnieuw proberen (zelfde invoer) ernaast (Geert, 10 nov 2026: hij kon
    // het goede adres nergens meer invullen en moest zijn computer herstarten).
    const terug = !!f.terug;
    $("#kaart").innerHTML = `<div class="foutkaart"><h2>${esc(f.uitleg || "Er ging iets mis.")}</h2>
      <p>${esc(f.wat_nu || "")}</p><div class="rij">${f.adres_hint
        ? `<button class="knop" type="button" id="adresDoor">Ga door met mijn adres</button>` : ""}${terug
        ? `<button class="knop${f.adres_hint ? " licht" : ""}" type="button" id="gegevens">Gegevens aanpassen</button>` : ""}<button class="knop${terug ? " licht" : ""}" type="button" id="opnieuw">Opnieuw proberen</button>${f.hulp_uri
        ? `<a class="knop licht" href="${esc(f.hulp_uri)}">Laat Claude het oplossen</a>` : ""}</div>${f.hulp_uri
        ? `<p class="klein">Claude opent in VS Code met het probleem al ingevuld. Druk daar op Enter.</p>` : ""}</div>`;
    $("#opnieuw").addEventListener("click", async () => {
      $("#opnieuw").disabled = true;
      try { await api("/api/regie/start", { invoer: invoerOnthouden }); } catch (e) { startscherm(); }
    });
    // f.adres_hint: de code klopt, het adres niet. Ga door met mijn adres koppelt het ingevulde adres aan
    // de code en start opnieuw (Richard, 10 nov 2026). Code en adres vult de server aan als ze hier ontbreken.
    const ad = $("#adresDoor");
    if (ad) ad.addEventListener("click", async () => {
      ad.disabled = true; ad.textContent = "Even geduld";
      try {
        await api("/api/regie/start", { invoer: Object.assign({}, invoerOnthouden, { ander_adres_ok: true }) });
      } catch (e) {
        ad.disabled = false; ad.textContent = "Ga door met mijn adres";
        const p = $(".foutkaart p"); if (p) p.textContent = e.message;
      }
    });
    const g = $("#gegevens");
    if (g) g.addEventListener("click", async () => {
      g.disabled = true;
      // Verse stand van de server: de ingevulde (verkeerde) code en het adres staan dan voorgevuld.
      try { BEGIN = await api("/api/begin"); } catch (_) {}
      startscherm();
    });
  }

  function tekenQr(el, tekst) {
    if (!el || !tekst || typeof qrcode !== "function") return;
    const q = qrcode(0, "M"); q.addData(tekst); q.make();
    el.innerHTML = q.createSvgTag({ cellSize: 4, margin: 0, scalable: true });
  }

  // ---------------------------------------------------------------- klaar
  async function klaarscherm(st) {
    if (holo) holo.voortgang(1);
    // De 4 V's per week open (31 okt 2026): een cursus vanaf november begint zonder Jarvis. Dan geen
    // onthulling, maar meteen de app bij Verstand, met de korte kennismaking in een venster.
    if (st.verstand) {
      $("#titel").textContent = "Klaar. Alles staat.";
      $("#regel").textContent = "Je Mainframe staat klaar.";
      $("#resterend").textContent = "";
      $("#kaart").innerHTML = `<div class="rij" style="margin-bottom:26px"><button class="knop breed" type="button" id="naarVerstand" style="margin-top:0">Open je Mainframe</button></div>`
        + `<p class="sub" style="margin-top:0">${st.verhuizen
          ? "Je begint met de verhuizing van je oude Mainframe: je sleutels, je kennis en je skills. Daarna vraagt hij alleen nog wat ontbreekt."
          : "Je begint bij Verstand: je koppelt Apify en je Mainframe leert je kennen."} Elke week van de cursus komt er iets bij.</p>`;
      $("#naarVerstand").addEventListener("click", () => { location.href = st.verstand; });
      return;
    }
    try {
      const r = await fetch("/api/welkom", { headers: { "X-Wizard": SLEUTEL } });
      if (r.ok) welkomStem = new Audio(URL.createObjectURL(await r.blob()));
    } catch (_) { welkomStem = null; }
    $("#titel").textContent = "Klaar. Alles staat.";
    $("#regel").textContent = "Jarvis is er klaar voor.";
    $("#resterend").textContent = "";
    // Onboarding (19 okt 2026): na Ontmoet Jarvis opent de app de kennismaking in een modal:
    // verbindingen, Leer mij kennen, je eerste klus, iets dat vanzelf gaat en Orca.
    let metOnboarding = st.jarvis || "";
    try { if (st.jarvis) { const u = new URL(st.jarvis); u.searchParams.set("onboarding", "1"); metOnboarding = u.href; } } catch (_) { metOnboarding = st.jarvis || ""; }
    $("#kaart").innerHTML = `<div class="rij" style="margin-bottom:26px"><button class="knop breed" type="button" id="ontmoet" style="margin-top:0">Ontmoet Jarvis</button></div>`
      + `<p class="sub" style="margin-top:0">Daarna zet Jarvis je Mainframe samen met je klaar: wat hij nodig heeft, wat hij over je moet weten en je eerste klus. Een kwartiertje.</p>`;
    $("#ontmoet").addEventListener("click", () => onthul(metOnboarding));
  }

  async function onthul(jarvisUrl) {
    if (holo) return onthulMetHolo(jarvisUrl);
    const o = document.getElementById("onthulling");
    document.getElementById("groet").textContent = `${groetWoord()}${BEGIN.voornaam || invoerOnthouden.voornaam ? ", " + (invoerOnthouden.voornaam || BEGIN.voornaam) : ""}.`;
    document.getElementById("groetSub").textContent = "Zo zetten we samen je Mainframe klaar.";
    o.setAttribute("aria-hidden", "false");
    o.dataset.aan = "1";
    await wacht(900);
    o.dataset.fase = "1";
    let duur = 0;
    if (welkomStem) {
      const d = welkomStem.duration;
      duur = isFinite(d) && d > 0 ? d * 1000 : 8000;
      try { const p = welkomStem.play(); if (p && p.catch) p.catch(() => {}); } catch (_) { duur = 0; }
    }
    const eerste = duur ? Math.min(Math.max(3000, duur * 0.55), 6000) : 3000;
    await wacht(eerste);
    o.dataset.fase = "2";
    await wacht(duur ? Math.max(2600, duur - eerste + 900) : 2600);
    o.classList.add("vertrek");
    await wacht(700);
    location.href = jarvisUrl || "about:blank";
  }

  // Jarvis zelf: het opgebouwde hologram komt groot in beeld, doet zijn ogen open
  // en spreekt de begroeting uit, met de mond op het echte geluid.
  async function onthulMetHolo(jarvisUrl) {
    const o = document.getElementById("onthulling");
    holo.geluidKlaarzetten();
    const naam = invoerOnthouden.voornaam || BEGIN.voornaam;
    document.getElementById("groet").textContent = `${groetWoord()}${naam ? ", " + naam : ""}.`;
    document.getElementById("groetSub").textContent = "Zo zetten we samen je Mainframe klaar.";
    o.dataset.holo = "1";
    o.setAttribute("aria-hidden", "false");
    o.dataset.aan = "1";
    await wacht(900);
    holo.verplaats(document.getElementById("holoGroot"));
    o.dataset.fase = "1";
    await wacht(700);
    holo.wakker();
    await wacht(1700);
    if (welkomStem) await holo.praat(welkomStem);
    else await wacht(2500);
    o.dataset.fase = "2";
    await wacht(2800);
    o.classList.add("vertrek");
    await wacht(700);
    location.href = jarvisUrl || "about:blank";
  }

  // ---------------------------------------------------------------- start
  async function start() {
    if (!SLEUTEL) {
      toon(`<h1>Open de installatie opnieuw</h1><p class="sub">Dit adres mist zijn sleutel. Start de installatie opnieuw.</p>`);
      return;
    }
    try {
      BEGIN = await api("/api/begin");
    } catch (_) {
      toon(`<h1>Even geen verbinding</h1><p class="sub">De installatie draait niet meer. Start hem opnieuw en laad deze pagina opnieuw.</p>`);
      return;
    }
    kopRechts.textContent = BEGIN.systeem_naam || "";
    const r = BEGIN.regie || {};
    if (r.fase && r.fase !== "start") installatiescherm(); else startscherm();
  }
  start();
})();
