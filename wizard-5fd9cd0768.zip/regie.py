"""De regie: een installatie die van begin tot eind zelf doorloopt.

Bart, 4 oktober 2026: "een volledige gestroomlijnde installatie met heel weinig
tekst ... zoveel mogelijk zelf fixen, mensen met korte updates op de hoogte
houden, en als je iets van de gebruiker nodig hebt dat duidelijk laten weten,
waarbij de gebruiker zo min mogelijk moet doen."

Dus: de gebruiker vult op het eerste scherm drie dingen in en drukt op
Installeren. Daarna loopt deze regie alle stappen af. Wat al klaar is wordt
overgeslagen. Alleen als er echt iets van de gebruiker nodig is (inloggen,
een klik in een venster van Apple of Microsoft) zet de regie een actiekaart
klaar en wacht hij tot het gebeurd is; meestal ziet hij dat zelf.
"""
from __future__ import annotations

import os
import queue
import re
import subprocess
import threading
import time
import traceback
from pathlib import Path
from typing import Callable, Dict, List, Optional

import kern
import stappen
from kern import Fout, lees_staat, systeem, zet_staat

# Vaste koppelingen van Slim Werken (Bart, 4 oktober 2026). Niet geheim: een
# Microsoft-app zonder secret en een Google-client van het type bureaublad-app.
# Het Google-secret staat alleen in de .env; publiceer.py zet het in het pakket.
MICROSOFT_CLIENT_ID = "b2285ec5-ecc5-4e5e-9d57-89fc3ec656a7"
GOOGLE_CLIENT_ID = "344457737349-hjpa47sa1vlcolg7pq1l63d3fff66ook.apps.googleusercontent.com"
GOOGLE_CLIENT_SECRET = os.environ.get("MAINFRAME_INSTALLER_GOOGLE_CLIENT_SECRET") or "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"

AI_STUDIO = "https://aistudio.google.com/apikey"

# Wat de Microsoft-koppeling mag (gelijk aan OUTLOOK_COMPLEET in de app,
# scripts/account-connections.ts). Bij een bedrijf moet een beheerder hier een keer
# akkoord op geven; daarna logt iedere medewerker gewoon in.
MICROSOFT_RECHTEN = ("User.Read Mail.ReadWrite Mail.Send Calendars.ReadWrite Calendars.Read.Shared "
                     "Contacts.Read Files.ReadWrite.All Tasks.ReadWrite")


def beheerder_akkoord_url(email: str) -> str:
    """Link waarmee een Microsoft 365-beheerder in een keer akkoord geeft voor het hele bedrijf.

    Microsoft kent het bedrijf aan zijn maildomein, dus de link werkt zonder dat wij
    het tenant-id hoeven te weten. Getest op 6 oktober 2026 met qdp.nl."""
    from urllib.parse import urlencode
    domein = email.split("@")[-1].strip().lower() if "@" in email else "organizations"
    scope = "offline_access " + " ".join("https://graph.microsoft.com/" + r for r in MICROSOFT_RECHTEN.split())
    return (f"https://login.microsoftonline.com/{domein}/v2.0/adminconsent?" + urlencode({
        "client_id": MICROSOFT_CLIENT_ID, "scope": scope, "state": "beheerder",
        "redirect_uri": "http://localhost:8081/__operator/connections/callback/outlook"}))
GEMINI_PATROON = re.compile(r"AIza[0-9A-Za-z_\-]{35}")

# Volgorde, naam in beeld en een schatting in seconden (voor de voortgangsbalk).
STAPPEN = [
    ("basis", "Voorbereiden", 60),
    ("claude", "Claude", 60),
    ("orca", "Orca", 60),
    ("mainframe", "Je Mainframe", 15),
    ("app", "De app", 180),
    ("jarvis", "Jarvis' stem", 60),
    ("mail", "Mail en agenda", 60),
    ("telefoon", "Je telefoon", 60),
    ("klaar", "Controle", 45),
]


class Stop(Exception):
    pass


class Regie:
    def __init__(self) -> None:
        self.slot = threading.Lock()
        self.antwoorden: "queue.Queue[dict]" = queue.Queue()
        self.draad: Optional[threading.Thread] = None
        self.logregels: List[str] = []
        self.status: Dict = self._leeg()

    def _leeg(self) -> Dict:
        return {
            "fase": "start", "stap": None, "procent": 0, "regel": "",
            "stappen": [{"id": i, "titel": t, "status": "wacht"} for i, t, _ in STAPPEN],
            "actie": None, "fout": None, "jarvis": None, "nog_seconden": sum(s for _, _, s in STAPPEN),
        }

    # ------------------------------------------------------------ status
    def zet(self, **velden) -> None:
        with self.slot:
            self.status.update(velden)

    def stapstatus(self, stap_id: str, status: str) -> None:
        with self.slot:
            for s in self.status["stappen"]:
                if s["id"] == stap_id:
                    if status == "bezig" and s["status"] not in ("bezig", "actie"):
                        self.stap_begin = time.time()
                    s["status"] = status
            self._reken()

    def _reken(self) -> None:
        totaal = sum(s for _, _, s in STAPPEN)
        gedaan, bezig_deel = 0.0, 0.0
        for (i, _, sec), s in zip(STAPPEN, self.status["stappen"]):
            if s["status"] in ("klaar", "overgeslagen"):
                gedaan += sec
            elif s["status"] in ("bezig", "actie"):
                # Binnen een stap loopt de balk rustig mee met de tijd, tot 90%.
                bezig_deel = sec * min(0.9, (time.time() - getattr(self, "stap_begin", time.time())) / max(sec, 1))
        self.status["procent"] = int(min(99, (gedaan + bezig_deel) * 100 / totaal))
        self.status["nog_seconden"] = int(max(0, totaal - gedaan - bezig_deel))

    def log(self, regel: str) -> None:
        regel = kern.schoon(str(regel))
        if not regel or regel.startswith("§"):
            return
        self.logregels.append(regel[:300])
        self.logregels = self.logregels[-400:]
        # Alleen onze eigen korte Nederlandse zinnen komen in beeld; Engelse uitvoer
        # van installers en techniek blijft in de details.
        if (len(regel) < 80 and re.match(r"^[A-Z][a-z]", regel)
                and re.search(r"(?i)\b(installeren|ophalen|klaarmaken|klaarzetten|bouwen|starten|controleren|staat erop|"
                              r"neergezet|binnen|draait|gekoppeld|aangezet|bewaard|werkt)\b", regel)
                and not re.search(r"[#%=_/\\\[\]()]|http|\.(py|sh|json|zip|exe)\b", regel)):
            self.zet(regel=regel)

    def momentopname(self, vanaf: int = 0) -> Dict:
        with self.slot:
            if self.status.get("fase") in ("bezig", "actie"):
                self._reken()
            uit = dict(self.status)
            uit["stappen"] = [dict(s) for s in self.status["stappen"]]
        uit["log"] = self.logregels[vanaf:]
        uit["log_aantal"] = len(self.logregels)
        return uit

    # ------------------------------------------------------------ vragen aan de gebruiker
    def vraag(self, actie: Dict, klaar_als: Optional[Callable[[], bool]] = None,
              wacht: float = 2.0, maximaal: float = 3600) -> Dict:
        """Zet een actiekaart klaar en wacht tot hij vanzelf klaar is of de gebruiker iets doet."""
        while not self.antwoorden.empty():
            self.antwoorden.get_nowait()
        self.zet(actie=actie, fase="actie")
        self.stapstatus(self.status["stap"], "actie")
        einde = time.time() + maximaal
        try:
            while time.time() < einde:
                if klaar_als and klaar_als():
                    return {"soort": "vanzelf"}
                try:
                    antwoord = self.antwoorden.get(timeout=wacht)
                    return antwoord
                except queue.Empty:
                    continue
            raise Fout("Dit duurde te lang.", "Druk op Opnieuw proberen.")
        finally:
            self.zet(actie=None, fase="bezig")
            self.stapstatus(self.status["stap"], "bezig")

    def antwoord(self, antwoord: Dict) -> None:
        self.antwoorden.put(antwoord)

    # ------------------------------------------------------------ starten
    def start(self, invoer: Dict) -> None:
        if self.draad and self.draad.is_alive():
            return
        naam = str(invoer.get("voornaam", "")).strip()
        code = re.sub(r"\s+", "", str(invoer.get("code", ""))).upper()
        email = str(invoer.get("email", "")).strip().lower()
        if naam:
            zet_staat(voornaam=naam.split()[0].capitalize())
        if invoer.get("vaste_computer") in ("ja", "nee"):
            zet_staat(vaste_computer=invoer["vaste_computer"])
        if code:
            zet_staat(code=code)
        if email:
            zet_staat(email=email)
        # Opnieuw starten = wat eerder "Later" was opnieuw aanbieden.
        zet_staat(mail_later=False, telefoon_later=False)
        self.status = self._leeg()
        self.zet(fase="bezig")
        self.draad = threading.Thread(target=self._loop, daemon=True)
        self.draad.start()

    def _loop(self) -> None:
        for stap_id, titel, _ in STAPPEN:
            self.zet(stap=stap_id, regel="")
            self.stapstatus(stap_id, "bezig")
            try:
                uitkomst = getattr(self, "stap_" + stap_id)()
                self.stapstatus(stap_id, "overgeslagen" if uitkomst == "overgeslagen" else "klaar")
            except Fout as f:
                self.log(f.uitleg)
                self.stapstatus(stap_id, "fout")
                self.zet(fase="fout", fout={"uitleg": f.uitleg, "wat_nu": f.wat_nu or "Druk op Opnieuw proberen."})
                self._bewaar_log()
                return
            except Exception as e:
                for r in traceback.format_exc().splitlines()[-8:]:
                    self.log(r)
                self.stapstatus(stap_id, "fout")
                self.zet(fase="fout", fout={"uitleg": "Er ging iets mis dat ik niet had verwacht.",
                                            "wat_nu": "Druk op Opnieuw proberen. Blijft het misgaan, stuur dan de details naar Bart."})
                self._bewaar_log()
                return
        with self.slot:
            self.status["procent"] = 100
            self.status["nog_seconden"] = 0
        self.zet(fase="klaar", stap=None, regel="")
        self._bewaar_log()

    def _bewaar_log(self) -> None:
        try:
            kern.WERKMAP.mkdir(parents=True, exist_ok=True)
            with open(kern.WERKMAP / "logboek.txt", "a", encoding="utf-8") as f:
                f.write(f"\n== {time.strftime('%Y-%m-%d %H:%M:%S')} installatie fase={self.status['fase']}\n")
                f.writelines(r + "\n" for r in self.logregels)
        except OSError:
            pass

    # ------------------------------------------------------------ de stappen
    def stap_basis(self):
        if stappen.check_basis()["status"] == "klaar":
            return
        self.zet(regel="Je computer klaarmaken")
        if systeem() == "mac" and not stappen._git_ok():
            kern.stil(["xcode-select", "--install"])
            self.vraag({"soort": "wacht", "titel": "Klik op Installeren",
                        "tekst": "Je Mac vraagt om een onderdeel van Apple. Klik in dat venster op Installeren. Ik ga vanzelf verder."},
                       klaar_als=stappen._git_ok, wacht=5, maximaal=3600)
        if systeem() == "windows":
            self.zet(regel="Vraagt Windows om toestemming? Klik op Ja.")
        stappen.doe_basis({}, self.log)

    def stap_claude(self):
        if stappen.check_claude()["status"] == "klaar":
            return
        if not stappen._claude():
            self.zet(regel="Claude installeren")
            stappen.doe_claude({"actie": "alleen_installeren"}, self.log)
        stappen._onboarding_klaar()
        if stappen.claude_ingelogd():
            return
        link: Dict[str, str] = {}
        proces = self._start_claude_login(link)
        try:
            while True:
                antwoord = self.vraag({
                    "soort": "claude", "titel": "Log in bij Claude",
                    "tekst": "Je browser opent Claude. Log in en klik op Authorize.",
                    "knop": {"tekst": "Open Claude", "url": link.get("url", "https://claude.ai/login")},
                    "invoer": {"label": "Zie je een code? Plak hem hier.", "veld": "code"},
                }, klaar_als=lambda: bool(stappen.claude_ingelogd()), wacht=2, maximaal=1800)
                if antwoord.get("soort") == "vanzelf":
                    return
                if antwoord.get("soort") == "code" and proces.poll() is None:
                    code = re.sub(r"\s+", "", str(antwoord.get("waarde", "")))
                    try:
                        proces.stdin.write((code + "\n").encode())  # type: ignore[union-attr]
                        proces.stdin.flush()  # type: ignore[union-attr]
                    except OSError:
                        pass
                    for _ in range(20):
                        time.sleep(1)
                        if stappen.claude_ingelogd():
                            return
                if proces.poll() is not None and not stappen.claude_ingelogd():
                    proces = self._start_claude_login(link)
        finally:
            if proces.poll() is None:
                proces.terminate()

    def _start_claude_login(self, link: Dict[str, str]) -> subprocess.Popen:
        c = stappen._claude()
        vlaggen = getattr(subprocess, "CREATE_NO_WINDOW", 0) if systeem() == "windows" else 0
        proces = subprocess.Popen([c, "auth", "login", "--claudeai"], stdin=subprocess.PIPE,
                                  stdout=subprocess.PIPE, stderr=subprocess.STDOUT, creationflags=vlaggen)

        def lees():
            for ruw in iter(proces.stdout.readline, b""):  # type: ignore[union-attr]
                m = re.search(r"https://\S+oauth/authorize\S+", ruw.decode("utf-8", "replace"))
                if m:
                    link["url"] = m.group(0)
                    with self.slot:
                        if self.status.get("actie") and self.status["actie"].get("soort") == "claude":
                            self.status["actie"]["knop"]["url"] = m.group(0)

        threading.Thread(target=lees, daemon=True).start()
        return proces

    def stap_orca(self):
        if stappen.check_orca()["status"] == "klaar":
            return
        self.zet(regel="Orca downloaden")
        stappen.doe_orca({}, self.log)

    def stap_mainframe(self):
        s = lees_staat()
        if stappen.check_mainframe()["status"] != "klaar":
            self.zet(regel="Je Mainframe ophalen")
            stappen.doe_mainframe({"code": s.get("code", ""), "email": s.get("email", ""),
                                   "map": s.get("map") or str(kern.THUIS / "Mainframe")}, self.log)
        # Vooraf ingevuld "Over jou" (VIP) gaat er stil in; anders vraagt Jarvis het later.
        vulling = lees_staat().get("vulling") or {}
        if vulling.get("wie") and vulling.get("wat") and stappen.check_overjou()["status"] != "klaar":
            stappen.doe_overjou(vulling, self.log)

    def stap_app(self):
        if stappen.check_app()["status"] == "klaar":
            stappen.zet_onderdelen({"jarvis": True, "agenda": True, "inbox": True})
            return
        self.zet(regel="De app met Jarvis installeren")
        stappen.doe_app({}, self.log)

    def stap_jarvis(self):
        if stappen._gemini_sleutel():
            stappen.doe_jarvis({}, self.log)  # naam naar de app
            return
        kern.open_in_browser(AI_STUDIO)
        gevonden: Dict[str, str] = {}

        def uit_klembord() -> bool:
            sleutel = lees_klembord_sleutel()
            if sleutel and sleutel != gevonden.get("afgewezen"):
                gevonden["sleutel"] = sleutel
                return True
            return False

        tekst = "Klik bij Google op Create API key en daarna op Copy. De rest gaat vanzelf."
        while True:
            antwoord = self.vraag({
                "soort": "gemini", "titel": "Geef Jarvis een stem",
                "tekst": tekst,
                "knop": {"tekst": "Open Google", "url": AI_STUDIO},
                "invoer": {"label": "Of plak de sleutel hier.", "veld": "sleutel"},
                "klein": "Kost bij normaal gebruik een paar euro per maand, rechtstreeks bij Google.",
            }, klaar_als=uit_klembord, wacht=1.5, maximaal=3600)
            sleutel = gevonden.get("sleutel") if antwoord.get("soort") == "vanzelf" else str(antwoord.get("waarde", "")).strip()
            if not sleutel:
                continue
            self.zet(regel="Sleutel controleren")
            try:
                stappen.doe_jarvis({"sleutel": sleutel}, self.log)
                return
            except Fout:
                gevonden["afgewezen"] = sleutel
                gevonden.pop("sleutel", None)
                tekst = "Die sleutel werkt niet. Kopieer hem nog een keer bij Google."

    def stap_mail(self):
        if stappen.check_mail()["status"] == "klaar":
            return
        s = lees_staat()
        p = s.get("aanbieder") or stappen.aanbieder(s.get("email", ""))
        if p not in ("outlook", "google"):
            antwoord = self.vraag({"soort": "keuze", "titel": "Waar staat je mail?",
                                   "tekst": "Dan kan Jarvis je agenda en mail lezen.",
                                   "keuzes": [{"id": "outlook", "tekst": "Microsoft"},
                                              {"id": "google", "tekst": "Google"},
                                              {"id": "later", "tekst": "Later"}]})
            p = antwoord.get("waarde")
            if p not in ("outlook", "google"):
                zet_staat(mail_later=True)
                return "overgeslagen"
        zet_staat(aanbieder=p, mail_later=False)
        if p == "outlook":
            stappen.app_post("/__operator/connections/configure", {"provider": "outlook", "clientId": MICROSOFT_CLIENT_ID})
        else:
            stappen.app_post("/__operator/connections/configure", {"provider": "google", "clientId": GOOGLE_CLIENT_ID,
                                                                    "clientSecret": GOOGLE_CLIENT_SECRET})
        stand = stappen.check_mail()
        wie = "Microsoft" if p == "outlook" else "Google"
        antwoord = self.vraag({
            "soort": "mail", "titel": "Koppel je agenda en mail",
            "tekst": f"Log in met je {wie}-account en klik op Accepteren.",
            "knop": {"tekst": f"Log in met {wie}", "url": stand.get("koppel_url", "")},
            "klein": ("Google meldt dat de app niet geverifieerd is. Klik op Geavanceerd en dan op Doorgaan."
                      if p == "google" else "Vraagt Microsoft om een beheerder? Dan geeft je beheerder hieronder een keer "
                      "akkoord voor het hele bedrijf. Daarna klik je gewoon op Log in. Of kies Later."),
            "link": None if p == "google" else {
                "tekst": "Beheerder van je bedrijf? Geef hier een keer akkoord voor iedereen",
                "url": beheerder_akkoord_url(s.get("email", ""))},
            "overslaan": "Later",
        }, klaar_als=lambda: stappen.check_mail()["status"] == "klaar", wacht=3, maximaal=3600)
        if antwoord.get("soort") == "overslaan":
            zet_staat(mail_later=True)
            return "overgeslagen"

    def stap_telefoon(self):
        if stappen.check_telefoon()["status"] in ("klaar", "overgeslagen"):
            return "overgeslagen" if stappen.check_telefoon()["status"] == "overgeslagen" else None
        vast = lees_staat().get("vaste_computer") == "ja"
        antwoord = self.vraag({"soort": "keuze", "titel": "Jarvis ook op je telefoon?",
                               "tekst": "Dan praat je ook onderweg met Jarvis." if vast else
                               "Dat werkt zolang deze laptop aan staat.",
                               "keuzes": [{"id": "ja", "tekst": "Ja, graag"}, {"id": "later", "tekst": "Later"}]})
        if antwoord.get("waarde") != "ja":
            zet_staat(telefoon_later=True)
            return "overgeslagen"
        if not stappen._tailscale():
            self.zet(regel="Tailscale downloaden")
            if systeem() == "mac":
                pkg = kern.download("https://pkgs.tailscale.com/stable/Tailscale-latest-macos.pkg",
                                    kern.WERKMAP / "downloads" / "Tailscale.pkg", self.log, "Tailscale")
                kern.stil(["open", str(pkg)])
                self.vraag({"soort": "wacht", "titel": "Installeer Tailscale",
                            "tekst": "Klik in het venster door tot Installeer. Je Mac vraagt om je wachtwoord."},
                           klaar_als=lambda: bool(stappen._tailscale()), wacht=4)
            elif systeem() == "windows":
                kern.draai(["winget", "install", "--id", "Tailscale.Tailscale", "-e", "--silent",
                            "--accept-package-agreements", "--accept-source-agreements"], self.log, timeout=900)
            else:
                raise Fout("Installeer Tailscale via tailscale.com/download.", "Druk daarna op Opnieuw proberen.")
        if not stappen.tailscale_status().get("ingelogd"):
            if systeem() == "mac":
                kern.stil(["open", "-a", "Tailscale"])
            else:
                t = stappen._tailscale()
                if t:
                    kern.stil([t, "up"], timeout=5)
            self.vraag({"soort": "wacht", "titel": "Log in bij Tailscale",
                        "tekst": "Klik op het Tailscale-icoon bovenin je scherm en log in. Gebruik straks op je telefoon hetzelfde account."
                        if systeem() == "mac" else "Log in bij Tailscale in het venster dat opent.",
                        "overslaan": "Later"},
                       klaar_als=lambda: bool(stappen.tailscale_status().get("ingelogd")), wacht=4)
            if not stappen.tailscale_status().get("ingelogd"):
                zet_staat(telefoon_later=True)
                return "overgeslagen"
        self.zet(regel="Je telefoon klaarzetten")
        uit = stappen.doe_telefoon({"actie": "koppel"}, self.log)
        antwoord = self.vraag({"soort": "qr", "titel": "Scan met je telefoon",
                               "tekst": "Installeer eerst Tailscale op je telefoon en log in met hetzelfde account. Scan daarna de tweede code.",
                               "qr": [{"tekst": "Tailscale", "url": "https://tailscale.com/download"},
                                      {"tekst": "Jarvis", "url": uit.get("koppellink", "")}],
                               "knop_klaar": "Het werkt", "overslaan": "Later"})
        if antwoord.get("soort") == "overslaan":
            zet_staat(telefoon_later=True)
            return "overgeslagen"
        zet_staat(telefoon_klaar=True, telefoon_later=False)

    def stap_klaar(self):
        self.zet(regel="Alles nalopen")
        uit = stappen.doe_klaar({}, self.log)
        self.zet(jarvis=uit.get("jarvis"))


def lees_klembord_sleutel() -> Optional[str]:
    """Kijkt of er een Gemini-sleutel op het klembord staat. Leest niets anders terug."""
    s = systeem()
    if s == "mac":
        cmd = ["pbpaste"]
    elif s == "windows":
        cmd = ["powershell", "-NoProfile", "-Command", "Get-Clipboard"]
    else:
        cmd = ["wl-paste", "--no-newline"] if kern.vind("wl-paste") else ["xclip", "-selection", "clipboard", "-o"]
    code, uit = kern.stil(cmd, timeout=5)
    if code != 0 or not uit:
        return None
    m = GEMINI_PATROON.search(uit[:500])
    return m.group(0) if m else None


REGIE = Regie()
