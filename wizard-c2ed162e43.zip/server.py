#!/usr/bin/env python3
"""De Mainframe-installer: een wizard in je browser die stap voor stap een
schone Mainframe met Jarvis op deze computer zet.

Starten:
    python3 server.py                 # opent de wizard in je browser
    python3 server.py --geen-browser  # alleen het adres printen

De server luistert alleen op 127.0.0.1, met een eenmalige sleutel in het adres.
Niets van buiten deze computer kan erbij. Alleen standaard-Python.
"""
from __future__ import annotations

import argparse
import json
import mimetypes
import re
import os
import secrets
import sys
import threading
import time
import traceback
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HIER = Path(__file__).resolve().parent
sys.path.insert(0, str(HIER))

import kern  # noqa: E402
import regie  # noqa: E402
import stappen  # noqa: E402

VERSIE = "1.0.0"
SLEUTEL = secrets.token_urlsafe(24)
TAKEN: dict = {}
TAKEN_SLOT = threading.Lock()
LAATSTE_CONTACT = [time.time()]
POOL = ThreadPoolExecutor(max_workers=12)


class Taak:
    def __init__(self, stap: str):
        self.id = secrets.token_hex(6)
        self.stap = stap
        self.regels: list = []
        self.klaar = False
        self.ok = False
        self.fout = None
        self.uitkomst: dict = {}
        self.begin = time.time()

    def log(self, regel: str) -> None:
        self.regels.append({"t": round(time.time() - self.begin, 1), "r": kern.schoon(str(regel))[:400]})

    def als_json(self, vanaf: int = 0) -> dict:
        return {"id": self.id, "stap": self.stap, "regels": self.regels[vanaf:], "aantal": len(self.regels),
                "klaar": self.klaar, "ok": self.ok, "fout": self.fout, "uitkomst": self.uitkomst}


def draai_taak(taak: Taak, invoer: dict) -> None:
    stap = stappen.PER_ID[taak.stap]
    try:
        taak.uitkomst = stap["doe"](invoer, taak.log) or {}
        taak.ok = True
    except kern.Fout as f:
        taak.fout = {"uitleg": f.uitleg, "wat_nu": f.wat_nu}
        taak.log(f.uitleg)
    except Exception as e:  # onverwacht: wel netjes melden, details in het logboek
        taak.fout = {"uitleg": "Er ging iets mis dat ik niet had verwacht.",
                     "wat_nu": "Klik opnieuw. Blijft het misgaan, open dan de details."}
        taak.log(f"{type(e).__name__}: {e}")
        for r in traceback.format_exc().splitlines()[-6:]:
            taak.log(r)
    finally:
        taak.klaar = True
        logbestand = kern.WERKMAP / "logboek.txt"
        try:
            kern.WERKMAP.mkdir(parents=True, exist_ok=True)
            with open(logbestand, "a", encoding="utf-8") as f:
                f.write(f"\n== {time.strftime('%Y-%m-%d %H:%M:%S')} {taak.stap} ok={taak.ok}\n")
                f.writelines(r["r"] + "\n" for r in taak.regels)
        except OSError:
            pass


def controleer(stap: dict) -> dict:
    try:
        uit = stap["check"]()
    except Exception as e:
        uit = {"status": "open", "tekst": "Kon dit niet controleren.", "fout": str(e)[:200]}
    return {"id": stap["id"], "titel": stap["titel"], **uit}


def alle_controles(alleen: str = "") -> list:
    lijst = [s for s in stappen.STAPPEN if not alleen or s["id"] == alleen]
    futures = [POOL.submit(controleer, s) for s in lijst]
    uit = []
    for s, f in zip(lijst, futures):
        try:
            uit.append(f.result(timeout=45))
        except Exception:
            uit.append({"id": s["id"], "titel": s["titel"], "status": "open", "tekst": "Controle duurde te lang."})
    return uit


class Handler(BaseHTTPRequestHandler):
    server_version = "Mainframe-installer"

    def log_message(self, *args):  # geen ruis in de terminal
        pass

    # --- hulp -----------------------------------------------------------
    def _json(self, data, status: int = 200) -> None:
        body = json.dumps(data, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _host_ok(self) -> bool:
        host = (self.headers.get("Host") or "").split(":")[0]
        return host in ("127.0.0.1", "localhost")

    def _sleutel_ok(self) -> bool:
        return secrets.compare_digest(self.headers.get("X-Wizard", ""), SLEUTEL)

    def _lees_body(self) -> dict:
        lengte = min(int(self.headers.get("Content-Length") or 0), 200_000)
        try:
            return json.loads(self.rfile.read(lengte).decode() or "{}")
        except ValueError:
            return {}

    def _bestand(self, pad: Path) -> None:
        if not pad.is_file() or HIER not in pad.resolve().parents:
            self.send_error(404)
            return
        data = pad.read_bytes()
        soort = mimetypes.guess_type(str(pad))[0] or "application/octet-stream"
        if pad.suffix == ".woff2":
            soort = "font/woff2"
        self.send_response(200)
        self.send_header("Content-Type", soort + ("; charset=utf-8" if soort.startswith("text/") or soort.endswith("javascript") else ""))
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store" if pad.suffix in (".html", ".js", ".css") else "max-age=86400")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.end_headers()
        self.wfile.write(data)

    # --- GET -------------------------------------------------------------
    def do_GET(self):
        if not self._host_ok():
            self.send_error(403)
            return
        LAATSTE_CONTACT[0] = time.time()
        url = urllib.parse.urlparse(self.path)
        q = urllib.parse.parse_qs(url.query)
        if url.path in ("/", "/index.html"):
            return self._bestand(HIER / "index.html")
        if url.path.startswith("/assets/"):
            return self._bestand((HIER / url.path.lstrip("/")).resolve())
        if not url.path.startswith("/api/"):
            return self.send_error(404)
        if not self._sleutel_ok():
            return self._json({"fout": "geen toegang"}, 403)
        if url.path == "/api/stappen":
            alleen = (q.get("alleen") or [""])[0]
            return self._json({"stappen": alle_controles(alleen), "systeem": kern.systeem(),
                               "systeem_naam": kern.systeem_naam(), "versie": VERSIE,
                               "staat": {k: v for k, v in kern.lees_staat().items()
                                         if k in ("voornaam", "vaste_computer", "map", "code", "email",
                                                  "aanbieder", "jarvis", "overjou", "app_adres")}})
        if url.path == "/api/begin":
            s = kern.lees_staat()
            m = stappen.check_mainframe()
            return self._json({
                "systeem": kern.systeem(), "systeem_naam": kern.systeem_naam(), "versie": VERSIE,
                "voornaam": s.get("voornaam", ""), "code": s.get("code", ""), "email": s.get("email", ""),
                "vaste_computer": s.get("vaste_computer", ""),
                "mainframe_staat": m["status"] == "klaar",
                "regie": regie.REGIE.momentopname(10**9),
            })
        if url.path == "/api/regie":
            return self._json(regie.REGIE.momentopname(int((q.get("vanaf") or ["0"])[0] or 0)))
        if url.path == "/api/taak":
            taak = TAKEN.get((q.get("id") or [""])[0])
            if not taak:
                return self._json({"fout": "onbekend"}, 404)
            return self._json(taak.als_json(int((q.get("vanaf") or ["0"])[0] or 0)))
        if url.path == "/api/stem":
            return self._stem(q)
        if url.path == "/api/welkom":
            if not stappen.WELKOM_WAV.exists():
                return self.send_error(404)
            data = stappen.WELKOM_WAV.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "audio/wav")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(data)
            return
        return self.send_error(404)

    def _stem(self, q) -> None:
        """Stemvoorbeeld van Jarvis, doorgegeven vanuit de app (die heeft de sleutel)."""
        adres = stappen.app_draait()
        stem = (q.get("stem") or ["Kore"])[0]
        karakter = (q.get("karakter") or ["sparring"])[0]
        if not adres or stem not in ("Kore", "Aoede", "Leda", "Charon", "Puck", "Orus"):
            return self.send_error(404)
        try:
            pad = "/__mainframe/voice/voorbeeld?" + urllib.parse.urlencode({"stem": stem, "karakter": karakter})
            with urllib.request.urlopen(adres + pad, timeout=60) as r:
                data = r.read()
                soort = r.headers.get("Content-Type", "audio/wav")
        except Exception:
            return self._json({"fout": "Het voorbeeld lukte niet."}, 502)
        self.send_response(200)
        self.send_header("Content-Type", soort)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    # --- POST ------------------------------------------------------------
    def do_POST(self):
        if not self._host_ok() or not self._sleutel_ok():
            return self._json({"fout": "geen toegang"}, 403)
        LAATSTE_CONTACT[0] = time.time()
        url = urllib.parse.urlparse(self.path)
        body = self._lees_body()
        if url.path == "/api/doe":
            stap = str(body.get("stap", ""))
            if stap not in stappen.PER_ID:
                return self._json({"fout": "onbekende stap"}, 400)
            with TAKEN_SLOT:
                bezig = [t for t in TAKEN.values() if not t.klaar]
                if bezig:
                    return self._json({"taak": bezig[0].id, "al_bezig": True})
                taak = Taak(stap)
                TAKEN[taak.id] = taak
            threading.Thread(target=draai_taak, args=(taak, body.get("invoer") or {}), daemon=True).start()
            return self._json({"taak": taak.id})
        if url.path == "/api/regie/start":
            invoer = dict(body.get("invoer") or {})
            bewaard = kern.lees_staat()
            for veld in ("code", "email", "voornaam", "vaste_computer"):
                if not invoer.get(veld) and bewaard.get(veld):
                    invoer[veld] = bewaard[veld]
            if not stappen.check_mainframe()["status"] == "klaar":
                code = re.sub(r"\s+", "", str(invoer.get("code", ""))).upper()
                if not re.fullmatch(r"MF-[A-Z0-9]{4}-[A-Z0-9]{4}", code):
                    return self._json({"fout": "Die code klopt niet. Hij ziet eruit als MF-ABCD-1234."}, 400)
                if "@" not in str(invoer.get("email", "")):
                    return self._json({"fout": "Vul het e-mailadres van je aankoop in."}, 400)
            regie.REGIE.start(invoer)
            return self._json({"ok": True})
        if url.path == "/api/regie/antwoord":
            regie.REGIE.antwoord({"soort": str(body.get("soort", ""))[:30], "waarde": str(body.get("waarde", ""))[:300]})
            return self._json({"ok": True})
        if url.path == "/api/claude-code":
            return self._json({"ok": stappen.claude_code_invoer(str(body.get("code", ""))[:400])})
        if url.path == "/api/open":
            doel = str(body.get("url", ""))
            if doel.startswith(("https://", "http://127.0.0.1", "http://localhost", "macappstore://")):
                kern.open_in_browser(doel)
                return self._json({"ok": True})
            return self._json({"fout": "ongeldig adres"}, 400)
        if url.path == "/api/afsluiten":
            self._json({"ok": True})
            threading.Timer(1.0, lambda: self.server.shutdown()).start()
            return
        return self._json({"fout": "onbekend"}, 404)


def vrije_poort(voorkeur: int) -> int:
    import socket
    for p in [voorkeur] + list(range(47800, 47900)):
        with socket.socket() as s:
            try:
                s.bind(("127.0.0.1", p))
                return p
            except OSError:
                continue
    return 0


def draaiende_installer() -> str:
    try:
        adres = (kern.WERKMAP / "adres.txt").read_text().strip()
        basis = adres.split("#")[0]
        with urllib.request.urlopen(basis, timeout=2) as r:
            if r.status == 200 and b"Mainframe installeren" in r.read(4000):
                return adres
    except Exception:
        pass
    return ""


def maak_los() -> None:
    """Draai verder als zelfstandig proces. Zo stopt de installer niet als de
    Terminal of de Claude-sessie die hem startte klaar is.

    Altijd een nieuw proces starten (fork plus exec), nooit alleen forken: op een
    Mac crasht een geforkt Python-proces zodra het internet gebruikt (de
    proxy-opvraging van macOS mag niet in een fork-kind). Gemeten 4 oktober 2026
    op een schone Mac: SIGSEGV in SCDynamicStoreCopyProxies na anderhalve minuut.
    """
    import subprocess
    kern.WERKMAP.mkdir(parents=True, exist_ok=True)
    logpad = kern.WERKMAP / "server.log"
    argv = [a for a in sys.argv if a != "--los"]
    log = open(logpad, "ab")
    if kern.systeem() == "windows":
        vlaggen = 0x00000008 | 0x00000200  # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
        pythonw = Path(sys.executable).with_name("pythonw.exe")
        exe = str(pythonw) if pythonw.exists() else sys.executable
        subprocess.Popen([exe] + argv, creationflags=vlaggen, stdout=log, stderr=log,
                         stdin=subprocess.DEVNULL, close_fds=True)
    else:
        subprocess.Popen([sys.executable] + argv, start_new_session=True, stdout=log, stderr=log,
                         stdin=subprocess.DEVNULL, close_fds=True)
    sys.exit(0)


def main() -> int:
    ap = argparse.ArgumentParser(description="De Mainframe-installer")
    ap.add_argument("--poort", type=int, default=47800)
    ap.add_argument("--geen-browser", action="store_true")
    ap.add_argument("--los", action="store_true", help="op de achtergrond verder draaien, los van wie ons startte")
    args = ap.parse_args()
    # Draait er al een installer? Dan die openen in plaats van een tweede starten.
    oud = draaiende_installer()
    if oud:
        (kern.WERKMAP / "adres.txt").write_text(oud)  # vers stempel voor het startscript
        print(f"  De installer draait al: {oud}")
        if not args.geen_browser and not os.environ.get("MAINFRAME_INSTALLER_TEST"):
            kern.open_in_browser(oud)
        return 0
    if args.los:
        maak_los()
    kern.ververs_path()
    kern.WERKMAP.mkdir(parents=True, exist_ok=True)
    poort = vrije_poort(args.poort)
    server = ThreadingHTTPServer(("127.0.0.1", poort), Handler)
    adres = f"http://127.0.0.1:{poort}/#{SLEUTEL}"
    (kern.WERKMAP / "adres.txt").write_text(adres)
    print("")
    print("  De Mainframe-installer draait.")
    print(f"  Opent je browser niet vanzelf? Plak dit adres erin:\n  {adres}")
    print("  Laat dit venster open tot je klaar bent.")
    print("")
    sys.stdout.flush()
    if not args.geen_browser and not os.environ.get("MAINFRAME_INSTALLER_TEST"):
        threading.Timer(0.6, lambda: kern.open_in_browser(adres)).start()

    def bewaker():
        while True:
            time.sleep(60)
            bezig = any(not t.klaar for t in TAKEN.values())
            if not bezig and time.time() - LAATSTE_CONTACT[0] > 6 * 3600:
                server.shutdown()
                return

    threading.Thread(target=bewaker, daemon=True).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    print("  De installer is gestopt.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
