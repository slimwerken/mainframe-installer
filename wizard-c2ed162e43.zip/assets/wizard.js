/* Mainframe-installer: de voorkant. Eén startscherm, daarna loopt de installatie
   vanzelf (regie.py op de lokale server). Alleen als de gebruiker iets moet doen
   verschijnt er een kaart met één knop. Praat alleen met de server op deze
   computer, met de sleutel uit het adres na het hekje. */
(function () {
  "use strict";

  const SLEUTEL = (location.hash || "").slice(1);
  const scherm = document.getElementById("scherm");
  const kopRechts = document.getElementById("kopRechts");
  let BEGIN = {};
  let invoerOnthouden = {};
  let peil = null;
  let logVanaf = 0;
  let logTekst = "";
  let laatsteActie = "";
  let laatsteFase = "";
  let welkomStem = null;

  const $ = (sel, el) => (el || document).querySelector(sel);
  const $$ = (sel, el) => Array.from((el || document).querySelectorAll(sel));
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  const wacht = (ms) => new Promise((r) => setTimeout(r, ms));
  const VINK = '<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 6.2l2.4 2.4 4.6-5"/></svg>';

  async function api(pad, body) {
    const r = await fetch(pad, {
      method: body === undefined ? "GET" : "POST",
      headers: Object.assign({ "X-Wizard": SLEUTEL }, body === undefined ? {} : { "Content-Type": "application/json" }),
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw Object.assign(new Error(data.fout || "Dat lukte niet."), { data });
    return data;
  }

  function toon(html) {
    scherm.innerHTML = `<div class="inhoud">${html}</div>`;
  }

  function groetWoord() {
    const u = new Date().getHours();
    return u < 6 ? "Goedenacht" : u < 12 ? "Goedemorgen" : u < 18 ? "Goedemiddag" : "Goedenavond";
  }

  // ---------------------------------------------------------------- startscherm
  function startscherm() {
    clearInterval(peil);
    const al = BEGIN.mainframe_staat;
    let vast = BEGIN.vaste_computer === "ja";
    kopRechts.textContent = BEGIN.systeem_naam || "";
    toon(`
      <h1>${al ? "Je Mainframe afmaken" : "Mainframe installeren"}</h1>
      <p class="sub">${al ? "Ik kijk wat er nog mist en maak het af." : "Vul dit in. De rest gaat vanzelf."}</p>
      <div class="veld"><label for="voornaam">Je voornaam</label>
        <input class="invoer" id="voornaam" autocomplete="given-name" value="${esc(BEGIN.voornaam)}"></div>
      ${al ? "" : `
      <div class="veld"><label for="code">Licentiecode</label>
        <input class="invoer code" id="code" placeholder="MF-XXXX-XXXX" autocomplete="off" spellcheck="false" value="${esc(BEGIN.code)}"></div>
      <div class="veld"><label for="email">E-mailadres van je aankoop</label>
        <input class="invoer" id="email" type="email" autocomplete="email" value="${esc(BEGIN.email)}"></div>`}
      <button class="schakel" type="button" role="switch" id="vast" aria-checked="${vast}">
        <span><b>Deze computer blijft altijd aan</b><small>Dan werkt Jarvis ook als je weg bent.</small></span>
        <span class="knopje" aria-hidden="true"></span>
      </button>
      <button class="uitleg-knop" type="button" id="uitlegKnop">Wat is het verschil?</button>
      <div class="uitleg" id="uitleg" hidden>
        <div><b>Blijft aan</b><ul><li>Jarvis op je telefoon, overal</li><li>Klussen lopen door als je weg bent</li><li>Automatiseringen ook 's nachts</li></ul></div>
        <div><b>Laptop</b><ul><li>Telefoon werkt alleen als de laptop open is</li><li>Een klus stopt bij dichtklappen</li><li>Automatiseringen slaan dan over</li></ul></div>
      </div>
      <button class="knop breed" type="button" id="installeer">${al ? "Afmaken" : "Installeren"}</button>
      <p class="melding-fout" id="startFout"></p>`);
    const s = $("#vast");
    s.addEventListener("click", () => { vast = !vast; s.setAttribute("aria-checked", String(vast)); });
    $("#uitlegKnop").addEventListener("click", () => { const u = $("#uitleg"); u.hidden = !u.hidden; });
    $("#installeer").addEventListener("click", async () => {
      const invoer = {
        voornaam: $("#voornaam").value.trim(),
        code: ($("#code") || {}).value || "",
        email: ($("#email") || {}).value || "",
        vaste_computer: vast ? "ja" : "nee",
      };
      if (!invoer.voornaam) { $("#startFout").textContent = "Vul je voornaam in."; return; }
      $("#installeer").disabled = true;
      try {
        await api("/api/regie/start", { invoer });
        invoerOnthouden = invoer;
        installatiescherm();
      } catch (e) {
        $("#startFout").textContent = e.message;
        $("#installeer").disabled = false;
      }
    });
    const eerste = $("input", scherm);
    if (eerste && !eerste.value) eerste.focus();
  }

  // ---------------------------------------------------------------- installatiescherm
  function installatiescherm() {
    clearInterval(peil);
    laatsteActie = ""; laatsteFase = ""; logVanaf = 0; logTekst = "";
    toon(`
      <h1 id="titel">Je Mainframe wordt geïnstalleerd</h1>
      <p class="regel" id="regel">Even opstarten</p>
      <div class="voortgang"><div class="balk"><div class="balk-vul" id="vul"></div></div>
        <div class="balk-tekst"><span id="procent">0%</span><span id="resterend"></span></div></div>
      <div id="kaart"></div>
      <ul class="lijst" id="lijst"></ul>
      <details class="details"><summary>Details</summary><div class="logboek" id="logboek"></div></details>`);
    ververs();
    peil = setInterval(ververs, 900);
  }

  async function ververs() {
    let st;
    try { st = await api("/api/regie?vanaf=" + logVanaf); } catch (_) { return; }
    // voortgang
    $("#vul").style.width = st.procent + "%";
    $("#procent").textContent = st.procent + "%";
    const min = Math.ceil((st.nog_seconden || 0) / 60);
    $("#resterend").textContent = st.fase === "klaar" ? "" : min > 1 ? `Nog ongeveer ${min} minuten` : "Bijna klaar";
    if (st.fase === "actie") $("#regel").textContent = "Daarna ga ik vanzelf verder.";
    else if (st.regel) $("#regel").textContent = st.regel;
    // stappen
    const stand = { wacht: "", bezig: "Bezig", actie: "Jij bent aan zet", klaar: "Klaar", overgeslagen: "Later", fout: "Niet gelukt" };
    $("#lijst").innerHTML = st.stappen.map((s) =>
      `<li data-s="${esc(s.status)}"><span class="ico">${VINK}</span><span class="naam">${esc(s.titel)}</span><span class="stand">${stand[s.status] || ""}</span></li>`).join("");
    // logboek
    if (st.log && st.log.length) {
      logVanaf = st.log_aantal;
      logTekst += st.log.join("\n") + "\n";
      const lb = $("#logboek"); lb.textContent = logTekst; lb.scrollTop = lb.scrollHeight;
    }
    // fase
    if (st.fase === "actie" && st.actie) {
      const sleutelActie = JSON.stringify(st.actie);
      if (sleutelActie !== laatsteActie) { laatsteActie = sleutelActie; tekenActie(st.actie); }
      $("#titel").textContent = "Jij bent even aan zet";
    } else if (st.fase === "fout") {
      if (laatsteFase !== "fout") tekenFout(st.fout || {});
      $("#titel").textContent = "Even een probleem";
    } else if (st.fase === "klaar") {
      clearInterval(peil);
      klaarscherm(st);
    } else {
      if (laatsteActie) { $("#kaart").innerHTML = ""; laatsteActie = ""; }
      if (laatsteFase === "fout") $("#kaart").innerHTML = "";
      $("#titel").textContent = "Je Mainframe wordt geïnstalleerd";
    }
    laatsteFase = st.fase;
  }

  function tekenActie(a) {
    const knop = a.knop && a.knop.url
      ? `<a class="knop" href="${esc(a.knop.url)}" target="_blank" rel="noopener">${esc(a.knop.tekst)}</a>` : "";
    const keuzes = (a.keuzes || []).map((k, i) =>
      `<button class="knop ${i ? "licht" : ""}" type="button" data-keuze="${esc(k.id)}">${esc(k.tekst)}</button>`).join("");
    const qrs = (a.qr || []).map((q, i) => `<div class="qr"><div id="qr${i}"></div>${esc(q.tekst)}</div>`).join("");
    const klaarKnop = a.knop_klaar ? `<button class="knop" type="button" data-klaar>${esc(a.knop_klaar)}</button>` : "";
    const overslaan = a.overslaan ? `<button class="tekstknop" type="button" data-overslaan>${esc(a.overslaan)}</button>` : "";
    const invoer = a.invoer ? `
      <button class="tekstknop" type="button" data-plakopen>${esc(a.invoer.label)}</button>
      <div class="plak" hidden><input class="invoer" id="plakveld" autocomplete="off" spellcheck="false">
        <button class="knop" type="button" data-plak>Verstuur</button></div>` : "";
    $("#kaart").innerHTML = `<div class="actie">
      <h2>${esc(a.titel)}</h2><p>${esc(a.tekst)}</p>
      ${qrs ? `<div class="qrs">${qrs}</div>` : ""}
      <div class="rij">${knop}${keuzes}${klaarKnop}${overslaan}</div>
      ${invoer}
      ${a.klein ? `<p class="klein">${esc(a.klein)}</p>` : ""}
    </div>`;
    (a.qr || []).forEach((q, i) => tekenQr($("#qr" + i), q.url));
    $$("[data-keuze]").forEach((b) => b.addEventListener("click", () => stuur({ soort: "keuze", waarde: b.dataset.keuze }, b)));
    const k = $("[data-klaar]"); if (k) k.addEventListener("click", () => stuur({ soort: "klaar" }, k));
    const o = $("[data-overslaan]"); if (o) o.addEventListener("click", () => stuur({ soort: "overslaan" }, o));
    const po = $("[data-plakopen]");
    if (po) po.addEventListener("click", () => { po.hidden = true; $(".plak").hidden = false; $("#plakveld").focus(); });
    const pl = $("[data-plak]");
    if (pl) pl.addEventListener("click", () => {
      const v = $("#plakveld").value.trim(); if (!v) return;
      stuur({ soort: a.invoer.veld, waarde: v }, pl);
    });
    const kaartKnop = $(".actie .knop"); if (kaartKnop) kaartKnop.focus({ preventScroll: true });
  }

  async function stuur(antwoord, knop) {
    if (knop) { knop.disabled = true; knop.textContent = "Even geduld"; }
    try { await api("/api/regie/antwoord", antwoord); } catch (_) {}
  }

  function tekenFout(f) {
    $("#kaart").innerHTML = `<div class="foutkaart"><h2>${esc(f.uitleg || "Er ging iets mis.")}</h2>
      <p>${esc(f.wat_nu || "")}</p><button class="knop" type="button" id="opnieuw">Opnieuw proberen</button></div>`;
    $("#opnieuw").addEventListener("click", async () => {
      $("#opnieuw").disabled = true;
      try { await api("/api/regie/start", { invoer: invoerOnthouden }); } catch (e) { startscherm(); }
    });
  }

  function tekenQr(el, tekst) {
    if (!el || !tekst || typeof qrcode !== "function") return;
    const q = qrcode(0, "M"); q.addData(tekst); q.make();
    el.innerHTML = q.createSvgTag({ cellSize: 4, margin: 0, scalable: true });
  }

  // ---------------------------------------------------------------- klaar
  async function klaarscherm(st) {
    try {
      const r = await fetch("/api/welkom", { headers: { "X-Wizard": SLEUTEL } });
      if (r.ok) welkomStem = new Audio(URL.createObjectURL(await r.blob()));
    } catch (_) { welkomStem = null; }
    $("#titel").textContent = "Klaar. Alles staat.";
    $("#regel").textContent = "Jarvis is er klaar voor.";
    $("#resterend").textContent = "";
    $("#kaart").innerHTML = `<div class="rij" style="margin-bottom:26px"><button class="knop breed" type="button" id="ontmoet" style="margin-top:0">Ontmoet Jarvis</button></div>`;
    $("#ontmoet").addEventListener("click", () => onthul(st.jarvis));
  }

  async function onthul(jarvisUrl) {
    const o = document.getElementById("onthulling");
    document.getElementById("groet").textContent = `${groetWoord()}${BEGIN.voornaam || invoerOnthouden.voornaam ? ", " + (invoerOnthouden.voornaam || BEGIN.voornaam) : ""}.`;
    document.getElementById("groetSub").textContent = "Tik zo op Zeg het maar en vraag wat je wilt.";
    o.setAttribute("aria-hidden", "false");
    o.dataset.aan = "1";
    await wacht(900);
    o.dataset.fase = "1";
    let duur = 0;
    if (welkomStem) {
      const d = welkomStem.duration;
      duur = isFinite(d) && d > 0 ? d * 1000 : 8000;
      try { const p = welkomStem.play(); if (p && p.catch) p.catch(() => {}); } catch (_) { duur = 0; }
    }
    const eerste = duur ? Math.min(Math.max(3000, duur * 0.55), 6000) : 3000;
    await wacht(eerste);
    o.dataset.fase = "2";
    await wacht(duur ? Math.max(2600, duur - eerste + 900) : 2600);
    o.classList.add("vertrek");
    await wacht(700);
    location.href = jarvisUrl || "about:blank";
  }

  // ---------------------------------------------------------------- start
  async function start() {
    if (!SLEUTEL) {
      toon(`<h1>Open de installatie opnieuw</h1><p class="sub">Dit adres mist zijn sleutel. Start de installatie opnieuw.</p>`);
      return;
    }
    try {
      BEGIN = await api("/api/begin");
    } catch (_) {
      toon(`<h1>Even geen verbinding</h1><p class="sub">De installatie draait niet meer. Start hem opnieuw en laad deze pagina opnieuw.</p>`);
      return;
    }
    kopRechts.textContent = BEGIN.systeem_naam || "";
    const r = BEGIN.regie || {};
    if (r.fase && r.fase !== "start") installatiescherm(); else startscherm();
  }
  start();
})();
