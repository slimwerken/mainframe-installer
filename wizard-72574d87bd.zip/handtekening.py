"""Controleert of een download van de licentieserver echt van Slim Werken komt.

Zelfde controle als de updater (overig/scripts/mainframe_update.py in de cursist-motor): sha256
plus een ed25519-handtekening tegen de publieke sleutel hieronder. Zo kan wie de server of de
opslag overneemt geen eigen code op een nieuwe installatie zetten (security-check 20 okt 2026).
Alleen standaard-Python. Houd dit gelijk met de updater; test: tests/handtekening_test.py.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import re

RELEASE_SLEUTEL = "4DDoyXsSG1ejl2jIk/9RddRv8MHZs6JiRhzLaDGBITw="
HANDTEKENING_VOORVOEGSEL = "mainframe-release-v1"

_P = 2**255 - 19
_L = 2**252 + 27742317777372353535851937790883648493
_D = -121665 * pow(121666, _P - 2, _P) % _P
_WORTEL_MIN_1 = pow(2, (_P - 1) // 4, _P)


def _punt_optellen(a: tuple, b: tuple) -> tuple:
    p = _P
    x = (a[1] - a[0]) * (b[1] - b[0]) % p
    y = (a[1] + a[0]) * (b[1] + b[0]) % p
    c = 2 * a[3] * b[3] * _D % p
    d = 2 * a[2] * b[2] % p
    e, f, g, h = y - x, d - c, d + c, y + x
    return (e * f % p, g * h % p, f * g % p, e * h % p)


def _punt_maal(s: int, punt: tuple) -> tuple:
    uit = (0, 1, 1, 0)  # het neutrale punt
    while s > 0:
        if s & 1:
            uit = _punt_optellen(uit, punt)
        punt = _punt_optellen(punt, punt)
        s >>= 1
    return uit


def _punt_gelijk(a: tuple, b: tuple) -> bool:
    return ((a[0] * b[2] - b[0] * a[2]) % _P == 0
            and (a[1] * b[2] - b[1] * a[2]) % _P == 0)


def _x_terug(y: int, teken: int) -> int | None:
    if y >= _P:
        return None
    x2 = (y * y - 1) * pow(_D * y * y + 1, _P - 2, _P) % _P
    if x2 == 0:
        return None if teken else 0
    x = pow(x2, (_P + 3) // 8, _P)
    if (x * x - x2) % _P != 0:
        x = x * _WORTEL_MIN_1 % _P
    if (x * x - x2) % _P != 0:
        return None
    if (x & 1) != teken:
        x = _P - x
    return x


def _punt_uitpakken(s: bytes) -> tuple | None:
    if len(s) != 32:
        return None
    y = int.from_bytes(s, "little")
    teken = y >> 255
    y &= (1 << 255) - 1
    x = _x_terug(y, teken)
    if x is None:
        return None
    return (x, y, 1, x * y % _P)


_G_Y = 4 * pow(5, _P - 2, _P) % _P
_G_X = _x_terug(_G_Y, 0)
_G = (_G_X, _G_Y, 1, _G_X * _G_Y % _P)


def ed25519_klopt(publiek: bytes, bericht: bytes, handtekening: bytes) -> bool:
    """True als `handtekening` een geldige Ed25519-handtekening van `bericht` is."""
    if len(publiek) != 32 or len(handtekening) != 64:
        return False
    a = _punt_uitpakken(publiek)
    if a is None:
        return False
    r_bytes = handtekening[:32]
    r = _punt_uitpakken(r_bytes)
    if r is None:
        return False
    s = int.from_bytes(handtekening[32:], "little")
    if s >= _L:
        return False
    h = int.from_bytes(hashlib.sha512(r_bytes + publiek + bericht).digest(), "little") % _L
    return _punt_gelijk(_punt_maal(s, _G), _punt_optellen(r, _punt_maal(h, a)))


def release_bericht(sha256_hex: str, soort: str, versie: str) -> bytes:
    """Wat er precies ondertekend wordt. Moet byte voor byte gelijk zijn aan
    release_handtekening.py: voorvoegsel, hash, soort (motor/app) en versie. De versie
    zit erin zodat een oude, ook echt ondertekende release niet als nieuwe kan gelden."""
    return f"{HANDTEKENING_VOORVOEGSEL}:{sha256_hex}:{soort}:{versie}".encode("ascii")


def controleer_release(data: bytes, antwoord: dict, soort: str, versie: str) -> str | None:
    """None als de download van Slim Werken komt, anders de reden in gewone woorden.

    `soort` is "motor" of "app"; de server stuurt dan <soort>_sha256 en
    <soort>_handtekening mee. Zonder RELEASE_SLEUTEL (de overgang) wordt niets
    gecontroleerd, zodat leden niet vastlopen voordat alle releases ondertekend zijn.
    """
    if not RELEASE_SLEUTEL:
        return None
    verwacht = antwoord.get(f"{soort}_sha256")
    handtekening = antwoord.get(f"{soort}_handtekening")
    if not isinstance(verwacht, str) or not isinstance(handtekening, str) or not verwacht or not handtekening:
        return "de server stuurde geen handtekening mee, dus ik kan niet nagaan of dit van Slim Werken komt."
    if not isinstance(versie, str) or not re.fullmatch(r"[0-9A-Za-z.+-]{1,40}", versie):
        return "het versienummer van de server is onleesbaar."
    werkelijk = hashlib.sha256(data).hexdigest()
    if not hmac.compare_digest(werkelijk, verwacht.strip().lower()):
        return "de download is anders dan wat de server aankondigde (de controlegetallen kloppen niet)."
    try:
        publiek = base64.b64decode(RELEASE_SLEUTEL, validate=True)
        sig = base64.b64decode(handtekening.strip(), validate=True)
    except (ValueError, TypeError):
        return "de handtekening is onleesbaar."
    if not ed25519_klopt(publiek, release_bericht(werkelijk, soort, versie), sig):
        return "de handtekening klopt niet, dus dit komt niet aantoonbaar van Slim Werken."
    return None
