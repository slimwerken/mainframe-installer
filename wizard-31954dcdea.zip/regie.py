"""De regie: een installatie die van begin tot eind zelf doorloopt.

Bart, 4 oktober 2026: "een volledige gestroomlijnde installatie met heel weinig
tekst ... zoveel mogelijk zelf fixen, mensen met korte updates op de hoogte
houden, en als je iets van de gebruiker nodig hebt dat duidelijk laten weten,
waarbij de gebruiker zo min mogelijk moet doen."

Dus: de gebruiker vult op het eerste scherm drie dingen in en drukt op
Installeren. Daarna loopt deze regie alle stappen af. Wat al klaar is wordt
overgeslagen. Alleen als er echt iets van de gebruiker nodig is (inloggen,
een klik in een venster van Apple of Microsoft) zet de regie een actiekaart
klaar en wacht hij tot het gebeurd is; meestal ziet hij dat zelf.
"""
from __future__ import annotations

import os
import queue
import re
import subprocess
import threading
import time
import traceback
from pathlib import Path
from typing import Callable, Dict, List, Optional

import kern
import ophalen
import stappen
from kern import Fout, lees_staat, systeem, zet_staat

# Vaste koppelingen van Slim Werken (Bart, 4 oktober 2026). Niet geheim: een
# Microsoft-app zonder secret en een Google-client van het type bureaublad-app.
# Het Google-secret van een bureaublad-app is volgens Google niet geheim (het zit altijd in de
# app zelf); publiceer.py zet het in het openbare pakket, zodat het niet in git staat.
MICROSOFT_CLIENT_ID = "b2285ec5-ecc5-4e5e-9d57-89fc3ec656a7"
GOOGLE_CLIENT_ID = "344457737349-hjpa47sa1vlcolg7pq1l63d3fff66ook.apps.googleusercontent.com"
GOOGLE_CLIENT_SECRET = os.environ.get("MAINFRAME_INSTALLER_GOOGLE_CLIENT_SECRET") or "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"

AI_STUDIO = "https://aistudio.google.com/apikey"
# Hier staat per project de knop Set up billing (gezien 11 okt 2026).
AI_STUDIO_SLEUTELS = "https://aistudio.google.com/api-keys"
AI_STUDIO_PLAFOND = "https://aistudio.google.com/spend"
# Kosten van de stem, uit de prijslijst van Google (ai.google.dev/gemini-api/docs/pricing, 23 okt 2026,
# gemini-3.1-flash-live-preview): 0,005 dollar per minuut geluid erin, 0,018 per minuut geluid eruit.
# Melding Ton (23 okt 2026): 13,91 euro in twee dagen. Geen "een paar euro per maand" meer beloven.
KOSTEN_STEM = ("Let op: je betaalt Google per minuut dat Jarvis luistert en praat. Volgens de prijslijst van "
               "Google is dat een halve dollarcent per minuut dat jij praat en bijna 2 dollarcent per minuut "
               "dat Jarvis praat, en bij elke vraag telt het gesprek tot dan toe opnieuw mee.")
# De stem heet nergens meer Gratis (Bart, 23 okt 2026): de sleutel is gratis, het praten niet. Dezelfde
# zin staat in de app (src/lib/stem-kosten.ts, SLEUTEL_GRATIS).
SLEUTEL_GRATIS = "De sleutel van Google is gratis. Google rekent wel per minuut dat je met Jarvis praat."
PLAFOND_TIP = ("Zet zelf een plafond: in AI Studio bij Spend, Monthly spend cap, Edit spend cap. Google stopt "
               "dan bij dat bedrag per maand, al kan de teller tot zo'n tien minuten achterlopen. Een budget "
               "met meldingen in Google Cloud (Billing, Budgets & alerts) stuurt alleen een mail en stopt niets.")

# Wat de Microsoft-koppeling mag (gelijk aan OUTLOOK_COMPLEET in de app,
# scripts/account-connections.ts). Bij een bedrijf moet een beheerder hier een keer
# akkoord op geven; daarna logt iedere medewerker gewoon in.
MICROSOFT_RECHTEN = ("User.Read Mail.ReadWrite Mail.Send Calendars.ReadWrite Calendars.Read.Shared "
                     "Contacts.Read Files.ReadWrite.All Tasks.ReadWrite")


def beheerder_akkoord_url(email: str) -> str:
    """Link waarmee een Microsoft 365-beheerder in een keer akkoord geeft voor het hele bedrijf.

    Microsoft kent het bedrijf aan zijn maildomein, dus de link werkt zonder dat wij
    het tenant-id hoeven te weten. Getest op 6 oktober 2026 met een klantdomein."""
    from urllib.parse import urlencode
    domein = email.split("@")[-1].strip().lower() if "@" in email else "organizations"
    scope = "offline_access " + " ".join("https://graph.microsoft.com/" + r for r in MICROSOFT_RECHTEN.split())
    return (f"https://login.microsoftonline.com/{domein}/v2.0/adminconsent?" + urlencode({
        "client_id": MICROSOFT_CLIENT_ID, "scope": scope, "state": "beheerder",
        "redirect_uri": "http://localhost:8081/__operator/connections/callback/outlook"}))
GEMINI_PATROON = re.compile(r"AQ\.[0-9A-Za-z_.\-]{20,200}|AIza[0-9A-Za-z_\-]{35}")

# Volgorde, naam in beeld en een schatting in seconden (voor de voortgangsbalk).
STAPPEN = [
    ("basis", "Voorbereiden", 60),
    ("claude", "Claude", 60),
    ("orca", "Orca", 60),
    ("vscode", "VS Code", 60),
    ("mainframe", "Je Mainframe", 15),
    ("app", "De app", 180),
    ("jarvis", "Jarvis' stem", 60),
    ("mail", "Mail en agenda", 60),
    ("telefoon", "Je telefoon", 60),
    ("sleutels", "Sleutels veilig", 45),
    ("klaar", "Controle", 45),
]

# Nooit meer vastlopen (Bart, 11 nov 2026, VIP-installatie op Windows: "Ik wil dat het echt onmogelijk
# is dat de installer op een gegeven moment hapert, dus dat de mensen niet meer weten hoe ze verder
# moeten"). Zonder deze stappen werkt de rest niet; elke andere stap mag je overslaan en later opnieuw
# doen met /wizard, ook als hij fout gaat of blijft hangen.
VERPLICHT = {"basis", "claude", "vscode", "mainframe"}
# Hoe lang een stap zelf mag werken (seconden) voor we vragen wat je wilt. Wachten op jou telt niet mee.
LIMIET = {"basis": 1200, "claude": 900, "orca": 600, "vscode": 600, "mainframe": 600, "app": 1200,
          "jarvis": 300, "mail": 300, "telefoon": 300, "sleutels": 300, "klaar": 600}
# Wat "Later" betekent voor de stappen die dat zelf al kennen.
HULP_KLEIN = "Laat Claude het oplossen opent Claude in VS Code met het probleem al ingevuld. Druk daar op Enter."
LATER_VLAG = {"mail": "mail_later", "telefoon": "telefoon_later", "sleutels": "sleutels_later"}


class HulpKlaar(Exception):
    """Claude in VS Code heeft het opgelost: de stap gaat opnieuw."""


class TeLang(Exception):
    """Een stap bleef hangen en de gebruiker koos om verder te gaan of opnieuw te beginnen."""


def _verlaten() -> bool:
    """True in de draad van een stap die bleef hangen en die we hebben losgelaten."""
    return bool(getattr(threading.current_thread(), "mf_verlaten", False))


# Stappen die bij een dicht onderdeel helemaal uit de lijst gaan, in plaats van "Komt in week X" (Bart,
# 31 okt 2026: "Orca pas vrijgeven vanaf week 8, mag niet zichtbaar zijn tot die tijd").
ONZICHTBAAR_TOT_OPEN = ("orca",)


def verborgen_stappen(sloten: Optional[Dict]) -> List[str]:
    """De stappen die nergens in beeld mogen: hun onderdeel is dicht en blijft tot dan onzichtbaar."""
    return [stap for stap, slot in stappen.SLOT_VAN_STAP.items()
            if slot in ONZICHTBAAR_TOT_OPEN and stappen.slot_dicht(sloten, slot)]


# De laatst opgehaalde status per code en adres. Het startscherm vraagt hem al op zodra code en adres
# er staan; dan kan de lijst bij Installeren meteen zonder Orca beginnen, zonder op Convex te wachten.
_SLOTEN_GEZIEN: Dict[tuple, Optional[Dict]] = {}


def _sleutel(code: str, email: str) -> tuple:
    return (re.sub(r"\s+", "", str(code or "")).upper(), str(email or "").strip().lower())


def sloten_voor(code: str, email: str, log: Optional[Callable[[str], None]] = None, vers: bool = False) -> Optional[Dict]:
    """De status voor deze code en dit adres; uit het geheugen tenzij vers. None = alles zoals altijd."""
    sleutel = _sleutel(code, email)
    if not vers and sleutel in _SLOTEN_GEZIEN:
        return _SLOTEN_GEZIEN[sleutel]
    sloten = stappen.haal_v_sloten(sleutel[0], sleutel[1], log)
    _SLOTEN_GEZIEN[sleutel] = sloten
    return sloten


# Wat elke stap is, in gewone taal (Bart, 12 okt 2026: "mensen meenemen in het stappenplan, wat
# gebeurt er, wat gaan ze installeren"). Staat op het startscherm en onder de stap die loopt.
UITLEG = {
    "basis": "Hulpprogramma's die de rest nodig heeft. Git bewaart elke versie van je werk, zodat je altijd terug kunt. uv en Bun laten de app en de scripts draaien. Op een Mac vraagt Apple één keer om Installeren.",
    "claude": "Claude Code: de AI die het echte werk doet, in jouw map en met jouw kennis. Het hart van je Mainframe. Je logt in met je eigen Claude-account.",
    "orca": "Orca: hier zie je elke klus die Claude of Jarvis voor je doet als eigen tabblad, ook als jij even weg bent. Hij draait op de achtergrond.",
    "vscode": "VS Code, met Claude erin: hier werk je tijdens de lessen en zie je al je bestanden. Je Mainframe is gewoon een map met tekstbestanden die je zelf kunt lezen en aanpassen.",
    "mainframe": "Je Mainframe-map, op de plek die je koos: alles op één plek op je eigen computer. Hier woont Verstand (wat je AI over jou weet) en Vaardigheden (je skills: vaste werkwijzen). Staat er al een Mainframe, dan komt alleen erbij wat ontbreekt.",
    "app": "Mainframe OS met Jarvis: je dashboard met de 4 V's. Verbindingen, Verstand, Vaardigheden en Vanzelf zie je hier in één oogopslag, en je zet ze zelf aan of uit. De eerste keer bouwen duurt een paar minuten.",
    "jarvis": "Een eigen sleutel bij Google, zodat je gewoon tegen je Mainframe kunt praten en Jarvis kan nadenken. Je betaalt Google zelf, per minuut dat Jarvis luistert en praat.",
    "mail": "Verbindingen: Jarvis mag je mail en agenda lezen, van Microsoft of Google, zodat hij weet wat er speelt. Jij beslist of hij ook zelf mails mag versturen. Kan ook later.",
    "telefoon": "Jarvis ook op je telefoon, via een veilige verbinding met deze computer. Kan ook later.",
    "sleutels": "Je Mainframe gebruikt sleutels om namens jou bij je mail, agenda en andere programma's te mogen. We maken ze onleesbaar voor iedereen zonder jouw hoofdsleutel. Die hoofdsleutel bewaar jij, bijvoorbeeld in je wachtwoordmanager.",
    "klaar": "We kijken of alles werkt. Daarna ontmoet je Jarvis en zet hij je Mainframe samen met je klaar. VS Code met je Mainframe staat erachter klaar.",
}

# Op het startscherm en tussendoor in beeld (Bart, 13 okt 2026: "mensen meenemen in wat er wordt
# geïnstalleerd en waarom, met al onze principes ... en laat de 4 V's voorbij komen").
PRINCIPES = [
    "Alles staat in één map op je eigen computer. Van jou, niet van een platform.",
    "Je AI kent jou: je bedrijf, je klanten en je manier van werken.",
    "Jij beslist: er gaat niets naar buiten zonder jouw ja.",
    "Elke klus die je vaker doet, wordt een skill. Zo groeit je Mainframe mee.",
]
VIER_V = [
    ("Verbindingen", "bij al je tools"),
    ("Verstand", "het kent jou"),
    ("Vaardigheden", "doet het echte werk"),
    ("Vanzelf", "draait uit zichzelf"),
]
WISSEL = PRINCIPES + [f"{v}: {w}." for v, w in VIER_V] + [
    "Git bewaart elke versie van je werk. Ging er iets mis, dan kun je altijd terug.",
    "Jarvis is de stem; Claude doet erachter het werk, in jouw map.",
    "Je map is gewoon tekst. Je kunt alles zelf lezen in VS Code.",
]


class Stop(Exception):
    pass


class Regie:
    def __init__(self) -> None:
        self.slot = threading.Lock()
        self.antwoorden: "queue.Queue[dict]" = queue.Queue()
        # Stappen waar Claude het al een keer vanzelf probeerde op te lossen (hooguit een keer per stap).
        self.claude_geprobeerd: set = set()
        self.draad: Optional[threading.Thread] = None
        self.logregels: List[str] = []
        # De 4 V's per week open (31 okt 2026): de status uit Convex, of None (dan alles zoals altijd).
        self.sloten: Optional[Dict] = None
        # Stappen die voor deze licentie helemaal uit beeld blijven (Orca tot week 8).
        self.verborgen: List[str] = []
        self.status: Dict = self._leeg()

    def _leeg(self) -> Dict:
        return {
            "fase": "start", "stap": None, "procent": 0, "regel": "",
            "stappen": [{"id": i, "titel": t, "status": "wacht", "wat": UITLEG.get(i, "")} for i, t, _ in STAPPEN],
            "actie": None, "fout": None, "jarvis": None, "verstand": None, "verhuizen": False,
            "nog_seconden": sum(s for _, _, s in STAPPEN),
        }

    # ------------------------------------------------------------ status
    def zet(self, **velden) -> None:
        if _verlaten():
            return
        with self.slot:
            self.status.update(velden)

    def stapstatus(self, stap_id: str, status: str, notitie: Optional[str] = None) -> None:
        if _verlaten():
            return
        with self.slot:
            for s in self.status["stappen"]:
                if s["id"] == stap_id:
                    if notitie:
                        s["notitie"] = notitie
                    if status == "bezig" and s["status"] not in ("bezig", "actie"):
                        self.stap_begin = time.time()
                    s["status"] = status
            self._reken()

    def _reken(self) -> None:
        # Per id, want een verborgen stap staat niet in de lijst.
        seconden = {i: sec for i, _, sec in STAPPEN}
        totaal = sum(seconden.get(s["id"], 0) for s in self.status["stappen"]) or 1
        gedaan, bezig_deel = 0.0, 0.0
        for s in self.status["stappen"]:
            sec = seconden.get(s["id"], 0)
            if s["status"] in ("klaar", "overgeslagen"):
                gedaan += sec
            elif s["status"] in ("bezig", "actie"):
                # Binnen een stap loopt de balk rustig mee met de tijd, tot 90%.
                bezig_deel = sec * min(0.9, (time.time() - getattr(self, "stap_begin", time.time())) / max(sec, 1))
        self.status["procent"] = int(min(99, (gedaan + bezig_deel) * 100 / totaal))
        self.status["nog_seconden"] = int(max(0, totaal - gedaan - bezig_deel))

    def log(self, regel: str) -> None:
        regel = kern.schoon(str(regel))
        if not regel or regel.startswith("§"):
            return
        self.logregels.append(regel[:300])
        self.logregels = self.logregels[-400:]
        # Alleen onze eigen korte Nederlandse zinnen komen in beeld; Engelse uitvoer
        # van installers en techniek blijft in de details.
        if (len(regel) < 80 and re.match(r"^[A-Z][a-z]", regel)
                and re.search(r"(?i)\b(installeren|ophalen|klaarmaken|klaarzetten|bouwen|starten|controleren|staat erop|"
                              r"neergezet|binnen|draait|gekoppeld|aangezet|bewaard|werkt)\b", regel)
                and not re.search(r"[#%=_/\\\[\]()]|http|\.(py|sh|json|zip|exe)\b", regel)):
            self.zet(regel=regel)

    def momentopname(self, vanaf: int = 0) -> Dict:
        with self.slot:
            if self.status.get("fase") in ("bezig", "actie"):
                self._reken()
            uit = dict(self.status)
            uit["stappen"] = [dict(s) for s in self.status["stappen"]]
        uit["log"] = self.logregels[vanaf:]
        uit["log_aantal"] = len(self.logregels)
        return uit

    # ------------------------------------------------------------ vragen aan de gebruiker
    def vraag(self, actie: Dict, klaar_als: Optional[Callable[[], bool]] = None,
              wacht: float = 2.0, maximaal: float = 3600) -> Dict:
        """Zet een actiekaart klaar en wacht tot hij vanzelf klaar is of de gebruiker iets doet."""
        if _verlaten():
            # Deze stap is losgelaten omdat hij bleef hangen: hij mag geen kaart meer tonen.
            raise TeLang("losgelaten")
        while not self.antwoorden.empty():
            self.antwoorden.get_nowait()
        self.zet(actie=actie, fase="actie")
        self.stapstatus(self.status["stap"], "actie")
        einde = time.time() + maximaal
        try:
            while time.time() < einde:
                if klaar_als and klaar_als():
                    return {"soort": "vanzelf"}
                try:
                    antwoord = self.antwoorden.get(timeout=wacht)
                    return antwoord
                except queue.Empty:
                    continue
            raise Fout("Dit duurde te lang.", "Druk op Opnieuw proberen.")
        finally:
            self.zet(actie=None, fase="bezig")
            self.stapstatus(self.status["stap"], "bezig")

    def antwoord(self, antwoord: Dict) -> None:
        self.antwoorden.put(antwoord)

    # ------------------------------------------------------------ starten
    def start(self, invoer: Dict) -> None:
        if self.draad and self.draad.is_alive():
            return
        naam = str(invoer.get("voornaam", "")).strip()
        code = re.sub(r"\s+", "", str(invoer.get("code", ""))).upper()
        email = str(invoer.get("email", "")).strip().lower()
        if naam:
            zet_staat(voornaam=naam.split()[0].capitalize())
        if invoer.get("vaste_computer") in ("ja", "nee"):
            zet_staat(vaste_computer=invoer["vaste_computer"])
        if invoer.get("vanzelf") in ("ja", "nee"):
            zet_staat(vanzelf=invoer["vanzelf"])
        if invoer.get("aanspreek") in ("", "hij", "zij"):
            zet_staat(aanspreek=invoer["aanspreek"])
        if code:
            zet_staat(code=code)
        if email:
            zet_staat(email=email)
        if invoer.get("map"):
            zet_staat(map=str(invoer["map"]), map_gekozen=True)
        if "oud" in invoer:
            # De oude Mainframe verhuist straks in de kennismaking van de app (Bart, 20 okt 2026).
            zet_staat(oude_map=str(invoer.get("oud") or ""))
        if invoer.get("meenemen") in ("ja", "nee"):
            # Het vinkje "neem alles mee" (Bart, 21 okt 2026): dan start de import vanzelf in de app.
            zet_staat(meenemen=invoer["meenemen"])
        if invoer.get("ophalen") in ("ja", "nee"):
            # "Haal mijn Mainframe op" (Bart, 11 nov 2026): een tweede computer met hetzelfde Mainframe.
            # Dan is er geen oude map om te verhuizen.
            zet_staat(ophalen=invoer["ophalen"] == "ja")
            if invoer["ophalen"] == "ja":
                zet_staat(oude_map="", meenemen="nee")
        # Opnieuw starten = wat eerder "Later" was opnieuw aanbieden.
        zet_staat(mail_later=False, telefoon_later=False, sleutels_later=False)
        self.status = self._leeg()
        # Al bekend van het startscherm: die stappen staan er vanaf de eerste seconde niet in.
        self.verborgen = verborgen_stappen(_SLOTEN_GEZIEN.get(_sleutel(
            code or lees_staat().get("code", ""), email or lees_staat().get("email", ""))))
        self.status["stappen"] = [st for st in self.status["stappen"] if st["id"] not in self.verborgen]
        self.zet(fase="bezig")
        self.draad = threading.Thread(target=self._loop, daemon=True)
        self.draad.start()

    def _loop(self) -> None:
        self.sloten = self._haal_sloten()
        for stap_id, titel, _ in STAPPEN:
            if stap_id in self.verborgen:
                # Niet in de lijst, niet in het logboek: dit onderdeel blijft tot het opengaat uit beeld.
                continue
            if self.dicht(stap_id):
                # Komt later in de app, met de les van die week. Geen kaart, geen vraag.
                zin = stappen.slot_zin(self.sloten, stappen.SLOT_VAN_STAP[stap_id])
                self.log(f"{titel}: {zin.lower()} van de cursus, in de app.")
                self.stapstatus(stap_id, "overgeslagen", notitie=zin)
                continue
            self.zet(stap=stap_id, regel="")
            self.stapstatus(stap_id, "bezig")
            while True:
                try:
                    uitkomst = self._draai_stap(stap_id, titel)
                    self.stapstatus(stap_id, "overgeslagen" if uitkomst == "overgeslagen" else "klaar")
                    break
                except HulpKlaar:
                    self.log(f"{titel}: Claude heeft het opgelost, ik probeer het opnieuw.")
                    self.stapstatus(stap_id, "bezig")
                    continue
                except Exception as e:
                    f = e if isinstance(e, Fout) else None
                    if isinstance(e, TeLang):
                        uitleg = f"{titel} bleef hangen."
                        f = Fout(f"{titel} duurt veel langer dan normaal.",
                                 "Druk op Opnieuw proberen. Lukt het dan nog niet, laat Claude het oplossen.")
                    elif f is not None:
                        uitleg = f.uitleg
                    else:
                        for r in getattr(e, "mf_traceback", traceback.format_exc()).splitlines()[-8:]:
                            self.log(r)
                        uitleg = "Er ging iets mis dat ik niet had verwacht."
                        f = Fout(uitleg, "Druk op Opnieuw proberen. Blijft het misgaan, laat Claude het dan oplossen.")
                    self.log(f.uitleg)
                    self._meld("te_lang" if isinstance(e, TeLang) else "fout", stap_id, f.uitleg)
                    # Eerst Claude, zonder dat het lid iets hoeft te kiezen of te openen (Bart, 12 nov 2026).
                    if self._claude_kan(stap_id, f) and self._laat_claude(stap_id, titel, f):
                        self.stapstatus(stap_id, "bezig")
                        continue
                    if stap_id in VERPLICHT or getattr(f, "terug", False):
                        # Zonder deze stap kan de rest niet: de foutkaart met Opnieuw proberen en Claude-hulp.
                        self.stapstatus(stap_id, "fout")
                        self.zet(fase="fout", fout=self.foutkaart(titel, f))
                        self._bewaar_log()
                        self._wacht_op_hulp()
                        return
                    if self._na_fout(stap_id, titel, f, uitleg) == "opnieuw":
                        self.stapstatus(stap_id, "bezig")
                        continue
                    break
        with self.slot:
            self.status["procent"] = 100
            self.status["nog_seconden"] = 0
        self.zet(fase="klaar", stap=None, regel="")
        self._bewaar_log()
        self._meld("klaar", "klaar")

    # ------------------------------------------------------------ melden en vanzelf oplossen
    def _meld(self, soort: str, stap_id: str, tekst: str = "") -> None:
        """Geef door waar het stopte (stappen.meld_installatie). Een fout hier houdt nooit iets tegen."""
        try:
            stappen.meld_installatie(soort, stap_id, tekst, self.logregels if soort in ("fout", "te_lang") else None)
        except Exception:
            pass

    def _claude_kan(self, stap_id: str, f: Optional[Fout] = None) -> bool:
        """Mag Claude deze stap vanzelf proberen op te lossen? Niet voor de stappen waar Claude zelf nog
        niet staat, niet bij een invoerfout (verkeerd adres: daar helpt Gegevens aanpassen), en hooguit
        een keer per stap."""
        if stap_id in ("basis", "claude") or stap_id in self.claude_geprobeerd:
            return False
        if f is not None and getattr(f, "terug", False):
            return False
        return stappen.claude_kan_helpen()

    def _laat_claude(self, stap_id: str, titel: str, f: Fout) -> bool:
        """Claude lost het op de achtergrond op; het lid blijft in de browser. True = opnieuw proberen."""
        self.claude_geprobeerd.add(stap_id)
        self.zet(regel=f"{titel} lukte niet meteen. Claude lost het voor je op. Dat duurt een paar minuten, "
                       "je hoeft niets te doen.")
        self._meld("claude_start", stap_id)
        try:
            opgelost, zin = stappen.claude_lost_op([f"bij de stap {titel}: {f.uitleg}"], self.logregels, self.log)
        except Exception as e:  # Claude mag de installatie nooit laten vallen
            self.log(f"Claude-hulp liep zelf vast ({type(e).__name__}).")
            opgelost, zin = False, ""
        self._meld("claude_opgelost" if opgelost else "claude_niet", stap_id, zin)
        if opgelost:
            self.zet(regel=f"Claude heeft het opgelost. {titel} gaat opnieuw.")
            return True
        if zin:
            f.wat_nu = f"Claude keek ernaar: {zin} " + (f.wat_nu or "")
            f.claude_zin = zin  # type: ignore[attr-defined]
        return False

    def _draai_stap(self, stap_id: str, titel: str):
        """Draait een stap in een eigen draad en houdt de tijd bij. Werkt hij langer dan LIMIET (wachten op
        de gebruiker telt niet), dan vragen we wat je wilt: nog even wachten, of verder (overslaanbare stap)
        of opnieuw (verplichte stap). Een losgelaten draad kan daarna niets meer in beeld zetten."""
        uit: Dict = {}

        def werk() -> None:
            try:
                uit["r"] = getattr(self, "stap_" + stap_id)()
            except BaseException as e:  # noqa: BLE001 - alles terug naar de lus
                e.mf_traceback = traceback.format_exc()  # type: ignore[attr-defined]
                uit["e"] = e

        draad = threading.Thread(target=werk, daemon=True, name="stap-" + stap_id)
        draad.start()
        limiet = float(LIMIET.get(stap_id, 600))
        bezig, vorige = 0.0, time.time()
        while draad.is_alive():
            draad.join(1.0)
            nu = time.time()
            if self.status.get("fase") != "actie":
                bezig += nu - vorige
            vorige = nu
            if draad.is_alive() and bezig >= limiet:
                if self._claude_kan(stap_id):
                    # Geen kaart met keuzes: loslaten, Claude laten kijken en daarna opnieuw (in _loop).
                    draad.mf_verlaten = True  # type: ignore[attr-defined]
                    self.log(f"{titel} bleef hangen; losgelaten na {int(limiet)} seconden, Claude kijkt ernaar.")
                    raise TeLang(titel)
                keuze = self._te_lang_kaart(stap_id, titel, draad)
                if keuze == "wacht":
                    bezig, vorige, limiet = 0.0, time.time(), max(180.0, limiet / 2)
                elif keuze == "hulp":
                    draad.mf_verlaten = True  # type: ignore[attr-defined]
                    stappen.hulp_klaar_wis()
                    raise HulpKlaar(titel)
                elif keuze != "klaar":
                    draad.mf_verlaten = True  # type: ignore[attr-defined]
                    self.log(f"{titel} bleef hangen; losgelaten na {int(limiet)} seconden.")
                    raise TeLang(titel)
        if "e" in uit:
            raise uit["e"]
        return uit.get("r")

    def _te_lang_kaart(self, stap_id: str, titel: str, draad: threading.Thread) -> str:
        """De kaart als een stap blijft hangen. Geeft wacht, verder of klaar (stap was intussen klaar)."""
        while not self.antwoorden.empty():
            self.antwoorden.get_nowait()
        verplicht = stap_id in VERPLICHT
        hulp = self._hulp_uri(titel, f"{titel} blijft hangen")
        kaart = {
            "soort": "keuze", "titel": f"{titel} duurt langer dan normaal",
            "tekst": ("Soms is internet traag of wacht je computer ergens op. Je kunt nog even wachten. "
                      + ("Of begin deze stap opnieuw." if verplicht else
                         "Of ga verder: dit onderdeel doe je later opnieuw met /wizard in Claude Code.")),
            "keuzes": [{"id": "wacht", "tekst": "Wacht nog even"},
                       {"id": "verder", "tekst": "Begin opnieuw" if verplicht else "Ga verder, dit doe ik later"}],
            "knop": {"url": hulp, "tekst": "Laat Claude het oplossen"},
            "klein": HULP_KLEIN if hulp else "",
        }
        with self.slot:
            self.status.update(actie=kaart, fase="actie")
        try:
            while True:
                if not draad.is_alive():
                    return "klaar"
                if stappen.hulp_klaar():
                    return "hulp"
                if self.status.get("actie") is not kaart:
                    # De stap zelf toont intussen een vraag: die gaat voor, wij wachten verder.
                    return "wacht"
                try:
                    a = self.antwoorden.get(timeout=1.0)
                except queue.Empty:
                    continue
                return "wacht" if a.get("waarde") == "wacht" else "verder"
        finally:
            with self.slot:
                if self.status.get("actie") is kaart:
                    self.status.update(actie=None, fase="bezig")

    def _na_fout(self, stap_id: str, titel: str, f: Fout, uitleg: str) -> str:
        """Een overslaanbare stap ging mis: nooit stoppen. Opnieuw, of verder en later opnieuw. Geeft
        opnieuw of verder."""
        self._bewaar_log()
        hulp = self._hulp_uri(titel, f.uitleg)
        antwoord = self.vraag({
            "soort": "keuze", "titel": f"{titel} lukte nu niet",
            "tekst": f"{uitleg} " + (f"Claude keek ernaar: {f.claude_zin} " if getattr(f, "claude_zin", "") else "")
                     + "Je kunt het opnieuw proberen, of verder gaan: de rest van je Mainframe werkt "
                     "ook zonder. Dit onderdeel doe je later opnieuw met /wizard in Claude Code, of met /check.",
            "keuzes": [{"id": "opnieuw", "tekst": "Opnieuw proberen"},
                       {"id": "verder", "tekst": "Ga verder, dit doe ik later"}],
            "knop": {"url": hulp, "tekst": "Laat Claude het oplossen"},
            "klein": HULP_KLEIN if hulp else "",
        }, klaar_als=stappen.hulp_klaar, wacht=1.0, maximaal=7 * 24 * 3600)
        if antwoord.get("soort") == "vanzelf" or antwoord.get("waarde") == "opnieuw":
            # vanzelf = Claude in VS Code heeft het opgelost: gewoon opnieuw, zonder klik.
            stappen.hulp_klaar_wis()
            return "opnieuw"
        if stap_id in LATER_VLAG:
            zet_staat(**{LATER_VLAG[stap_id]: True})
        self._meld("overgeslagen", stap_id, uitleg)
        self.stapstatus(stap_id, "overgeslagen", notitie="Later opnieuw met /wizard")
        return "verder"

    def _wacht_op_hulp(self) -> None:
        """Na een foutkaart van een verplichte stap: zet Claude in VS Code het seintje neer, dan start de
        installatie vanzelf opnieuw (wat al klaar is wordt overgeslagen)."""
        stap = self.status.get("stap")

        def kijk() -> None:
            while self.status.get("fase") == "fout" and self.status.get("stap") == stap:
                if stappen.hulp_klaar() and not (self.draad and self.draad.is_alive()):
                    stappen.hulp_klaar_wis()
                    self.log("Claude heeft het opgelost, de installatie gaat verder.")
                    self.start({})
                    return
                time.sleep(1.0)

        threading.Thread(target=kijk, daemon=True, name="wacht-op-hulp").start()

    def foutkaart(self, titel: str, f: Fout) -> Dict:
        """Wat de foutkaart toont. `terug` = de invoer klopt niet: dan hoort er een knop naar het
        startscherm bij, want Opnieuw proberen met dezelfde invoer helpt niet (Geert, 10 nov 2026)."""
        terug = bool(getattr(f, "terug", False))
        # Bij een invoerfout geen Claude-hulp: die schrijft installatie-hulp.md in een map die er nog niet
        # hoort te zijn (test_lokaal fout-mail: "niets half neergezet"), en Claude kan een verkeerd
        # ingevuld adres toch niet oplossen; de knop Gegevens aanpassen wel.
        return {"uitleg": f.uitleg, "wat_nu": f.wat_nu or "Druk op Opnieuw proberen.",
                "hulp_uri": "" if terug else self._hulp_uri(titel, f.uitleg), "terug": terug,
                "adres_hint": str(getattr(f, "adres_hint", "") or "")}

    def _haal_sloten(self) -> Optional[Dict]:
        """Welke onderdelen er nu open zijn voor deze code. Alleen een cursus vanaf de novembergroep
        heeft sloten; voor al het andere, en als het ophalen niet lukt, verandert er niets."""
        s = lees_staat()
        sloten = sloten_voor(str(s.get("code") or ""), str(s.get("email") or ""), self.log, vers=True)
        if not (sloten and sloten.get("met_sloten")):
            # Toch alles: wat het startscherm dacht te weten, telt dan niet.
            if self.verborgen:
                with self.slot:
                    self.status["stappen"] = self._leeg()["stappen"]
                    self._reken()
                self.verborgen = []
            return None
        self.verborgen = verborgen_stappen(sloten)
        with self.slot:
            # Opnieuw uit de volle lijst: er is nog geen stap begonnen, en het startscherm kan oud zijn.
            self.status["stappen"] = [st for st in self._leeg()["stappen"] if st["id"] not in self.verborgen]
            self._reken()
            for st in self.status["stappen"]:
                if st["id"] == "klaar":
                    st["wat"] = (("We kijken of alles werkt. Daarna open je de app: eerst verhuizen we je oude Mainframe, "
                                  "met je sleutels en je kennis. Daarna vraagt hij alleen nog wat ontbreekt. ")
                                 if lees_staat().get("oude_map") else
                                 "We kijken of alles werkt. Daarna open je de app bij Verstand: je koppelt Apify en "
                                 "je Mainframe leert je kennen. ") + "VS Code met je Mainframe staat erachter klaar."
        return sloten

    def dicht(self, stap_id: str) -> bool:
        slot = stappen.SLOT_VAN_STAP.get(stap_id)
        return bool(slot and stappen.slot_dicht(self.sloten, slot))

    def _bewaar_log(self) -> None:
        try:
            kern.WERKMAP.mkdir(parents=True, exist_ok=True)
            with open(kern.WERKMAP / "logboek.txt", "a", encoding="utf-8") as f:
                f.write(f"\n== {time.strftime('%Y-%m-%d %H:%M:%S')} installatie fase={self.status['fase']}\n")
                f.writelines(r + "\n" for r in self.logregels)
        except OSError:
            pass

    # ------------------------------------------------------------ de stappen
    def stap_basis(self):
        if stappen.check_basis()["status"] == "klaar":
            return
        self.zet(regel="Je computer klaarmaken")
        if systeem() == "mac" and not stappen._git_ok():
            kern.stil(["xcode-select", "--install"])
            self.vraag({"soort": "wacht", "titel": "Klik op Installeren",
                        "tekst": "Je Mac vraagt om een onderdeel van Apple. Klik in dat venster op Installeren. Ik ga vanzelf verder."},
                       klaar_als=stappen._git_ok, wacht=5, maximaal=3600)
        if systeem() == "windows":
            self.zet(regel="Vraagt Windows om toestemming? Klik op Ja.")
        stappen.doe_basis({}, self.log)

    def stap_claude(self):
        if stappen.check_claude()["status"] == "klaar":
            return
        if not stappen._claude():
            self.zet(regel="Claude installeren")
            stappen.doe_claude({"actie": "alleen_installeren"}, self.log)
        stappen._onboarding_klaar()
        if stappen.claude_ingelogd():
            if stappen.claude_werkt(vers=True):
                return
            # Wel "ingelogd", maar Claude antwoordt niet: de login is verlopen. Eerst uitloggen,
            # dan krijgt het lid gewoon het inlogscherm (Barts XPS, 10 nov 2026).
            self.log("Je Claude-login is verlopen. Je logt even opnieuw in.")
            stappen.claude_uitloggen()
        link: Dict[str, str] = {}
        uitvoer: List[str] = []
        proces = self._start_claude_login(link, uitvoer)
        tekst = "Je browser opent Claude. Log in en klik op Authorize."
        mislukt = 0
        try:
            while True:
                # Ook klaar als het inloggen zelf stopt: anders bleef deze kaart staan terwijl er
                # niets meer gebeurde, zonder dat iemand zag waarom (melding Yuri, 23 okt 2026).
                antwoord = self.vraag({
                    "soort": "claude", "titel": "Log in bij Claude",
                    "tekst": tekst,
                    "knop": {"tekst": "Open Claude", "url": link.get("url", "https://claude.ai/login")},
                    "invoer": {"label": "Zie je een code? Plak hem hier.", "veld": "code"},
                }, klaar_als=lambda: bool(stappen.claude_ingelogd()) or proces.poll() is not None,
                    wacht=2, maximaal=1800)
                if stappen.claude_ingelogd():
                    return
                if antwoord.get("soort") == "code" and proces.poll() is None:
                    code = re.sub(r"\s+", "", str(antwoord.get("waarde", "")))
                    try:
                        proces.stdin.write((code + "\n").encode())  # type: ignore[union-attr]
                        proces.stdin.flush()  # type: ignore[union-attr]
                    except OSError:
                        pass
                    for _ in range(20):
                        time.sleep(1)
                        if stappen.claude_ingelogd():
                            return
                        if proces.poll() is not None:
                            break
                if proces.poll() is None:
                    continue
                # Het inloggen is gestopt. Even wachten: net na een gelukte login kan de status nog achterlopen.
                for _ in range(3):
                    time.sleep(1)
                    if stappen.claude_ingelogd():
                        return
                for regel in uitvoer[-8:]:
                    if regel and "oauth/authorize" not in regel:
                        self.log(regel)
                fout = stappen.claude_login_fout(uitvoer)
                mislukt += 1
                # Stopte hij voor er een inlogpagina was (Git ontbreekt, geen internet), dan helpt
                # opnieuw proberen op deze kaart niet: meteen zeggen wat er mis is.
                if not link.get("url") or mislukt >= 3:
                    raise fout
                tekst = f"Dat lukte niet: {fout.uitleg} Log nog een keer in; je browser opent Claude opnieuw."
                link.clear()
                uitvoer.clear()
                proces = self._start_claude_login(link, uitvoer)
        finally:
            if proces.poll() is None:
                proces.terminate()

    def _start_claude_login(self, link: Dict[str, str], uitvoer: Optional[List[str]] = None) -> subprocess.Popen:
        c = stappen._claude()
        if not c:
            raise Fout("Claude Code staat er niet goed op.", "Druk op Opnieuw proberen; dan zet ik hem er opnieuw op.")
        vlaggen = getattr(subprocess, "CREATE_NO_WINDOW", 0) if systeem() == "windows" else 0
        try:
            proces = subprocess.Popen([c, "auth", "login", "--claudeai"], stdin=subprocess.PIPE,
                                      stdout=subprocess.PIPE, stderr=subprocess.STDOUT, creationflags=vlaggen,
                                      env=stappen.claude_omgeving())
        except OSError as e:
            # Exec format error op een halve npm-installatie (melding Robin, 28 okt 2026): geen
            # onverwachte fout maar een kaart met de volgende stap; _claude() slaat dit pad daarna over.
            raise stappen.claude_start_fout(c, e)

        def lees():
            for ruw in iter(proces.stdout.readline, b""):  # type: ignore[union-attr]
                regel = ruw.decode("utf-8", "replace").strip()
                if uitvoer is not None:
                    uitvoer.append(regel)
                    del uitvoer[:-50]
                m = re.search(r"https://\S+oauth/authorize\S+", regel)
                if m:
                    link["url"] = m.group(0)
                    with self.slot:
                        if self.status.get("actie") and self.status["actie"].get("soort") == "claude":
                            self.status["actie"]["knop"]["url"] = m.group(0)

        threading.Thread(target=lees, daemon=True).start()
        return proces

    def stap_orca(self):
        if stappen.check_orca()["status"] == "klaar":
            return
        self.zet(regel="Orca downloaden")
        stappen.doe_orca({}, self.log)

    def kies_bestaande_map(self) -> None:
        """Heeft iemand al een Mainframe (zelf opgebouwd in de cursus, of een eerdere versie), dan
        komt Jarvis daarbij in plaats van in een tweede map (Bart, 11 okt 2026)."""
        s = lees_staat()
        if s.get("map") or s.get("map_gekozen"):
            return
        vondsten = stappen.zoek_bestaande_mainframes()
        if not vondsten:
            return
        def kort(p: Path) -> str:
            try:
                return str(p.relative_to(kern.THUIS))
            except ValueError:
                return str(p)
        vondsten = vondsten[:3]
        if any(stappen._licentie(p) for p in vondsten):
            # Al Mainframe 2.0: die werken we bij, op zijn plek.
            keuzes = [{"id": str(i), "tekst": f"Ja, in {kort(p)}"} for i, p in enumerate(vondsten)]
            keuzes.append({"id": "nieuw", "tekst": "Nee, een nieuwe map"})
            tekst = (f"Ik zag je Mainframe in {kort(vondsten[0])}. Zal ik Jarvis en Mainframe OS daarbij zetten? "
                     "Je eigen bestanden blijven precies zoals ze zijn; alleen wat ontbreekt komt erbij.")
        else:
            # Een oude Mainframe: 2.0 op de logische plek, de oude gaat straks veilig mee (Bart, 20 okt 2026).
            keuzes = [{"id": str(i), "tekst": f"Ja, neem {kort(p)} mee"} for i, p in enumerate(vondsten)]
            keuzes.append({"id": "nieuw", "tekst": "Nee, ik begin opnieuw"})
            tekst = ("Geen probleem. Mainframe 2.0 komt in een nieuwe map, en daar kopieren we alles naartoe wat je "
                     "hebt ingericht: je skills, CLAUDE.md, kennis, projecten, klanten, scripts, verbindingen, "
                     "wachtwoorden en automatiseringen. Je oude map blijft precies zoals hij is.")
        antwoord = self.vraag({"soort": "keuze", "titel": "Je hebt al een Mainframe", "tekst": tekst, "keuzes": keuzes})
        w = str(antwoord.get("waarde", ""))
        if not (w.isdigit() and int(w) < len(vondsten)):
            zet_staat(map_gekozen=True)
            return
        gekozen = vondsten[int(w)]
        if stappen._licentie(gekozen):
            zet_staat(map=str(gekozen), map_gekozen=True)
        else:
            # Nooit in de oude map zelf, ook niet als hij ~/Mainframe heet (Bart, 21 okt 2026).
            zet_staat(map=str(stappen.verhuis_doel(gekozen)), map_gekozen=True, oude_map=str(gekozen))

    def haal_op(self) -> bool:
        """Tweede computer: log in bij GitHub, kies de back-up en haal hem binnen. Geeft True als de map
        van GitHub komt; False als de gebruiker toch voor een nieuw Mainframe koos."""
        s = lees_staat()
        doel = stappen.map_uit_keuze(str(s.get("map") or kern.THUIS / "Mainframe"))
        if (doel / ".git").exists() and ophalen.deze_computer(doel).get("opgehaaldVan"):
            zet_staat(map=str(doel), map_gekozen=True)
            return True  # al eerder binnengehaald (Opnieuw proberen)
        waarom = stappen.gedeelde_map(doel)
        if waarom:
            raise Fout(f"{doel} staat in {waarom}.", stappen.GEDEELD_UITLEG)
        self.zet(regel="De GitHub-tool klaarzetten")
        gh = ophalen.vind_gh() or ophalen.installeer_gh(self.log)
        self.github_inloggen(gh)
        ophalen.zet_git_op_gh(gh)
        while True:
            self.zet(regel="Je back-up op GitHub zoeken")
            gevonden = ophalen.zoek_backups(gh, self.log)
            if not gevonden:
                antwoord = self.vraag({
                    "soort": "keuze", "titel": "Ik vind nog geen back-up op GitHub",
                    "tekst": "Je Mainframe moet eerst op je andere computer naar GitHub. Open daar de app, ga naar "
                             "Verbindingen, kies GitHub en klik op Zet back-up aan. Klaar? Klik hier op Zoek opnieuw.",
                    "keuzes": [{"id": "opnieuw", "tekst": "Zoek opnieuw"},
                               {"id": "nieuw", "tekst": "Begin met een nieuw Mainframe"}]})
                if antwoord.get("waarde") == "nieuw":
                    zet_staat(ophalen=False)
                    return False
                continue
            if len(gevonden) == 1:
                keuze = gevonden[0]
            else:
                antwoord = self.vraag({
                    "soort": "keuze", "titel": "Welke is je Mainframe?",
                    "tekst": "Ik zag meer dan een Mainframe op je GitHub. Kies de back-up die je wilt ophalen.",
                    "keuzes": [{"id": str(i), "tekst": g["repo"].split("/")[-1]
                                + (f" (bijgewerkt {ophalen.datum_tekst(g['bijgewerkt'])})" if ophalen.datum_tekst(g["bijgewerkt"]) else "")}
                               for i, g in enumerate(gevonden[:4])]})
                w = str(antwoord.get("waarde", ""))
                keuze = gevonden[int(w)] if w.isdigit() and int(w) < len(gevonden) else gevonden[0]
            break
        self.zet(regel="Je Mainframe ophalen van GitHub")
        ophalen.kloon(keuze["url"], doel, self.log)
        zet_staat(map=str(doel), map_gekozen=True, ophalen_url=keuze["url"])
        return True

    def github_inloggen(self, gh: str) -> None:
        if ophalen.ingelogd_als(gh):
            return
        for poging in range(3):
            inlog = ophalen.Inloggen(gh)
            try:
                code = inlog.wacht_op_code()
                if not code:
                    continue
                kern.open_in_browser(ophalen.DEVICE_URL)
                self.vraag({
                    "soort": "github", "titel": "Log in bij GitHub",
                    "tekst": "Je Mainframe staat als back-up op GitHub. Log daar in en vul deze code in. "
                             "Klik daarna op Authorize. Ik ga vanzelf verder.",
                    "sleutel": code,
                    "knop": {"tekst": "Open GitHub", "url": ophalen.DEVICE_URL},
                    "klein": "Gebruik hetzelfde GitHub-account als op je andere computer."},
                    klaar_als=inlog.klaar, wacht=2, maximaal=1800)
                for _ in range(10):
                    if ophalen.ingelogd_als(gh):
                        return
                    time.sleep(1)
            finally:
                inlog.stop()
        raise Fout("Inloggen bij GitHub lukte niet.",
                   "Druk op Opnieuw proberen. Lukt het niet, kies dan bij de start Nieuw Mainframe en haal je map later op.")

    def stap_vscode(self):
        if stappen.check_vscode()["status"] == "klaar":
            return
        self.zet(regel="VS Code downloaden" if not stappen.vscode_pad() else "Claude Code in VS Code zetten")
        stappen.doe_vscode({}, self.log)

    def stap_mainframe(self):
        opgehaald = False
        if stappen.check_mainframe()["status"] != "klaar":
            if lees_staat().get("ophalen"):
                opgehaald = self.haal_op()
            else:
                self.kies_bestaande_map()
        s = lees_staat()
        if stappen.check_mainframe()["status"] != "klaar":
            self.zet(regel="Je Mainframe ophalen")
            stappen.doe_mainframe({"code": s.get("code", ""), "email": s.get("email", ""),
                                   "map": s.get("map") or str(kern.THUIS / "Mainframe"),
                                   "opgehaald": opgehaald}, self.log)
        if opgehaald:
            m = stappen.mainframe_map()
            if m:
                ophalen.meld_aan(m, str(lees_staat().get("ophalen_url") or ""), self.log)
                # Meteen de hoofdsleutel: dan staan je sleutels (ook die van Jarvis) er weer voor de app start.
                try:
                    heeft_versleuteld = bool(stappen.sleutelmodule().versleutelde(m))
                except Exception:
                    heeft_versleuteld = False
                if heeft_versleuteld:
                    self.stap_sleutels()
        # De 4 V's: de app weet vanaf de eerste start wat er open is, ook zonder internet.
        m = stappen.mainframe_map()
        if self.sloten and m:
            try:
                stappen.schrijf_v_sloten(m, self.sloten)
            except OSError:
                self.log("De status van de onderdelen kon niet in je map; de app haalt hem zelf op.")
        # Vooraf ingevuld "Over jou" (VIP) gaat er stil in; anders vraagt Jarvis het later.
        vulling = lees_staat().get("vulling") or {}
        if vulling.get("wie") and vulling.get("wat") and stappen.check_overjou()["status"] != "klaar":
            stappen.doe_overjou(vulling, self.log)

    def stap_app(self):
        m = stappen.mainframe_map()
        versie_bestand = (m / ".mainframe" / "app" / ".versie") if m else None
        actueel = bool(versie_bestand and versie_bestand.exists()
                       and versie_bestand.read_text().strip() == (lees_staat().get("app_versie") or ""))
        if actueel and stappen.check_app()["status"] == "klaar":
            stappen.zet_onderdelen({"jarvis": True, "agenda": True, "inbox": True})
            stappen.zet_vanzelf(self.log)
            return
        self.zet(regel="De app met Jarvis installeren")
        stappen.doe_app({"zonder_orca": "orca" in self.verborgen, "lokaal": self.dicht("telefoon")}, self.log)

    def stap_jarvis(self):
        if stappen._gemini_sleutel():
            stappen.doe_jarvis({}, self.log)  # naam naar de app
            return
        kern.open_in_browser(AI_STUDIO)
        gevonden: Dict[str, str] = {}

        def uit_klembord() -> bool:
            sleutel = lees_klembord_sleutel()
            if sleutel and sleutel != gevonden.get("afgewezen"):
                gevonden["sleutel"] = sleutel
                return True
            return False

        tekst = f"{SLEUTEL_GRATIS} Klik bij Google op Create API key en daarna op Copy. De rest gaat vanzelf."
        while True:
            antwoord = self.vraag({
                "soort": "gemini", "titel": "Geef Jarvis een stem",
                "tekst": tekst,
                "knop": {"tekst": "Open Google", "url": AI_STUDIO},
                "invoer": {"label": "Of plak de sleutel hier.", "veld": "sleutel"},
                "klein": f"{KOSTEN_STEM} {PLAFOND_TIP}",
                "link": {"tekst": "Zet een plafond bij Google", "url": AI_STUDIO_PLAFOND},
            }, klaar_als=uit_klembord, wacht=1.5, maximaal=3600)
            sleutel = gevonden.get("sleutel") if antwoord.get("soort") == "vanzelf" else str(antwoord.get("waarde", "")).strip()
            if not sleutel:
                continue
            self.zet(regel="Sleutel controleren")
            try:
                stappen.doe_jarvis({"sleutel": sleutel}, self.log)
                self.betalen_aanzetten()
                return
            except Fout as e:
                gevonden["afgewezen"] = sleutel
                gevonden.pop("sleutel", None)
                # De echte reden laten zien (melding Pieter, 21 okt 2026: hij zocht lang op de verkeerde plek).
                tekst = " ".join(x for x in (e.uitleg, e.wat_nu) if x) or "Die sleutel werkt niet. Kopieer hem nog een keer bij Google."

    def betalen_aanzetten(self):
        """Een nieuwe sleutel staat zonder betaalgegevens: de stem werkt, maar het denkwerk van Jarvis
        mag dan maar zo'n twintig keer per dag (gezien in AI Studio, 11 okt 2026). Bart koos: de
        installer laat betalen aanzetten, op de eigen rekening van de gebruiker."""
        antwoord = self.vraag({
            "soort": "gemini-betalen", "titel": "Zet betalen aan bij Google",
            "tekst": "Zonder betalen mag Jarvis maar een paar vragen per dag nadenken. Klik bij Google naast je "
                     "nieuwe sleutel op Set up billing en vul je betaalgegevens in. Vraagt Google om tegoed te kopen "
                     "(Buy credits)? Koop 10 dollar en klik daarna op Setup auto-reload. Dan vult Google het vanzelf "
                     "bij en valt Jarvis nooit stil.",
            "knop": {"tekst": "Open Google", "url": AI_STUDIO_SLEUTELS},
            "knop_klaar": "Gedaan",
            "overslaan": "Later",
            "klein": f"{KOSTEN_STEM} {PLAFOND_TIP}",
            "link": {"tekst": "Zet een plafond bij Google", "url": AI_STUDIO_PLAFOND},
        }, maximaal=3600)
        zet_staat(gemini_betalen="gedaan" if antwoord.get("soort") == "klaar" else "later")

    def stap_mail(self):
        if stappen.check_mail()["status"] == "klaar":
            return
        # Een oude Mainframe heeft zijn eigen koppelingen al (een eigen Microsoft-app, een zelfgebouwde
        # mailkoppeling). Die zet de eigen Claude straks over in de app, en controleert dat ze werken
        # (Bart, 26 okt 2026). Hier opnieuw koppelen gaf een tweede, andere koppeling (meldingen 16 en 21).
        if lees_staat().get("oude_map"):
            return "overgeslagen"
        s = lees_staat()
        p = s.get("aanbieder") or stappen.aanbieder(s.get("email", ""))
        if p not in ("outlook", "google"):
            antwoord = self.vraag({"soort": "keuze", "titel": "Waar staat je mail?",
                                   "tekst": "Dan kan Jarvis je agenda en mail lezen.",
                                   "keuzes": [{"id": "outlook", "tekst": "Microsoft"},
                                              {"id": "google", "tekst": "Google"},
                                              {"id": "anders", "tekst": "Andere mail"},
                                              {"id": "later", "tekst": "Later"}]})
            p = antwoord.get("waarde")
            if p == "anders":
                return self.mail_eigen_server(s.get("email", ""))
            if p not in ("outlook", "google"):
                zet_staat(mail_later=True)
                return "overgeslagen"
        zet_staat(aanbieder=p, mail_later=False)
        if p == "outlook":
            stappen.app_post("/__operator/connections/configure", {"provider": "outlook", "clientId": MICROSOFT_CLIENT_ID})
        else:
            stappen.app_post("/__operator/connections/configure", {"provider": "google", "clientId": GOOGLE_CLIENT_ID,
                                                                    "clientSecret": GOOGLE_CLIENT_SECRET})
        stand = stappen.check_mail()
        wie = "Microsoft" if p == "outlook" else "Google"
        antwoord = self.vraag({
            "soort": "mail", "titel": "Koppel je agenda en mail",
            "tekst": f"Log in met je {wie}-account en klik op Accepteren.",
            "knop": {"tekst": f"Log in met {wie}", "url": stand.get("koppel_url", "")},
            "klein": ("Google meldt dat de app niet geverifieerd is. Klik op Geavanceerd en dan op Doorgaan."
                      if p == "google" else "Vraagt Microsoft om een beheerder? Dan geeft je beheerder hieronder een keer "
                      "akkoord voor het hele bedrijf. Daarna klik je gewoon op Log in. Of kies Later."),
            "link": None if p == "google" else {
                "tekst": "Beheerder van je bedrijf? Geef hier een keer akkoord voor iedereen",
                "url": beheerder_akkoord_url(s.get("email", ""))},
            "overslaan": "Later",
        }, klaar_als=lambda: stappen.check_mail()["status"] == "klaar", wacht=3, maximaal=3600)
        if antwoord.get("soort") == "overslaan":
            zet_staat(mail_later=True)
            return "overgeslagen"
        self.vraag_wat_mag_hij()

    def vraag_wat_mag_hij(self):
        """Wat mag hij (31 okt 2026): na het koppelen vragen of je Mainframe zelf mails mag
        versturen. Schrijft alleen de regel mail; de rest blijft op Na mijn ja. Later = niets
        schrijven, dan geldt de standaard (Na mijn ja). Een keer per installatie."""
        if lees_staat().get("wat_mag_hij_mail"):
            return
        antwoord = self.vraag({
            "soort": "keuze", "titel": "Mag je Mainframe zelf mails versturen?",
            "tekst": "Je Mainframe kan mails voor je schrijven. Kies of hij ze ook zelf mag versturen.",
            "keuzes": [{"id": "na_ja", "tekst": "Na mijn ja (aanbevolen)"},
                       {"id": "nooit", "tekst": "Nooit"},
                       {"id": "zelf", "tekst": "Mag zelf"}],
            "klein": "Na mijn ja: hij zet de mail klaar en jij klikt in de app op versturen. "
                     "Nooit: je verstuurt altijd zelf, in je eigen mailprogramma. "
                     "Mag zelf: hij verstuurt zonder het eerst te vragen. "
                     "Je kunt dit later altijd veranderen in de app, bij Verbindingen.",
            "overslaan": "Later",
        })
        stand = antwoord.get("waarde") if antwoord.get("soort") == "keuze" else None
        if stand not in ("na_ja", "nooit", "zelf"):
            zet_staat(wat_mag_hij_mail="later")
            return
        try:
            stappen.zet_wat_mag_hij("mail", stand)
            zet_staat(wat_mag_hij_mail=stand)
            self.log({"na_ja": "Mails versturen: na jouw ja.", "nooit": "Mails versturen: nooit door je Mainframe.",
                      "zelf": "Mails versturen: mag je Mainframe zelf."}[stand])
        except Exception:
            # Geen reden om de installatie te laten mislukken: dan geldt de standaard.
            self.log("Je keuze voor mails versturen kon niet bewaard worden. Dan geldt Na mijn ja; "
                     "je verandert het in de app bij Verbindingen.")

    def mail_eigen_server(self, email: str):
        """Mail bij een hoster (eigen domein, KPN, Ziggo, iCloud): IMAP, alleen het
        wachtwoord vragen. De app zoekt zelf de server en de poort en test de inlog
        (Bart, 19 oktober 2026: ook wie geen Google of Microsoft heeft, moet na de
        installatie meteen zijn mail op het dashboard zien)."""
        zet_staat(aanbieder="anders", mail_later=False)
        uitleg = f"Vul het wachtwoord van {email} in. De rest zoek ik zelf uit."
        while True:
            antwoord = self.vraag({
                "soort": "mail", "titel": "Koppel je mail",
                "tekst": uitleg,
                "invoer": {"label": "Wachtwoord", "veld": "wachtwoord", "geheim": True},
                "klein": "Gebruik je iCloud of tweestapsverificatie? Maak dan een app-wachtwoord aan bij je mailaanbieder en plak dat hier. Jarvis leest alleen; versturen doet hij nooit zonder jouw ja.",
                "overslaan": "Later",
            })
            if antwoord.get("soort") == "overslaan":
                zet_staat(mail_later=True)
                return "overgeslagen"
            if antwoord.get("soort") != "wachtwoord":
                continue
            self.zet(regel="Mailserver zoeken en inloggen")
            try:
                uit = stappen.app_post("/__operator/connections/mailbox/toevoegen",
                                       {"email": email, "wachtwoord": str(antwoord.get("waarde", ""))}, timeout=90)
            except stappen.Fout as fout:
                uit = {"ok": False, "fout": fout.uitleg if hasattr(fout, "uitleg") else str(fout)}
            if uit.get("ok"):
                self.vraag_wat_mag_hij()
                return None
            uitleg = (uit.get("fout") or "Inloggen lukte niet.") + " Probeer het nog eens, of kies Later."

    def stap_telefoon(self):
        if stappen.check_telefoon()["status"] in ("klaar", "overgeslagen"):
            return "overgeslagen" if stappen.check_telefoon()["status"] == "overgeslagen" else None
        vast = lees_staat().get("vaste_computer") == "ja"
        antwoord = self.vraag({"soort": "keuze", "titel": "Jarvis ook op je telefoon?",
                               "tekst": "Dan praat je ook onderweg met Jarvis." if vast else
                               "Dat werkt zolang deze laptop aan staat.",
                               "keuzes": [{"id": "ja", "tekst": "Ja, graag"}, {"id": "later", "tekst": "Later"}]})
        if antwoord.get("waarde") != "ja":
            zet_staat(telefoon_later=True)
            return "overgeslagen"
        if not stappen._tailscale():
            self.zet(regel="Tailscale downloaden")
            if systeem() == "mac":
                pkg = kern.download("https://pkgs.tailscale.com/stable/Tailscale-latest-macos.pkg",
                                    kern.WERKMAP / "downloads" / "Tailscale.pkg", self.log, "Tailscale")
                kern.stil(["open", str(pkg)])
                self.vraag({"soort": "wacht", "titel": "Installeer Tailscale",
                            "tekst": "Klik in het venster door tot Installeer. Je Mac vraagt om je wachtwoord."},
                           klaar_als=lambda: bool(stappen._tailscale()), wacht=4)
            elif systeem() == "windows":
                kern.draai(["winget", "install", "--id", "Tailscale.Tailscale", "-e", "--silent",
                            "--accept-package-agreements", "--accept-source-agreements"], self.log, timeout=900)
            else:
                raise Fout("Installeer Tailscale via tailscale.com/download.", "Druk daarna op Opnieuw proberen.")
        if not stappen.tailscale_status().get("ingelogd"):
            if systeem() == "mac":
                kern.stil(["open", "-a", "Tailscale"])
            else:
                t = stappen._tailscale()
                if t:
                    kern.stil([t, "up"], timeout=5)
            self.vraag({"soort": "wacht", "titel": "Log in bij Tailscale",
                        "tekst": "Klik op het Tailscale-icoon bovenin je scherm en log in. Gebruik straks op je telefoon hetzelfde account."
                        if systeem() == "mac" else "Log in bij Tailscale in het venster dat opent.",
                        "overslaan": "Later"},
                       klaar_als=lambda: bool(stappen.tailscale_status().get("ingelogd")), wacht=4)
            if not stappen.tailscale_status().get("ingelogd"):
                zet_staat(telefoon_later=True)
                return "overgeslagen"
        self.zet(regel="Je telefoon klaarzetten")
        uit = stappen.doe_telefoon({"actie": "koppel"}, self.log)
        antwoord = self.vraag({"soort": "qr", "titel": "Scan met je telefoon",
                               "tekst": "Installeer eerst Tailscale op je telefoon en log in met hetzelfde account. Scan daarna de tweede code. Op Android krijg je dan ook de Jarvis-app.",
                               "qr": [{"tekst": "Tailscale", "url": "https://tailscale.com/download"},
                                      {"tekst": "Jarvis", "url": uit.get("koppellink", "")}],
                               "knop_klaar": "Het werkt", "overslaan": "Later"})
        if antwoord.get("soort") == "overslaan":
            zet_staat(telefoon_later=True)
            return "overgeslagen"
        zet_staat(telefoon_klaar=True, telefoon_later=False)

    def stap_sleutels(self):
        """Sleutels veilig (Bart, 25 okt 2026): hoofdsleutel maken of plakken, bewaren, versleutelen.
        Een fout hier stopt de installatie nooit: alles blijft dan zoals het was, en /wizard biedt het
        opnieuw aan."""
        if stappen.check_sleutels()["status"] == "klaar":
            return
        m = stappen.mainframe_map()
        mod = stappen.sleutelmodule()
        uitleg = ("In je Mainframe staan sleutels: de codes waarmee je Mainframe namens jou bij je mail, agenda en "
                  "andere programma's mag. We maken ze onleesbaar voor iedereen die je hoofdsleutel niet heeft.")
        try:
            self.zet(regel="Het programma voor versleutelen klaarzetten")
            mod.dotenvx()
            if not mod.hoofdsleutel() and mod.versleutelde(m):
                # Er staan al versleutelde sleutels (uit GitHub of een back-up): dit is een volgende computer.
                antwoord = {"soort": "keuze", "waarde": "volgende"}
            elif not mod.hoofdsleutel():
                antwoord = self.vraag({
                    "soort": "keuze", "titel": "Zet je sleutels veilig", "tekst": uitleg,
                    "keuzes": [{"id": "eerste", "tekst": "Maak mijn hoofdsleutel"},
                               {"id": "volgende", "tekst": "Ik heb al een hoofdsleutel"}],
                    "overslaan": "Later",
                    "klein": "Heb je dit al eens op een andere computer gedaan? Kies dan Ik heb al een hoofdsleutel."})
            else:
                antwoord = {}
            if not mod.hoofdsleutel():
                if antwoord.get("soort") == "overslaan":
                    zet_staat(sleutels_later=True)
                    stappen.meld_installatie("overgeslagen", "sleutels", "Later gekozen")
                    return "overgeslagen"
                if antwoord.get("waarde") == "volgende":
                    tekst = "Dezelfde hoofdsleutel als op je eerste computer. Je vindt hem in je wachtwoordmanager onder Mainframe-hoofdsleutel."
                    while True:
                        antwoord = self.vraag({"soort": "sleutel-plakken", "titel": "Plak je hoofdsleutel", "tekst": tekst,
                                               "invoer": {"label": "Je hoofdsleutel (64 tekens)", "veld": "hoofdsleutel", "geheim": True},
                                               "overslaan": "Later"})
                        if antwoord.get("soort") == "overslaan":
                            zet_staat(sleutels_later=True)
                            return "overgeslagen"
                        try:
                            mod.zet_hoofdsleutel(str(antwoord.get("waarde", "")), m)
                            break
                        except mod.SleutelFout as e:
                            tekst = f"Dat lukte niet: {e}. Er is niets veranderd. Probeer het nog een keer."
                else:
                    mod.maak_hoofdsleutel()
            if not mod.is_bewaard():
                antwoord = self.vraag({
                    "soort": "sleutel-tonen", "titel": "Dit is je hoofdsleutel",
                    "tekst": "Dit is de sleutel waarmee alleen jij je andere sleutels kunt openen. Je hebt hem nodig "
                             "als je een tweede computer koppelt of een nieuwe computer koopt. Je ziet hem maar een keer. "
                             "Heb je een wachtwoordmanager, zoals NordPass, 1Password of Bitwarden? Klik op Kopieer en "
                             "bewaar hem daar als nieuw item met de naam Mainframe-hoofdsleutel. Heb je die niet? Klik "
                             "op Bewaar als bestand en zet dat bestand op een usb-stick, of print het en leg het bij je "
                             "papieren. Zet hem niet in een gesprek met je AI of in een mail.",
                    "sleutel": mod.hoofdsleutel(),
                    "bewaar_bestand": "Mainframe-hoofdsleutel.txt",
                    "vinkje": "Ik heb mijn hoofdsleutel bewaard",
                    "knop_klaar": "Verder"}, maximaal=7200)
                if antwoord.get("soort") != "klaar":
                    zet_staat(sleutels_later=True)
                    return "overgeslagen"
                mod.bevestig_bewaard()
            self.zet(regel="Je sleutels versleutelen en controleren")
            uit = mod.beveilig(m)
            mislukt = {k: v for k, v in uit.items() if v.startswith("niet gedaan")}
            self.log(f"Sleutels: {len(uit) - len(mislukt)} van {len(uit)} veilig.")
            for k, v in mislukt.items():
                self.log(f"Sleutels: {k}: {v}")
            if mislukt:
                raise Fout("Niet al je sleutels konden versleuteld worden. Er is niets weggegooid.",
                           "Druk op Opnieuw proberen.")
            zet_staat(sleutels_later=False)
        except mod.SleutelFout as e:
            # Nooit meer stil overslaan (12 nov 2026: een lid merkte pas bij les 4 dat .env.versleuteld
            # ontbrak). Hardop: eerst lost Claude het op, anders een kaart met Opnieuw proberen of Ga verder.
            self.log(f"Sleutels: niet gelukt, er is niets veranderd ({e}).")
            raise Fout(f"Je sleutels veilig zetten lukte niet: {e}. Er is niets veranderd aan je bestanden.",
                       "Druk op Opnieuw proberen.") from None

    def stap_klaar(self):
        self.zet(regel="Alles nalopen")
        if self.dicht("jarvis"):
            # Zonder de stap Jarvis' stem ging je naam nog niet naar de app.
            stappen.naam_naar_app(self.log)
        invoer = {"zonder_jarvis": self.dicht("jarvis"), "zonder_mail": self.dicht("mail"), "zonder_fout": True}
        uit = stappen.doe_klaar(invoer, self.log)
        groen = lambda u: u.get("ok", all(c.get("ok") for c in u.get("controles", [])))  # noqa: E731
        if not groen(uit):
            # Eerst zelf repareren wat rood is, dan opnieuw meten (Bart, 10 nov 2026: nooit vastlopen).
            self.repareer_rood({c["naam"] for c in uit["controles"] if not c["ok"]})
            uit = stappen.doe_klaar(invoer, self.log)
        if not groen(uit) and self._claude_kan("klaar"):
            # Dan Claude, op de achtergrond, zonder dat het lid iets hoeft te openen (Bart, 12 nov 2026).
            rood = [c for c in uit["controles"] if not c["ok"]]
            wat = "; ".join(stappen.HULP_PER_CONTROLE.get(c["naam"], (c["naam"] + " lukte niet.", []))[0] for c in rood)
            self._meld("fout", "klaar", wat)
            if self._laat_claude("klaar", "De eindcontrole", Fout(wat)):
                uit = stappen.doe_klaar(invoer, self.log)
        m = stappen.mainframe_map()
        if m:
            stappen.open_in_vscode(m, self.log)
        if not groen(uit):
            self._meld("overgeslagen", "klaar", "; ".join(c["naam"] for c in uit["controles"] if not c["ok"]))
            self.toon_hulp([c for c in uit["controles"] if not c["ok"]])
            if stappen.hulp_klaar():
                # Claude in VS Code heeft het opgelost: opnieuw meten, dan pas door.
                stappen.hulp_klaar_wis()
                uit = stappen.doe_klaar(invoer, self.log)
                if not groen(uit):
                    self.toon_hulp([c for c in uit["controles"] if not c["ok"]])
                    stappen.hulp_klaar_wis()
            if stappen.app_draait():
                pad = "/jarvis" if not self.dicht("jarvis") else "/verstand?onboarding=1"
                uit[("jarvis" if pad == "/jarvis" else "verstand")] = stappen.app_draait() + pad
        self.zet(jarvis=uit.get("jarvis"), verstand=uit.get("verstand"), verhuizen=bool(uit.get("verhuizen")))

    def _hulp_uri(self, titel: str, uitleg: str) -> str:
        """Bij een foutkaart: Claude in VS Code met het probleem erin, als Claude al werkt. Anders leeg."""
        try:
            return stappen.hulp_bij_probleem([f"bij de stap {titel}: {uitleg}"], self.logregels, self.log)["uri"]
        except Exception:
            return ""

    def repareer_rood(self, rood: set) -> None:
        """Wat de installer zelf kan rechtzetten. Een stap die zelf weer misgaat, stopt de installer niet."""
        if rood & {"Claude Code ingelogd", "Claude antwoordt vanuit je Mainframe"}:
            self.zet(regel="Opnieuw inloggen bij Claude")
            try:
                self.stap_claude()
            except Fout as f:
                self.log(f.uitleg)
        if "Mainframe-map compleet" in rood:
            self.zet(regel="Je Mainframe-map aanvullen")
            try:
                self.stap_mainframe()
            except Fout as f:
                self.log(f.uitleg)
        if "De app draait" in rood:
            self.zet(regel="De app opnieuw starten")
            try:
                stappen.doe_app({"zonder_orca": "orca" in self.verborgen, "lokaal": self.dicht("telefoon")}, self.log)
            except Fout as f:
                self.log(f.uitleg)
        self.zet(regel="Alles nog een keer nalopen")

    def toon_hulp(self, rood: List[Dict]) -> None:
        """Blijft iets rood: zeg wat er mis is, zet Claude in VS Code klaar met het probleem erin
        (het lid drukt op Enter), en geef de stappen voor als Claude het ook niet kan. Daarna altijd door."""
        uitleg = [stappen.HULP_PER_CONTROLE.get(c["naam"], (c["naam"] + " lukte niet.", []))[0]
                  + (f" ({c['uitleg']})" if c.get("uitleg") else "") for c in rood]
        stappenlijst: List[str] = []
        for c in rood:
            for regel in stappen.HULP_PER_CONTROLE.get(c["naam"], ("", []))[1]:
                if regel not in stappenlijst:
                    stappenlijst.append(regel)
        hulp = stappen.hulp_bij_probleem(uitleg, self.logregels, self.log)
        if hulp["uri"]:
            time.sleep(3)  # VS Code eerst laten openen met de Mainframe-map
            stappen.open_uri(hulp["uri"])
            tekst = (" ".join(uitleg) + " In VS Code staat Claude voor je klaar met het probleem erin. "
                     "Druk daar op Enter, dan lost Claude het op.")
            klein = "Opent VS Code niet vanzelf? Klik dan op Laat Claude het oplossen. Lukt het Claude niet, volg dan deze stappen."
        else:
            tekst = " ".join(uitleg) + " Zo los je het op:"
            klein = ""
        self.log("Nog niet groen: " + " ".join(uitleg))
        self.vraag({
            "soort": "hulp", "titel": "Bijna klaar, nog één ding",
            "tekst": tekst,
            "stappen": stappenlijst,
            "knop": {"tekst": "Laat Claude het oplossen", "url": hulp["uri"]} if hulp["uri"] else None,
            "knop_klaar": "Verder",
            "klein": klein,
        }, klaar_als=stappen.hulp_klaar, wacht=1.0, maximaal=7 * 86400)


def lees_klembord_sleutel() -> Optional[str]:
    """Kijkt of er een Gemini-sleutel op het klembord staat. Leest niets anders terug."""
    s = systeem()
    if s == "mac":
        cmd = ["pbpaste"]
    elif s == "windows":
        cmd = ["powershell", "-NoProfile", "-Command", "Get-Clipboard"]
    else:
        cmd = ["wl-paste", "--no-newline"] if kern.vind("wl-paste") else ["xclip", "-selection", "clipboard", "-o"]
    code, uit = kern.stil(cmd, timeout=5)
    if code != 0 or not uit:
        return None
    m = GEMINI_PATROON.search(uit[:500])
    return m.group(0) if m else None


REGIE = Regie()


def antwoord_tekst(a: Dict) -> str:
    return str(a.get("waarde", ""))[:20000]
