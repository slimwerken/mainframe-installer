/* Jarvis wordt opgebouwd terwijl de installatie loopt.
 *
 * Bart, 4 oktober 2026: "mooie 3d visualisaties, alsof we een Jarvis opbouwen stap
 * voor stap". Het is hetzelfde hologram als in de app (jarvis-hologram.tsx, ontwerp A
 * dat Bart op 28 september koos): een doorzichtig blauw borstbeeld met een oranje
 * lichtrand. Hier wordt het van onder naar boven opgebouwd. Een dunne lichtlijn met
 * een ring eromheen schuift mee met de voortgang; wat nog moet komen staat er heel
 * zwak als schets. Bij "Ontmoet Jarvis" gaan de ogen open en praat hij, met de mond op
 * het echte geluid van de begroeting.
 *
 * Rustig, zoals Bart eist: geen flikkering, geen pulseren, geen drukke vlakken. Alles
 * beweegt langzaam en alleen als er iets verandert. Lukt 3D niet, dan geeft
 * maakHologram null terug en blijft de pagina zoals hij was.
 */
import * as THREE from "three";
import { GLTFLoader } from "./3d/loaders/GLTFLoader.js";
import { MeshoptDecoder } from "./3d/libs/meshopt_decoder.module.js";

/** Mannenstemmen van Gemini; de rest is een vrouwenstem (gelijk aan de app). */
const MANNENSTEMMEN = new Set(["charon", "puck", "fenrir", "orus", "enceladus", "iapetus", "umbriel", "algieba",
  "algenib", "rasalgethi", "alnilam", "schedar", "achird", "zubenelgenubi", "sadachbia", "sadaltager"]);
export function figuurVoorStem(stem) {
  return stem && MANNENSTEMMEN.has(String(stem).trim().toLowerCase()) ? "man" : "vrouw";
}

/** Het hologram-materiaal van de app, met de opbouw erbij. */
function hologramMateriaal(u, vulling) {
  const m = new THREE.MeshBasicMaterial({
    color: 0x6fd6ff, transparent: true, depthWrite: true, side: THREE.FrontSide, blending: THREE.AdditiveBlending,
  });
  m.onBeforeCompile = (s) => {
    Object.assign(s.uniforms, u);
    s.vertexShader = s.vertexShader
      .replace("#include <common>", "#include <common>\nvarying vec3 vN; varying vec3 vV; varying float vY;")
      .replace("#include <project_vertex>",
        `#include <project_vertex>
        #if defined( USE_ENVMAP ) || defined( USE_SKINNING )
          vN = normalize(normalMatrix * objectNormal);
        #else
          vN = normalize(normalMatrix * normal);
        #endif
        vV = normalize(-mvPosition.xyz); vY = (modelMatrix * vec4(transformed, 1.0)).y;`);
    s.fragmentShader = s.fragmentShader
      .replace("#include <common>",
        "#include <common>\nuniform float uAccent; uniform float uBouw; uniform float uSchouder; uniform float uLijn; varying vec3 vN; varying vec3 vV; varying float vY;")
      .replace("#include <dithering_fragment>", `#include <dithering_fragment>
        float facing = abs(dot(normalize(vN), normalize(vV)));
        float rand = pow(1.0 - facing, 1.7);
        float lijnen = 0.62 + 0.38 * step(0.5, fract(gl_FragCoord.y / 3.0));
        vec3 blauw = mix(vec3(0.36, 0.78, 1.0), vec3(0.85, 0.97, 1.0), rand * rand);
        vec3 oranje = vec3(0.88, 0.26, 0.12);
        vec3 kleur = mix(blauw, oranje * 1.5, clamp(uAccent * rand * rand * 1.4, 0.0, 0.85));
        float warm = smoothstep(uSchouder + 0.22, uSchouder, vY);
        kleur = mix(kleur, oranje * 1.35, warm * rand * 0.55);
        float alfa = (${vulling.toFixed(3)} + rand * 0.85) * lijnen;
        // Opbouw: onder de lijn staat Jarvis er al, erboven alleen een zwakke schets.
        float boven = vY - uBouw;
        float gebouwd = 1.0 - smoothstep(-0.004, 0.004, boven);
        // De schets: alleen de lichtrand, zwak en koel blauw, zodat je ziet wat er komt.
        vec3 schets = vec3(0.42, 0.78, 1.0);
        kleur = mix(schets, kleur, gebouwd);
        alfa = mix(rand * 0.28 * lijnen, alfa, gebouwd);
        float lijn = exp(-pow(boven / 0.007, 2.0)) * uLijn;
        kleur = mix(kleur, vec3(0.92, 0.98, 1.0), lijn);
        alfa = alfa + lijn * 0.5;
        gl_FragColor = vec4(kleur * alfa, alfa);`);
  };
  return m;
}

/** De lichtring die met de opbouw mee omhoog schuift. */
function maakRing(u) {
  const m = new THREE.ShaderMaterial({
    uniforms: { uLijn: u.uLijn },
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide,
    vertexShader: "varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }",
    fragmentShader: `uniform float uLijn; varying vec2 vUv;
      void main(){
        float r = length(vUv - 0.5) * 2.0;
        float ring = exp(-pow((r - 0.86) / 0.035, 2.0));
        float waas = smoothstep(0.95, 0.2, r) * 0.10;
        float a = (ring * 0.55 + waas) * uLijn;
        gl_FragColor = vec4(vec3(0.45, 0.84, 1.0) * a, a);
      }`,
  });
  const ring = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), m);
  ring.rotation.x = -Math.PI / 2;
  ring.renderOrder = 2;
  return ring;
}

const zacht = (t) => t * t * (3 - 2 * t);

export async function maakHologram(plek, opties = {}) {
  const proef = document.createElement("canvas");
  if (!proef.getContext("webgl2") && !proef.getContext("webgl")) return null;
  const rustig = matchMedia("(prefers-reduced-motion: reduce)").matches;

  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: "low-power" });
  renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
  renderer.setClearColor(0x000000, 0);
  renderer.domElement.className = "holo-doek";
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(22, 1, 0.05, 30);
  const u = { uAccent: { value: 0 }, uBouw: { value: -10 }, uSchouder: { value: 1.3 }, uLijn: { value: 1 } };

  const figuur = opties.figuur === "man" ? "man" : "vrouw";
  let gltf;
  try {
    gltf = await new GLTFLoader().setMeshoptDecoder(MeshoptDecoder).loadAsync(`assets/jarvis/${figuur}.glb`);
  } catch (_) {
    renderer.dispose();
    return null;
  }
  const model = gltf.scene;
  scene.add(model);
  model.updateMatrixWorld(true);
  const bot = (n) => model.getObjectByName(n);

  // Armen rustig langs het lijf (het figuur staat in T-houding).
  // Draaien om een as in de wereld, ook als de ouders van het bot zelf gedraaid staan.
  const draaiBot = (naam, as, hoek) => {
    const b = bot(naam);
    if (!b || !b.parent) return;
    const ouder = b.parent.getWorldQuaternion(new THREE.Quaternion());
    const wereld = new THREE.Quaternion().setFromAxisAngle(as, hoek);
    b.quaternion.premultiply(ouder.clone().invert().multiply(wereld).multiply(ouder));
    b.updateMatrixWorld(true);
  };
  const Z = new THREE.Vector3(0, 0, 1);
  const armHoek = (naam) => {
    const a = bot(naam), h = bot(naam.replace("Arm", "ForeArm"));
    if (!a || !h) return 0;
    const pa = a.getWorldPosition(new THREE.Vector3()), ph = h.getWorldPosition(new THREE.Vector3());
    return Math.atan2(ph.y - pa.y, Math.abs(ph.x - pa.x));
  };
  // Tot de bovenarm 78 graden onder de horizon hangt, wat de beginhouding ook is.
  draaiBot("LeftArm", Z, -(THREE.MathUtils.degToRad(78) + armHoek("LeftArm")) * Math.sign(bot("LeftForeArm") ? bot("LeftForeArm").getWorldPosition(new THREE.Vector3()).x || 1 : 1));
  draaiBot("RightArm", Z, (THREE.MathUtils.degToRad(78) + armHoek("RightArm")) * Math.sign(-(bot("RightForeArm") ? bot("RightForeArm").getWorldPosition(new THREE.Vector3()).x || -1 : -1)));
  model.updateMatrixWorld(true);

  const lijf = hologramMateriaal(u, 0.018);
  // Haar, wenkbrauwen en wimpers voller, anders valt het haar weg (app, 29 sep 2026).
  const haar = hologramMateriaal(u, 0.2);
  const gezichten = [];
  model.traverse((o) => {
    if (!o.isMesh) return;
    const m = /hair|ponytail|long0|short0|bob|braid|brow|lash/i.test(o.name) ? haar : lijf;
    o.material = Array.isArray(o.material) ? o.material.map(() => m) : m;
    o.frustumCulled = false;
    o.renderOrder = /eye|teeth|tooth|tongue|brow|lash|hair|ponytail|long0|bob|braid|beard/i.test(o.name) ? 1 : 0;
    if (o.morphTargetDictionary) gezichten.push(o);
  });
  const vorm = (naam, waarde) => {
    for (const g of gezichten) {
      const i = g.morphTargetDictionary[naam];
      if (i !== undefined) g.morphTargetInfluences[i] = waarde;
    }
  };

  // Maten uit het figuur zelf: hoofd, kruin en schouders.
  const p = new THREE.Vector3();
  const hoofdY = (bot("Head") ? bot("Head").getWorldPosition(p) : p.set(0, 1.6, 0)).y;
  const kruinY = (bot("HeadTop_End") ? bot("HeadTop_End").getWorldPosition(p) : p.set(0, hoofdY + 0.2, 0)).y;
  const schouderY = (bot("LeftArm") ? bot("LeftArm").getWorldPosition(p) : p.set(0, hoofdY - 0.2, 0)).y;
  u.uSchouder.value = schouderY;
  const onder = schouderY - 0.30;
  const boven = kruinY + 0.03;

  const ring = maakRing(u);
  scene.add(ring);

  // Camera: borstbeeld, iets boven ooghoogte zodat de ring een ellips wordt.
  let smal = false;
  const kader = () => {
    const b = plek.clientWidth || 1, h = plek.clientHeight || 1;
    renderer.setSize(b, h, false);
    camera.aspect = b / h;
    smal = camera.aspect < 0.85;
    const doelY = (kruinY + onder) / 2 + 0.03;
    const hoogte = kruinY - onder + 0.12;
    let afstand = hoogte / 2 / Math.tan(THREE.MathUtils.degToRad(camera.fov / 2));
    if (smal) afstand /= Math.max(0.55, camera.aspect / 0.85);
    camera.position.set(0, doelY + 0.2, afstand);
    camera.lookAt(0, doelY, 0);
    camera.updateProjectionMatrix();
  };
  let ro = new ResizeObserver(kader);
  ro.observe(plek);
  plek.appendChild(renderer.domElement);
  kader();

  // Toestand
  let doel = 0, getoond = 0;
  let wakker = 0, wakkerDoel = 0;
  let volgendeKnipper = 0, knipperTot = 0;
  let praatMeter = null, praatNiveau = 0;
  const buf = new Float32Array(1024);
  const hoofdBot = bot("Head");
  const hoofdRust = hoofdBot ? hoofdBot.quaternion.clone() : null;
  const draai = new THREE.Quaternion(), as = new THREE.Euler();
  let raf = 0, vorige = performance.now(), weg = false;
  let geluid = null;

  vorm("eyeBlinkLeft", 1);
  vorm("eyeBlinkRight", 1);

  const lus = (nu) => {
    raf = requestAnimationFrame(lus);
    if (document.hidden) return;
    const dt = Math.min(0.1, (nu - vorige) / 1000);
    vorige = nu;
    const t = nu / 1000;

    // Opbouw: langzaam naar het doel, nooit springen.
    getoond += (doel - getoond) * (1 - Math.pow(0.35, dt));
    const y = onder + getoond * (boven - onder);
    u.uBouw.value = y;
    const lijnZicht = 1 - zacht(Math.min(1, Math.max(0, (getoond - 0.97) / 0.03)));
    u.uLijn.value = lijnZicht;
    ring.position.y = y;
    ring.scale.setScalar(0.62 + 0.18 * Math.max(0, Math.min(1, (schouderY - y) / 0.3)));
    ring.visible = lijnZicht > 0.01;

    // Heel langzaam draaien en een klein beetje ademen; niet bij "minder beweging".
    if (!rustig) {
      model.rotation.y = 0.14 * Math.sin((t * Math.PI * 2) / 28);
      if (hoofdBot && hoofdRust) {
        as.set(0.025 * Math.sin(t * 0.45), 0.04 * Math.sin(t * 0.31 + 1), 0.015 * Math.sin(t * 0.23));
        hoofdBot.quaternion.copy(hoofdRust).multiply(draai.setFromEuler(as));
      }
    }

    // Ogen: dicht tijdens de opbouw, open bij de onthulling, daarna af en toe knipperen.
    wakker += (wakkerDoel - wakker) * (1 - Math.pow(0.25, dt));
    let oog = 1 - zacht(Math.min(1, wakker));
    if (wakkerDoel === 1 && wakker > 0.98) {
      if (!volgendeKnipper) volgendeKnipper = t + 2 + Math.random() * 3;
      if (t > volgendeKnipper) { knipperTot = t + 0.16; volgendeKnipper = t + 3 + Math.random() * 4; }
      if (t < knipperTot) oog = 1;
    }
    vorm("eyeBlinkLeft", oog);
    vorm("eyeBlinkRight", oog);

    // Praten: de mond op het echte geluid, het oranje komt op als Jarvis spreekt.
    let niveau = 0;
    if (praatMeter) {
      praatMeter.getFloatTimeDomainData(buf);
      let s = 0;
      for (let i = 0; i < buf.length; i++) s += buf[i] * buf[i];
      niveau = Math.sqrt(s / buf.length);
    }
    praatNiveau += (niveau - praatNiveau) * (niveau > praatNiveau ? 0.5 : 0.18);
    const mond = Math.min(0.55, praatNiveau * 5.5);
    vorm("jawOpen", mond * 0.6);
    vorm("viseme_aa", mond);
    u.uAccent.value += (Math.min(1, praatNiveau * 6) - u.uAccent.value) * 0.05;

    renderer.render(scene, camera);
  };
  raf = requestAnimationFrame(lus);

  return {
    figuur,
    /** 0 tot 1: hoe ver Jarvis is opgebouwd. */
    voortgang(fractie) {
      doel = Math.max(doel, Math.max(0, Math.min(1, Number(fractie) || 0)));
    },
    /** Alles af en ogen open. */
    wakker() {
      doel = 1;
      wakkerDoel = 1;
    },
    /** Meteen bij de klik aanroepen: dan mag de browser later geluid afspelen. */
    geluidKlaarzetten() {
      try {
        geluid = geluid || new (window.AudioContext || window.webkitAudioContext)();
        geluid.resume();
      } catch (_) { geluid = null; }
    },
    /** Laat Jarvis praten op dit geluid; klaar als het geluid stopt. */
    async praat(audio) {
      try {
        const ctx = geluid || new (window.AudioContext || window.webkitAudioContext)();
        const bron = ctx.createMediaElementSource(audio);
        const meter = ctx.createAnalyser();
        meter.fftSize = 2048;
        bron.connect(meter);
        meter.connect(ctx.destination);
        await ctx.resume();
        praatMeter = meter;
      } catch (_) { /* zonder meter praat hij toch, alleen zonder mond */ }
      await new Promise((klaar) => {
        audio.addEventListener("ended", klaar, { once: true });
        audio.addEventListener("error", klaar, { once: true });
        const p = audio.play();
        if (p && p.catch) p.catch(klaar);
      });
      praatMeter = null;
    },
    /** Zet het hologram in een andere plek op de pagina (voor de onthulling). */
    verplaats(nieuw) {
      ro.disconnect();
      plek = nieuw;
      plek.appendChild(renderer.domElement);
      ro = new ResizeObserver(kader);
      ro.observe(plek);
      kader();
    },
    stop() {
      if (weg) return;
      weg = true;
      cancelAnimationFrame(raf);
      ro.disconnect();
      renderer.dispose();
      renderer.domElement.remove();
    },
  };
}
