"""Gereedschap voor de installer: systeem herkennen, programma's vinden, opdrachten
draaien met een leesbaar logboek, downloaden en de eigen staat bewaren.

Alleen de standaardbibliotheek, en het moet draaien op Python 3.8 en nieuwer:
op een kale Mac is dat de 3.9 van Apple, op Windows de Python die het
startscript net installeerde.
"""
from __future__ import annotations

import json
import os
import platform
import re
import shutil
import ssl
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Callable, Dict, List, Optional

THUIS = Path.home()
WERKMAP = THUIS / ".mainframe-installer"
STAAT_BESTAND = WERKMAP / "staat.json"
SERVER = "https://api.slimwerken.ai"
USER_AGENT = "Mainframe-installer/1.0 (+https://slimwerken.ai/installeer)"

Log = Callable[[str], None]


class Fout(Exception):
    """Een fout met een uitleg die we zo aan de gebruiker kunnen laten zien."""

    def __init__(self, uitleg: str, wat_nu: str = ""):
        super().__init__(uitleg)
        self.uitleg = uitleg
        self.wat_nu = wat_nu


# ---------------------------------------------------------------------------
# Systeem
# ---------------------------------------------------------------------------

def systeem() -> str:
    s = platform.system().lower()
    if s == "darwin":
        return "mac"
    if s.startswith("win"):
        return "windows"
    return "linux"


def is_arm() -> bool:
    return platform.machine().lower() in ("arm64", "aarch64")


def systeem_naam() -> str:
    s = systeem()
    if s == "mac":
        versie = platform.mac_ver()[0] or ""
        return f"Mac ({'Apple-chip' if is_arm() else 'Intel'}, macOS {versie})".replace(" macOS )", ")")
    if s == "windows":
        return f"Windows {platform.release()}"
    return "Linux"


def extra_paden() -> List[str]:
    """Waar de programma's die we installeren terechtkomen. Komt achter PATH."""
    lijst = [THUIS / ".local" / "bin", THUIS / ".bun" / "bin", THUIS / ".cargo" / "bin"]
    if systeem() == "windows":
        local = Path(os.environ.get("LOCALAPPDATA", THUIS / "AppData" / "Local"))
        lijst += [
            Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Git" / "cmd",
            local / "Programs" / "Git" / "cmd",
            local / "Microsoft" / "WindowsApps",
            local / "Programs" / "Orca" / "resources" / "bin",
            Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Tailscale",
        ]
    elif systeem() == "mac":
        lijst += [Path("/opt/homebrew/bin"), Path("/usr/local/bin"),
                  Path("/Applications/Tailscale.app/Contents/MacOS")]
    return [str(p) for p in lijst]


def ververs_path() -> None:
    """Zet nieuw geinstalleerde mappen in PATH van dit proces (en dus van wat we starten)."""
    bestaand = [p for p in os.environ.get("PATH", "").split(os.pathsep) if p]
    nieuw = [p for p in extra_paden() if p not in bestaand]
    if systeem() == "windows":
        # Winget zet nieuwe paden in het register; lees ze terug zonder herstart.
        try:
            import winreg  # type: ignore
            for root, sub in ((winreg.HKEY_CURRENT_USER, "Environment"),
                              (winreg.HKEY_LOCAL_MACHINE,
                               r"SYSTEM\CurrentControlSet\Control\Session Manager\Environment")):
                try:
                    with winreg.OpenKey(root, sub) as k:
                        waarde = os.path.expandvars(winreg.QueryValueEx(k, "Path")[0])
                        for p in waarde.split(";"):
                            if p and p not in bestaand and p not in nieuw:
                                nieuw.append(p)
                except OSError:
                    pass
        except ImportError:
            pass
    os.environ["PATH"] = os.pathsep.join(bestaand + nieuw)


def vind(naam: str) -> Optional[str]:
    ververs_path()
    gevonden = shutil.which(naam)
    if gevonden:
        return gevonden
    if systeem() == "windows":
        for ext in (".exe", ".cmd", ".bat"):
            g = shutil.which(naam + ext)
            if g:
                return g
    return None


# ---------------------------------------------------------------------------
# Opdrachten draaien
# ---------------------------------------------------------------------------

_ANSI = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]|\x1b\][^\x07]*\x07|\r")
_GEHEIM = re.compile(r"(AIza[0-9A-Za-z_-]{20,}|sk-[A-Za-z0-9_-]{20,}|pcsk_[A-Za-z0-9_]{10,}|"
                     r"(?i:(token|secret|password|wachtwoord)\s*[=:]\s*)\S+)")


def schoon(regel: str) -> str:
    regel = _ANSI.sub("", regel).rstrip()
    return _GEHEIM.sub("[verborgen]", regel)


def draai(cmd: List[str], log: Optional[Log] = None, cwd: Optional[Path] = None,
          env: Optional[Dict[str, str]] = None, timeout: int = 1800,
          invoer: Optional[str] = None) -> tuple:
    """Draai een opdracht, stuur elke regel naar het logboek. Geeft (code, uitvoer)."""
    ververs_path()
    omgeving = dict(os.environ)
    if env:
        omgeving.update(env)
    vlaggen = 0
    if systeem() == "windows":
        vlaggen = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        p = subprocess.Popen(cmd, cwd=str(cwd) if cwd else None, env=omgeving,
                             stdin=subprocess.PIPE if invoer is not None else subprocess.DEVNULL,
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             creationflags=vlaggen)
    except FileNotFoundError:
        return 127, f"{cmd[0]} niet gevonden"
    regels: List[str] = []

    def lees():
        assert p.stdout is not None
        for ruw in iter(p.stdout.readline, b""):
            r = schoon(ruw.decode("utf-8", "replace"))
            if r:
                regels.append(r)
                if log:
                    log(r)

    t = threading.Thread(target=lees, daemon=True)
    t.start()
    if invoer is not None and p.stdin:
        try:
            p.stdin.write(invoer.encode())
            p.stdin.close()
        except OSError:
            pass
    try:
        p.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        p.kill()
        t.join(2)
        return 124, "\n".join(regels)
    t.join(5)
    return p.returncode, "\n".join(regels)


def stil(cmd: List[str], timeout: int = 20, cwd: Optional[Path] = None) -> tuple:
    """Kort iets vragen aan een programma, zonder logboek. Geeft (code, uitvoer)."""
    ververs_path()
    vlaggen = getattr(subprocess, "CREATE_NO_WINDOW", 0) if systeem() == "windows" else 0
    try:
        r = subprocess.run(cmd, capture_output=True, timeout=timeout, cwd=str(cwd) if cwd else None,
                           stdin=subprocess.DEVNULL, creationflags=vlaggen)
        return r.returncode, (r.stdout + r.stderr).decode("utf-8", "replace").strip()
    except (FileNotFoundError, PermissionError, OSError):
        return 127, ""
    except subprocess.TimeoutExpired:
        return 124, ""


def shell_script(url: str, log: Log, timeout: int = 1800, env: Optional[Dict[str, str]] = None) -> int:
    """Een officieel installatiescript draaien (curl ... | bash, of irm ... | iex)."""
    if systeem() == "windows":
        cmd = ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command",
               f"irm {url} | iex"]
    else:
        cmd = ["bash", "-c", f"curl -fsSL {url} | bash"]
    code, _ = draai(cmd, log, timeout=timeout, env=env)
    return code


# ---------------------------------------------------------------------------
# Internet
# ---------------------------------------------------------------------------

def _context() -> ssl.SSLContext:
    ctx = ssl.create_default_context()
    if systeem() == "mac":
        # De Python van Apple vertrouwt de systeemcertificaten soms niet; curl wel.
        for pad in ("/etc/ssl/cert.pem", "/private/etc/ssl/cert.pem"):
            if os.path.exists(pad):
                try:
                    ctx.load_verify_locations(pad)
                except ssl.SSLError:
                    pass
    return ctx


def http_json(url: str, data: Optional[dict] = None, timeout: int = 60,
              headers: Optional[Dict[str, str]] = None) -> dict:
    kop = {"User-Agent": USER_AGENT, "Accept": "application/json"}
    if headers:
        kop.update(headers)
    body = None
    if data is not None:
        body = json.dumps(data).encode()
        kop["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=body, headers=kop, method="POST" if body else "GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=_context()) as r:
            return json.loads(r.read().decode() or "{}")
    except urllib.error.HTTPError as e:
        try:
            d = json.loads(e.read().decode() or "{}")
            d["_status"] = e.code
            return d
        except Exception:
            return {"_status": e.code}
    except Exception as e:  # netwerk weg, DNS, certificaat
        raise Fout("Ik kan het internet niet bereiken.",
                   "Kijk of de wifi aan staat en probeer het opnieuw.") from e


def download(url: str, naar: Path, log: Optional[Log] = None, wat: str = "bestand") -> Path:
    """Downloaden met voortgang in het logboek. Probeert curl eerst (beste certificaten)."""
    naar.parent.mkdir(parents=True, exist_ok=True)
    tijdelijk = naar.with_suffix(naar.suffix + ".deel")
    curl = vind("curl")
    if curl:
        code, uit = draai([curl, "-fL", "--retry", "3", "--silent", "--show-error", "-A", USER_AGENT,
                           "-o", str(tijdelijk), url], None, timeout=3600)
        if code == 0 and tijdelijk.exists():
            tijdelijk.replace(naar)
            if log:
                log(f"{wat} binnen" + _grootte(naar))
            return naar
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=120, context=_context()) as r, open(tijdelijk, "wb") as f:
            totaal = int(r.headers.get("Content-Length") or 0)
            gedaan, laatst = 0, 0.0
            while True:
                blok = r.read(1 << 20)
                if not blok:
                    break
                f.write(blok)
                gedaan += len(blok)
                if log and totaal and time.time() - laatst > 2:
                    log(f"{wat}: {gedaan * 100 // totaal}%")
                    laatst = time.time()
    except Exception as e:
        raise Fout(f"Het downloaden van {wat} lukte niet.",
                   "Kijk of de wifi aan staat en probeer het opnieuw.") from e
    tijdelijk.replace(naar)
    if log:
        log(f"{wat} binnen" + _grootte(naar))
    return naar


def _grootte(pad: Path) -> str:
    mb = pad.stat().st_size / 1_000_000
    return f" ({mb:.0f} MB)" if mb >= 1 else ""


def mx_van(domein: str) -> str:
    """De mailserver van een domein, via DNS over HTTPS (werkt op elk systeem)."""
    try:
        d = http_json(f"https://cloudflare-dns.com/dns-query?name={domein}&type=MX",
                      headers={"Accept": "application/dns-json"}, timeout=10)
        return " ".join(a.get("data", "") for a in d.get("Answer", []) or []).lower()
    except Fout:
        return ""


# ---------------------------------------------------------------------------
# Staat
# ---------------------------------------------------------------------------

_slot = threading.Lock()


def lees_staat() -> dict:
    try:
        return json.loads(STAAT_BESTAND.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def zet_staat(**velden) -> dict:
    with _slot:
        staat = lees_staat()
        staat.update({k: v for k, v in velden.items()})
        WERKMAP.mkdir(parents=True, exist_ok=True)
        tijdelijk = STAAT_BESTAND.with_suffix(".tmp")
        tijdelijk.write_text(json.dumps(staat, indent=2, ensure_ascii=False), encoding="utf-8")
        tijdelijk.replace(STAAT_BESTAND)
        return staat


# ---------------------------------------------------------------------------
# .env-bestanden: alleen een regel zetten, nooit iets weggooien
# ---------------------------------------------------------------------------

def zet_env(bestand: Path, naam: str, waarde: str) -> None:
    bestand.parent.mkdir(parents=True, exist_ok=True)
    regels = bestand.read_text(encoding="utf-8").splitlines() if bestand.exists() else []
    patroon = re.compile(rf"^\s*(export\s+)?{re.escape(naam)}\s*=")
    nieuw, gezet = [], False
    for r in regels:
        if patroon.match(r):
            if not gezet:
                nieuw.append(f"{naam}={waarde}")
                gezet = True
            continue
        nieuw.append(r)
    if not gezet:
        nieuw.append(f"{naam}={waarde}")
    bestand.write_text("\n".join(nieuw) + "\n", encoding="utf-8")
    try:
        os.chmod(bestand, 0o600)
    except OSError:
        pass


def lees_env(bestand: Path, naam: str) -> str:
    try:
        for r in bestand.read_text(encoding="utf-8").splitlines():
            m = re.match(rf"^\s*(?:export\s+)?{re.escape(naam)}\s*=\s*(.*)$", r)
            if m:
                return m.group(1).strip().strip("'\"")
    except OSError:
        pass
    return ""


def python_versie(pad: str) -> tuple:
    code, uit = stil([pad, "-c", "import sys;print('%d.%d'%sys.version_info[:2])"])
    if code != 0:
        return (0, 0)
    try:
        a, b = uit.strip().splitlines()[-1].split(".")
        return (int(a), int(b))
    except ValueError:
        return (0, 0)


def open_in_browser(url: str) -> None:
    import webbrowser
    if systeem() == "mac":
        stil(["open", url])
    else:
        webbrowser.open(url)


def open_terminal(opdracht: str, map_: Optional[Path] = None) -> bool:
    """Open een zichtbaar terminalvenster met deze opdracht (voor inloggen)."""
    s = systeem()
    cd = f'cd "{map_}" && ' if map_ else ""
    if s == "mac":
        script = (f'tell application "Terminal" to do script "{cd}{opdracht}"\n'
                  'tell application "Terminal" to activate')
        return stil(["osascript", "-e", script])[0] == 0
    if s == "windows":
        cdw = f'Set-Location \\"{map_}\\"; ' if map_ else ""
        try:
            subprocess.Popen(["cmd", "/c", "start", "powershell", "-NoExit", "-Command", cdw + opdracht])
            return True
        except OSError:
            return False
    for term in (["x-terminal-emulator", "-e"], ["gnome-terminal", "--"], ["konsole", "-e"], ["xterm", "-e"]):
        if vind(term[0]):
            try:
                subprocess.Popen(term + ["bash", "-c", f"{cd}{opdracht}; exec bash"])
                return True
            except OSError:
                continue
    return False
