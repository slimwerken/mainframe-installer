/* Mainframe-installer: de voorkant. Eén startscherm, daarna loopt de installatie
   vanzelf (regie.py op de lokale server). Alleen als de gebruiker iets moet doen
   verschijnt er een kaart met één knop. Praat alleen met de server op deze
   computer, met de sleutel uit het adres na het hekje. */
(function () {
  "use strict";

  const SLEUTEL = (location.hash || "").slice(1);
  const scherm = document.getElementById("scherm");
  const kopRechts = document.getElementById("kopRechts");
  let BEGIN = {};
  let invoerOnthouden = {};
  let peil = null;
  let logVanaf = 0;
  let logTekst = "";
  let laatsteActie = "";
  let laatsteFase = "";
  let laatsteProcent = 0;
  let welkomStem = null;
  let holo = null;          // Jarvis in opbouw (hologram.js); null als 3D niet lukt
  let holoBezig = null;

  const $ = (sel, el) => (el || document).querySelector(sel);
  const $$ = (sel, el) => Array.from((el || document).querySelectorAll(sel));
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  const wacht = (ms) => new Promise((r) => setTimeout(r, ms));
  const VINK = '<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 6.2l2.4 2.4 4.6-5"/></svg>';

  async function api(pad, body) {
    const r = await fetch(pad, {
      method: body === undefined ? "GET" : "POST",
      headers: Object.assign({ "X-Wizard": SLEUTEL }, body === undefined ? {} : { "Content-Type": "application/json" }),
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw Object.assign(new Error(data.fout || "Dat lukte niet."), { data });
    return data;
  }

  function toon(html) {
    scherm.innerHTML = `<div class="inhoud">${html}</div>`;
  }

  function groetWoord() {
    const u = new Date().getHours();
    return u < 6 ? "Goedenacht" : u < 12 ? "Goedemorgen" : u < 18 ? "Goedemiddag" : "Goedenavond";
  }

  // ---------------------------------------------------------------- Jarvis in opbouw
  function startHolo() {
    const el = $("#holo");
    if (holo || holoBezig || !el) return;
    el.hidden = false;
    $("#podium").classList.add("met-holo");
    holoBezig = import("/assets/hologram.js")
      .then((m) => m.maakHologram($("#holoPlek"), {
        figuur: m.figuurVoorStem(BEGIN.stem),
        altijd: new URLSearchParams(location.search).get("3d") === "altijd",
        bijTraag: () => { holo = null; verbergHolo(); },
      }))
      .then((h) => { holo = h; if (!h) verbergHolo(); else holo.voortgang(laatsteProcent / 100); })
      .catch(() => verbergHolo());
  }

  function verbergHolo() {
    if (holo) holo.stop();
    holo = null; holoBezig = null;
    const el = $("#holo");
    if (el) { el.hidden = true; el.classList.remove("klein"); }
    $("#podium").classList.remove("met-holo");
  }

  // ---------------------------------------------------------------- startscherm
  function startscherm() {
    clearInterval(peil);
    verbergHolo();
    const al = BEGIN.mainframe_staat;
    let vast = BEGIN.vaste_computer === "ja";
    // Vanzelf starten staat standaard aan (Bart, 14 okt 2026); alleen een eerder nee blijft nee.
    let vanzelf = BEGIN.vanzelf !== "nee";
    kopRechts.textContent = BEGIN.systeem_naam || "";
    toon(`
      <h1>${al ? "Je Mainframe afmaken" : "Mainframe installeren"}</h1>
      <p class="sub">${al ? "Ik kijk wat er nog mist en maak het af." : "Vul dit in. De rest gaat vanzelf."}</p>
      <div class="veld"><label for="voornaam">Je voornaam</label>
        <input class="invoer" id="voornaam" autocomplete="given-name" value="${esc(BEGIN.voornaam)}"></div>
      <div class="veld"><label for="aanspreek">Jarvis praat over je als</label>
        <select class="invoer" id="aanspreek">
          <option value="" ${!BEGIN.aanspreek ? "selected" : ""}>neutraal</option>
          <option value="hij" ${BEGIN.aanspreek === "hij" ? "selected" : ""}>hij</option>
          <option value="zij" ${BEGIN.aanspreek === "zij" ? "selected" : ""}>zij</option>
        </select></div>
      ${al ? "" : `
      <div class="veld"><label for="code">Licentiecode</label>
        <input class="invoer code" id="code" placeholder="MF-XXXX-XXXX" autocomplete="off" spellcheck="false" value="${esc(BEGIN.code)}"></div>
      <div class="veld"><label for="email">E-mailadres van je aankoop</label>
        <input class="invoer" id="email" type="email" autocomplete="email" value="${esc(BEGIN.email)}"></div>
      <div class="oud-blok" id="oudBlok">
        <p id="oudTekst"></p>
        <div class="oud-knoppen">
          <button class="knop licht klein-knop" type="button" id="oudKies"></button>
          <button class="tekst-knop" type="button" id="oudWeg" hidden>Niet meenemen</button>
        </div>
        <button class="schakel" type="button" role="switch" id="meenemen" aria-checked="true" hidden>
          <span><b>Neem alles mee wat ik heb ingericht</b><small>Je skills, CLAUDE.md, kennis, projecten, klanten, scripts, verbindingen, wachtwoorden en automatiseringen. We kopieren alles; je oude map blijft precies zoals hij is.</small></span>
          <span class="knopje" aria-hidden="true"></span>
        </button>
      </div>
      <div class="veld"><label>Waar komt je Mainframe?</label>
        <div class="mapkeuze">
          <div class="map-pad" id="mapPad"></div>
          <button class="knop licht klein-knop" type="button" id="mapKies">Andere plek</button>
        </div>
        <p class="map-noot" id="mapNoot"></p>
        <p class="map-let-op">Niet in een gedeelde of gesynchroniseerde map, zoals OneDrive, iCloud Drive, Dropbox, Google Drive of een netwerkschijf. Kies een map op deze computer zelf.</p>
      </div>`}
      <button class="schakel" type="button" role="switch" id="vast" aria-checked="${vast}">
        <span><b>Deze computer blijft altijd aan</b><small>Dan werkt Jarvis ook als je weg bent.</small></span>
        <span class="knopje" aria-hidden="true"></span>
      </button>
      <button class="schakel" type="button" role="switch" id="vanzelf" aria-checked="${vanzelf}">
        <span><b>Jarvis start vanzelf als je je computer aanzet</b><small>Zet je dit uit, dan start je Jarvis na een herstart zelf met /app in Claude Code.</small></span>
        <span class="knopje" aria-hidden="true"></span>
      </button>
      <button class="uitleg-knop" type="button" id="uitlegKnop">Wat is het verschil?</button>
      <div class="uitleg" id="uitleg" hidden>
        <div><b>Blijft aan</b><ul><li>Jarvis op je telefoon, overal</li><li>Klussen lopen door als je weg bent</li><li>Automatiseringen ook 's nachts</li></ul></div>
        <div><b>Laptop</b><ul><li>Telefoon werkt alleen als de laptop open is</li><li>Een klus stopt bij dichtklappen</li><li>Automatiseringen slaan dan over</li></ul></div>
      </div>
      <button class="knop breed" type="button" id="installeer">${al ? "Afmaken" : "Installeren"}</button>
      <p class="melding-fout" id="startFout"></p>
      ${overzicht()}`);
    let gekozenMap = (BEGIN.map || {}).map || "";
    // Een oude Mainframe verhuist straks in de kennismaking van de app (Bart, 20 okt 2026).
    let oudeMap = (BEGIN.map || {}).oud || "";
    let meenemen = true;
    const toonOud = () => {
      if (!$("#oudBlok")) return;
      $("#oudTekst").innerHTML = oudeMap
        ? `<b>Je hebt al een Mainframe</b> in ${esc(kortPad(oudeMap))}. Geen probleem. Mainframe 2.0 komt in een nieuwe map ernaast. Je oude map raken we niet aan: we lezen hem alleen en kopieren wat je meeneemt. Gaat er iets mis, dan werkt je oude Mainframe gewoon nog.`
        : `<b>Heb je al een Mainframe?</b> Geen probleem. Wijs hem hier aan, dan nemen we alles wat je hebt ingericht mee naar Mainframe 2.0. Je oude map blijft precies zoals hij is.`;
      $("#oudKies").textContent = oudeMap ? "Een andere oude map" : "Ja, kies mijn Mainframe";
      $("#oudWeg").hidden = !oudeMap;
      $("#meenemen").hidden = !oudeMap;
    };
    toonOud();
    const toonMap = (m) => {
      if (!$("#mapPad")) return;
      gekozenMap = m.map || gekozenMap;
      // Een oude Mainframe gekozen als plek: die wordt de map om mee te nemen, 2.0 komt ernaast.
      if (m.oud) { oudeMap = m.oud; toonOud(); }
      $("#mapPad").textContent = kortPad(gekozenMap);
      $("#mapPad").title = gekozenMap;
      $("#mapNoot").textContent = m.gedeeld ? "" : m.bestaand ? "Hier staat al Mainframe 2.0. Die werken we bij; je eigen bestanden blijven zoals ze zijn." : "";
      $("#startFout").textContent = m.fout || (m.gedeeld ? `Die map staat in ${m.gedeeld}. ${BEGIN.gedeeld_uitleg || ""}` : "");
      $("#installeer").disabled = !!m.gedeeld;
    };
    if (BEGIN.map) toonMap(BEGIN.map);
    const mk = $("#mapKies");
    if (mk) mk.addEventListener("click", async () => {
      mk.disabled = true; mk.textContent = "Kies in het venster";
      try {
        const m = await api("/api/map/kies", {});
        if (m.geannuleerd) {
          // Geen mapvenster op deze computer: dan typen.
          const getypt = m.geen_venster ? prompt("Typ het pad van de map") : null;
          if (getypt) toonMap(await api("/api/map/controleer", { map: getypt }));
        } else toonMap(m);
      } catch (e) { $("#startFout").textContent = e.message; }
      mk.disabled = false; mk.textContent = "Andere plek";
    });
    const ok = $("#oudKies");
    if (ok) ok.addEventListener("click", async () => {
      ok.disabled = true;
      try {
        let m = await api("/api/map/oud", {});
        if (m.geannuleerd && m.geen_venster) {
          const getypt = prompt("Typ het pad van je oude Mainframe");
          m = getypt ? await api("/api/map/oud", { map: getypt }) : {};
        }
        if (m.fout) $("#startFout").textContent = m.fout;
        else if (m.oud) {
          oudeMap = m.oud;
          $("#startFout").textContent = "";
          // Stond de nieuwe map op de oude, dan komt 2.0 op de logische plek ernaast.
          if (!gekozenMap || gekozenMap === m.oud) toonMap({ map: m.doel, bestaand: false });
          toonOud();
        }
      } catch (e) { $("#startFout").textContent = e.message; }
      ok.disabled = false;
    });
    const ow = $("#oudWeg");
    if (ow) ow.addEventListener("click", () => { oudeMap = ""; toonOud(); });
    const mn = $("#meenemen");
    if (mn) mn.addEventListener("click", () => { meenemen = !meenemen; mn.setAttribute("aria-checked", String(meenemen)); });
    const s = $("#vast");
    s.addEventListener("click", () => { vast = !vast; s.setAttribute("aria-checked", String(vast)); });
    const vz = $("#vanzelf");
    vz.addEventListener("click", () => { vanzelf = !vanzelf; vz.setAttribute("aria-checked", String(vanzelf)); });
    $("#uitlegKnop").addEventListener("click", () => { const u = $("#uitleg"); u.hidden = !u.hidden; });
    $("#installeer").addEventListener("click", async () => {
      const invoer = {
        voornaam: $("#voornaam").value.trim(),
        code: ($("#code") || {}).value || "",
        email: ($("#email") || {}).value || "",
        vaste_computer: vast ? "ja" : "nee",
        vanzelf: vanzelf ? "ja" : "nee",
        aanspreek: ($("#aanspreek") || {}).value || "",
        map: al ? "" : gekozenMap,
        oud: al || oudeMap === gekozenMap ? "" : oudeMap,
        meenemen: meenemen ? "ja" : "nee",
      };
      if (!invoer.voornaam) { $("#startFout").textContent = "Vul je voornaam in."; return; }
      $("#installeer").disabled = true;
      try {
        await api("/api/regie/start", { invoer });
        invoerOnthouden = invoer;
        installatiescherm();
      } catch (e) {
        $("#startFout").textContent = e.message;
        $("#installeer").disabled = false;
      }
    });
    const eerste = $("input", scherm);
    if (eerste && !eerste.value) eerste.focus();
  }

  function kortPad(p) {
    const thuis = BEGIN.thuis || "";
    return thuis && p.startsWith(thuis) ? "~" + p.slice(thuis.length) : p;
  }

  // Wat er gaat gebeuren, voor je op Installeren klikt (12 okt 2026), met de principes en de 4 V's (13 okt).
  function overzicht() {
    const st = BEGIN.stappen || [];
    if (!st.length) return "";
    const principes = (BEGIN.principes || []).length ? `<section class="overzicht principes">
      <h2>Zo werkt je Mainframe</h2>
      <ul>${BEGIN.principes.map((p) => `<li>${esc(p)}</li>`).join("")}</ul>
      <div class="vier-v">${(BEGIN.vier_v || []).map(([v, w]) => `<div><b>${esc(v)}</b><span>${esc(w)}</span></div>`).join("")}</div>
    </section>` : "";
    const min = Math.round(st.reduce((t, s) => t + (s.seconden || 0), 0) / 60);
    return principes + `<section class="overzicht">
      <h2>Dit gaan we doen</h2>
      <p class="sub">Ongeveer ${Math.max(10, min)} minuten. Alleen als jij iets moet doen, vraag ik het.</p>
      <ol>${st.map((s) => `<li><b>${esc(s.titel)}</b><span>${esc(s.wat)}</span></li>`).join("")}</ol>
    </section>`;
  }

  // ---------------------------------------------------------------- installatiescherm
  function installatiescherm() {
    clearInterval(peil);
    laatsteActie = ""; laatsteFase = ""; logVanaf = 0; logTekst = "";
    toon(`
      <h1 id="titel">Je Mainframe wordt geïnstalleerd</h1>
      <p class="regel" id="regel">Even opstarten</p>
      <p class="wissel" id="wissel"></p>
      <div class="voortgang"><div class="balk"><div class="balk-vul" id="vul"></div></div>
        <div class="balk-tekst"><span id="procent">0%</span><span id="resterend"></span></div></div>
      <div id="kaart"></div>
      <ul class="lijst" id="lijst"></ul>
      <details class="details"><summary>Details</summary><div class="logboek" id="logboek"></div></details>`);
    startHolo();
    ververs();
    peil = setInterval(ververs, 900);
    // Tussendoor de principes en de 4 V's in beeld, rustig wisselend.
    const zinnen = BEGIN.wissel || [];
    let nr = 0;
    clearInterval(window.__wissel);
    const toonWissel = () => { const w = $("#wissel"); if (!w || !zinnen.length) return; w.classList.remove("in"); setTimeout(() => { w.textContent = zinnen[nr++ % zinnen.length]; w.classList.add("in"); }, 250); };
    toonWissel();
    window.__wissel = setInterval(toonWissel, 9000);
  }

  async function ververs() {
    let st;
    try { st = await api("/api/regie?vanaf=" + logVanaf); } catch (_) { return; }
    // voortgang
    $("#vul").style.width = st.procent + "%";
    $("#procent").textContent = st.procent + "%";
    laatsteProcent = st.procent;
    if (holo) holo.voortgang(st.procent / 100);
    $("#holo").classList.toggle("klein", st.fase === "actie" || st.fase === "fout");
    $("#holoLabel").textContent = st.fase === "klaar" ? "Jarvis · klaar" : "Jarvis · in opbouw";
    const min = Math.ceil((st.nog_seconden || 0) / 60);
    $("#resterend").textContent = st.fase === "klaar" ? "" : min > 1 ? `Nog ongeveer ${min} minuten` : "Bijna klaar";
    if (st.fase === "actie") $("#regel").textContent = "Daarna ga ik vanzelf verder.";
    else if (st.regel) $("#regel").textContent = st.regel;
    // stappen
    const stand = { wacht: "", bezig: "Bezig", actie: "Jij bent aan zet", klaar: "Klaar", overgeslagen: "Later", fout: "Niet gelukt" };
    $("#lijst").innerHTML = st.stappen.map((s) =>
      `<li data-s="${esc(s.status)}"><span class="ico">${VINK}</span><span class="naam">${esc(s.titel)}${
        (s.status === "bezig" || s.status === "actie") && s.wat ? `<small class="wat">${esc(s.wat)}</small>` : ""
      }</span><span class="stand">${esc(s.status === "overgeslagen" && s.notitie ? s.notitie : stand[s.status] || "")}</span></li>`).join("");
    // logboek
    if (st.log && st.log.length) {
      logVanaf = st.log_aantal;
      logTekst += st.log.join("\n") + "\n";
      const lb = $("#logboek"); lb.textContent = logTekst; lb.scrollTop = lb.scrollHeight;
    }
    // fase
    if (st.fase === "actie" && st.actie) {
      const sleutelActie = JSON.stringify(st.actie);
      if (sleutelActie !== laatsteActie) { laatsteActie = sleutelActie; tekenActie(st.actie); }
      $("#titel").textContent = "Jij bent even aan zet";
    } else if (st.fase === "fout") {
      if (laatsteFase !== "fout") tekenFout(st.fout || {});
      $("#titel").textContent = "Even een probleem";
    } else if (st.fase === "klaar") {
      clearInterval(peil);
      klaarscherm(st);
    } else {
      if (laatsteActie) { $("#kaart").innerHTML = ""; laatsteActie = ""; }
      if (laatsteFase === "fout") $("#kaart").innerHTML = "";
      $("#titel").textContent = "Je Mainframe wordt geïnstalleerd";
    }
    laatsteFase = st.fase;
  }

  function tekenActie(a) {
    const knop = a.knop && a.knop.url
      ? `<a class="knop" href="${esc(a.knop.url)}" target="_blank" rel="noopener">${esc(a.knop.tekst)}</a>` : "";
    const knop2 = a.knop2 && a.knop2.url
      ? `<a class="knop" href="${esc(a.knop2.url)}" target="_blank" rel="noopener">${esc(a.knop2.tekst)}</a>` : "";
    const keuzes = (a.keuzes || []).map((k, i) =>
      `<button class="knop ${i ? "licht" : ""}" type="button" data-keuze="${esc(k.id)}">${esc(k.tekst)}</button>`).join("");
    const qrs = (a.qr || []).map((q, i) => `<div class="qr"><div id="qr${i}"></div>${esc(q.tekst)}</div>`).join("");
    const klaarKnop = a.knop_klaar ? `<button class="knop licht" type="button" data-klaar>${esc(a.knop_klaar)}</button>` : "";
    const overslaan = a.overslaan ? `<button class="tekstknop" type="button" data-overslaan>${esc(a.overslaan)}</button>` : "";
    const lang = a.invoer && a.invoer.veld === "geheugen";
    const invoer = !a.invoer ? "" : a.invoer.geheim ? `
      <div class="plak"><input class="invoer" id="plakveld" type="password" autocomplete="current-password" placeholder="${esc(a.invoer.label)}">
        <button class="knop" type="button" data-plak>Koppelen</button></div>` : lang ? `
      <div class="plak lang"><textarea class="invoer" id="plakveld" rows="6" placeholder="${esc(a.invoer.label)}"></textarea>
        <button class="knop" type="button" data-plak>Meenemen</button></div>` : `
      <button class="tekstknop" type="button" data-plakopen>${esc(a.invoer.label)}</button>
      <div class="plak" hidden><input class="invoer" id="plakveld" autocomplete="off" spellcheck="false">
        <button class="knop" type="button" data-plak>Verstuur</button></div>`;
    // Sleutels veilig (25 okt 2026): de hoofdsleutel een keer tonen, met Kopieer en een vinkje.
    const sleutelvak = a.sleutel ? `<div class="sleutelvak"><code id="hoofdsleutel">${esc(a.sleutel)}</code>
      <button class="knop" type="button" data-kopieer>Kopieer</button></div>` : "";
    const vinkje = a.vinkje ? `<label class="vinkje"><input type="checkbox" id="bewaardvink"> <span>${esc(a.vinkje)}</span></label>` : "";
    $("#kaart").innerHTML = `<div class="actie">
      <h2>${esc(a.titel)}</h2><p>${esc(a.tekst)}</p>${sleutelvak}${vinkje}
      ${(a.stappen || []).length ? `<ol class="kaart-stappen">${a.stappen.map((s) => `<li>${esc(s)}</li>`).join("")}</ol>` : ""}
      ${qrs ? `<div class="qrs">${qrs}</div>` : ""}
      <div class="rij">${knop}${knop2}${keuzes}${klaarKnop}${overslaan}</div>
      ${invoer}
      ${a.klein ? `<p class="klein">${esc(a.klein)}</p>` : ""}
      ${a.link && a.link.url ? `<p class="klein"><a href="${esc(a.link.url)}" target="_blank" rel="noopener">${esc(a.link.tekst)}</a></p>` : ""}
    </div>`;
    (a.qr || []).forEach((q, i) => tekenQr($("#qr" + i), q.url));
    $$("[data-keuze]").forEach((b) => b.addEventListener("click", () => stuur({ soort: "keuze", waarde: b.dataset.keuze }, b)));
    const k = $("[data-klaar]"); if (k) k.addEventListener("click", () => stuur({ soort: "klaar" }, k));
    const vink = $("#bewaardvink");
    if (vink && k) { k.disabled = true; vink.addEventListener("change", () => { k.disabled = !vink.checked; }); }
    const kop = $("[data-kopieer]");
    if (kop) kop.addEventListener("click", async () => {
      const tekst = $("#hoofdsleutel").textContent;
      try { await navigator.clipboard.writeText(tekst); } catch (_) {
        const r = document.createRange(); r.selectNodeContents($("#hoofdsleutel"));
        const s = getSelection(); s.removeAllRanges(); s.addRange(r); document.execCommand("copy");
      }
      kop.textContent = "Gekopieerd"; setTimeout(() => { kop.textContent = "Kopieer"; }, 1800);
    });
    const o = $("[data-overslaan]"); if (o) o.addEventListener("click", () => stuur({ soort: "overslaan" }, o));
    const po = $("[data-plakopen]");
    if (po) po.addEventListener("click", () => { po.hidden = true; $(".plak").hidden = false; $("#plakveld").focus(); });
    const pl = $("[data-plak]");
    if (pl) pl.addEventListener("click", () => {
      const v = $("#plakveld").value.trim(); if (!v) return;
      stuur({ soort: a.invoer.veld, waarde: v }, pl);
    });
    const kaartKnop = $(".actie .knop"); if (kaartKnop) kaartKnop.focus({ preventScroll: true });
  }

  async function stuur(antwoord, knop) {
    if (knop) { knop.disabled = true; knop.textContent = "Even geduld"; }
    try { await api("/api/regie/antwoord", antwoord); } catch (_) {}
  }

  function tekenFout(f) {
    $("#kaart").innerHTML = `<div class="foutkaart"><h2>${esc(f.uitleg || "Er ging iets mis.")}</h2>
      <p>${esc(f.wat_nu || "")}</p><button class="knop" type="button" id="opnieuw">Opnieuw proberen</button></div>`;
    $("#opnieuw").addEventListener("click", async () => {
      $("#opnieuw").disabled = true;
      try { await api("/api/regie/start", { invoer: invoerOnthouden }); } catch (e) { startscherm(); }
    });
  }

  function tekenQr(el, tekst) {
    if (!el || !tekst || typeof qrcode !== "function") return;
    const q = qrcode(0, "M"); q.addData(tekst); q.make();
    el.innerHTML = q.createSvgTag({ cellSize: 4, margin: 0, scalable: true });
  }

  // ---------------------------------------------------------------- klaar
  async function klaarscherm(st) {
    if (holo) holo.voortgang(1);
    // De 4 V's per week open (31 okt 2026): een cursus vanaf november begint zonder Jarvis. Dan geen
    // onthulling, maar meteen de app bij Verstand, met de korte kennismaking in een venster.
    if (st.verstand) {
      $("#titel").textContent = "Klaar. Alles staat.";
      $("#regel").textContent = "Je Mainframe staat klaar.";
      $("#resterend").textContent = "";
      $("#kaart").innerHTML = `<div class="rij" style="margin-bottom:26px"><button class="knop breed" type="button" id="naarVerstand" style="margin-top:0">Open je Mainframe</button></div>`
        + `<p class="sub" style="margin-top:0">Je begint bij Verstand: je koppelt Apify en je Mainframe leert je kennen. Elke week van de cursus komt er iets bij.</p>`;
      $("#naarVerstand").addEventListener("click", () => { location.href = st.verstand; });
      return;
    }
    try {
      const r = await fetch("/api/welkom", { headers: { "X-Wizard": SLEUTEL } });
      if (r.ok) welkomStem = new Audio(URL.createObjectURL(await r.blob()));
    } catch (_) { welkomStem = null; }
    $("#titel").textContent = "Klaar. Alles staat.";
    $("#regel").textContent = "Jarvis is er klaar voor.";
    $("#resterend").textContent = "";
    // Onboarding (19 okt 2026): na Ontmoet Jarvis opent de app de kennismaking in een modal:
    // verbindingen, Leer mij kennen, je eerste klus, iets dat vanzelf gaat en Orca.
    let metOnboarding = st.jarvis || "";
    try { if (st.jarvis) { const u = new URL(st.jarvis); u.searchParams.set("onboarding", "1"); metOnboarding = u.href; } } catch (_) { metOnboarding = st.jarvis || ""; }
    $("#kaart").innerHTML = `<div class="rij" style="margin-bottom:26px"><button class="knop breed" type="button" id="ontmoet" style="margin-top:0">Ontmoet Jarvis</button></div>`
      + `<p class="sub" style="margin-top:0">Daarna zet Jarvis je Mainframe samen met je klaar: wat hij nodig heeft, wat hij over je moet weten en je eerste klus. Een kwartiertje.</p>`;
    $("#ontmoet").addEventListener("click", () => onthul(metOnboarding));
  }

  async function onthul(jarvisUrl) {
    if (holo) return onthulMetHolo(jarvisUrl);
    const o = document.getElementById("onthulling");
    document.getElementById("groet").textContent = `${groetWoord()}${BEGIN.voornaam || invoerOnthouden.voornaam ? ", " + (invoerOnthouden.voornaam || BEGIN.voornaam) : ""}.`;
    document.getElementById("groetSub").textContent = "Zo zetten we samen je Mainframe klaar.";
    o.setAttribute("aria-hidden", "false");
    o.dataset.aan = "1";
    await wacht(900);
    o.dataset.fase = "1";
    let duur = 0;
    if (welkomStem) {
      const d = welkomStem.duration;
      duur = isFinite(d) && d > 0 ? d * 1000 : 8000;
      try { const p = welkomStem.play(); if (p && p.catch) p.catch(() => {}); } catch (_) { duur = 0; }
    }
    const eerste = duur ? Math.min(Math.max(3000, duur * 0.55), 6000) : 3000;
    await wacht(eerste);
    o.dataset.fase = "2";
    await wacht(duur ? Math.max(2600, duur - eerste + 900) : 2600);
    o.classList.add("vertrek");
    await wacht(700);
    location.href = jarvisUrl || "about:blank";
  }

  // Jarvis zelf: het opgebouwde hologram komt groot in beeld, doet zijn ogen open
  // en spreekt de begroeting uit, met de mond op het echte geluid.
  async function onthulMetHolo(jarvisUrl) {
    const o = document.getElementById("onthulling");
    holo.geluidKlaarzetten();
    const naam = invoerOnthouden.voornaam || BEGIN.voornaam;
    document.getElementById("groet").textContent = `${groetWoord()}${naam ? ", " + naam : ""}.`;
    document.getElementById("groetSub").textContent = "Zo zetten we samen je Mainframe klaar.";
    o.dataset.holo = "1";
    o.setAttribute("aria-hidden", "false");
    o.dataset.aan = "1";
    await wacht(900);
    holo.verplaats(document.getElementById("holoGroot"));
    o.dataset.fase = "1";
    await wacht(700);
    holo.wakker();
    await wacht(1700);
    if (welkomStem) await holo.praat(welkomStem);
    else await wacht(2500);
    o.dataset.fase = "2";
    await wacht(2800);
    o.classList.add("vertrek");
    await wacht(700);
    location.href = jarvisUrl || "about:blank";
  }

  // ---------------------------------------------------------------- start
  async function start() {
    if (!SLEUTEL) {
      toon(`<h1>Open de installatie opnieuw</h1><p class="sub">Dit adres mist zijn sleutel. Start de installatie opnieuw.</p>`);
      return;
    }
    try {
      BEGIN = await api("/api/begin");
    } catch (_) {
      toon(`<h1>Even geen verbinding</h1><p class="sub">De installatie draait niet meer. Start hem opnieuw en laad deze pagina opnieuw.</p>`);
      return;
    }
    kopRechts.textContent = BEGIN.systeem_naam || "";
    const r = BEGIN.regie || {};
    if (r.fase && r.fase !== "start") installatiescherm(); else startscherm();
  }
  start();
})();
