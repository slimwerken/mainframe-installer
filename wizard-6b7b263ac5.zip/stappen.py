"""De stappen van de installer. Elke stap kan zichzelf controleren (staat het er
al, werkt het?) en kan zijn werk doen. Controleren kijkt altijd naar de echte
computer, niet alleen naar wat we onthouden: zo is de wizard later veilig
opnieuw te draaien, bijvoorbeeld alleen voor de Outlook-koppeling.
"""
from __future__ import annotations

import io
import json
import os
import platform
import re
import shutil
import subprocess
import socket
import tempfile
import threading
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path
from typing import Callable, Dict, List, Optional

from kern import (SERVER, THUIS, WERKMAP, Fout, Log, download, draai, http_json, is_arm, lees_env,
                  lees_staat, mx_van, open_in_browser, open_terminal, python_versie, shell_script,
                  stil, systeem, systeem_naam, vind, zet_env, zet_staat)

STARTER_ZIP = "https://github.com/slimwerken/mainframe-starter/archive/refs/heads/main.zip"
ORCA_DOWNLOAD = "https://github.com/stablyai/orca/releases/latest/download/"
APP_POORT = 8081
PROFIEL_BLOK = "# >>> Mainframe-installer >>>"


def mainframe_map() -> Optional[Path]:
    p = lees_staat().get("map")
    return Path(p) if p else None


def app_map() -> Optional[Path]:
    m = mainframe_map()
    return m / ".mainframe" / "app" if m else None


def python_cmd() -> List[str]:
    """De Python waarmee we scripts in de Mainframe-map draaien (3.10 of nieuwer)."""
    for naam in ("python3.12", "python3.13", "python3", "python", "py"):
        pad = vind(naam)
        if pad and python_versie(pad) >= (3, 10):
            return [pad]
    import sys
    return [sys.executable]


# ---------------------------------------------------------------------------
# Status: wat een controle teruggeeft
# ---------------------------------------------------------------------------

def klaar(tekst: str, **extra) -> dict:
    return {"status": "klaar", "tekst": tekst, **extra}


def open_(tekst: str, **extra) -> dict:
    return {"status": "open", "tekst": tekst, **extra}


def wacht(tekst: str, **extra) -> dict:
    return {"status": "wacht", "tekst": tekst, **extra}


def overgeslagen(tekst: str, **extra) -> dict:
    return {"status": "overgeslagen", "tekst": tekst, **extra}


# ---------------------------------------------------------------------------
# Stap 1: welkom
# ---------------------------------------------------------------------------

def check_welkom() -> dict:
    s = lees_staat()
    if s.get("voornaam") and s.get("vaste_computer") in ("ja", "nee"):
        return klaar(f"Welkom, {s['voornaam']}.", systeem=systeem_naam())
    return open_("Nog niet begonnen.", systeem=systeem_naam())


def doe_welkom(invoer: dict, log: Log) -> dict:
    naam = str(invoer.get("voornaam", "")).strip()[:40]
    vast = invoer.get("vaste_computer")
    if not naam:
        raise Fout("Vul je voornaam in, dan weet Jarvis hoe hij je moet noemen.")
    if vast not in ("ja", "nee"):
        raise Fout("Kies of dit een vaste computer is.")
    zet_staat(voornaam=naam.split()[0].capitalize(), vaste_computer=vast)
    log(f"Genoteerd: {naam}, vaste computer: {vast}")
    return {}


# ---------------------------------------------------------------------------
# Stap 2: basisprogramma's
# ---------------------------------------------------------------------------

def _git_ok() -> bool:
    if systeem() == "mac" and stil(["xcode-select", "-p"])[0] != 0:
        return False
    g = vind("git")
    return bool(g) and stil([g, "--version"])[0] == 0


def _python_ok() -> bool:
    return any(python_versie(p) >= (3, 10)
               for p in filter(None, (vind("python3.12"), vind("python3"), vind("python"))))


def _bun_ok() -> bool:
    b = vind("bun")
    return bool(b) and stil([b, "--version"])[0] == 0


def _uv_ok() -> bool:
    return bool(vind("uv"))


def check_basis() -> dict:
    onderdelen = {"git": _git_ok(), "python": _python_ok(), "uv": _uv_ok(), "bun": _bun_ok()}
    mist = [k for k, v in onderdelen.items() if not v]
    if not mist:
        return klaar("Alles staat erop.", onderdelen=onderdelen)
    return open_("Nog niet alles staat erop.", onderdelen=onderdelen)


def _profiel_pad() -> None:
    """Zorg dat ~/.local/bin en ~/.bun/bin ook in een nieuw terminalvenster werken."""
    if systeem() == "windows":
        return
    blok = (f"\n{PROFIEL_BLOK}\nexport PATH=\"$HOME/.local/bin:$HOME/.bun/bin:$PATH\"\n"
            "# <<< Mainframe-installer <<<\n")
    for naam in (".zprofile", ".zshrc", ".bash_profile", ".bashrc", ".profile"):
        pad = THUIS / naam
        if naam in (".zprofile", ".zshrc") and systeem() != "mac" and not pad.exists():
            continue
        if naam in (".bash_profile", ".profile") and not pad.exists():
            continue
        try:
            inhoud = pad.read_text() if pad.exists() else ""
            if PROFIEL_BLOK not in inhoud:
                pad.write_text(inhoud + blok)
        except OSError:
            pass


def doe_basis(invoer: dict, log: Log) -> dict:
    s = systeem()
    # Git (en op de Mac ook Python 3.9 van Apple)
    if not _git_ok():
        if s == "mac":
            log("Apple's ontwikkelgereedschap installeren. Er komt een venster: klik op Installeer.")
            stil(["xcode-select", "--install"])
            einde = time.time() + 45 * 60
            while time.time() < einde and not _git_ok():
                time.sleep(10)
                log("Wachten tot Apple klaar is met installeren...")
            if not _git_ok():
                raise Fout("Het ontwikkelgereedschap van Apple staat er nog niet.",
                           "Rond het venster van Apple af en klik hier opnieuw.")
        elif s == "windows":
            log("Git installeren...")
            code, _ = draai(["winget", "install", "--id", "Git.Git", "-e", "--silent",
                             "--accept-package-agreements", "--accept-source-agreements"], log)
            if not _git_ok():
                raise Fout("Git kon niet geinstalleerd worden.",
                           "Installeer Git via git-scm.com/download/win en klik daarna opnieuw.")
        else:
            raise Fout("Git ontbreekt op deze computer.",
                       "Open een terminal en typ: sudo apt install -y git unzip curl. Klik daarna opnieuw.")
    log("Git staat erop.")

    if not _uv_ok():
        log("uv installeren (houdt Python netjes bij)...")
        url = "https://astral.sh/uv/install.ps1" if s == "windows" else "https://astral.sh/uv/install.sh"
        if shell_script(url, log, env={"UV_NO_MODIFY_PATH": "0"}) != 0 or not _uv_ok():
            raise Fout("uv kon niet geinstalleerd worden.", "Kijk of de wifi aan staat en probeer het opnieuw.")
    log("uv staat erop.")

    if not _python_ok():
        log("Python 3.12 installeren...")
        uv = vind("uv")
        draai([uv, "python", "install", "3.12", "--default"], log, timeout=1800)
        if not _python_ok():
            draai([uv, "python", "install", "3.12", "--default", "--preview"], log, timeout=1800)
        if not _python_ok():
            raise Fout("Python kon niet geinstalleerd worden.", "Probeer het nog een keer.")
    log("Python staat erop.")

    if not _bun_ok():
        if s == "linux" and not vind("unzip"):
            raise Fout("Voor Bun is unzip nodig.", "Typ in een terminal: sudo apt install -y unzip. Klik daarna opnieuw.")
        log("Bun installeren (laat de app draaien)...")
        url = "https://bun.sh/install.ps1" if s == "windows" else "https://bun.sh/install"
        if shell_script(url, log) != 0 or not _bun_ok():
            raise Fout("Bun kon niet geinstalleerd worden.", "Kijk of de wifi aan staat en probeer het opnieuw.")
    log("Bun staat erop.")
    _profiel_pad()
    return {}


# ---------------------------------------------------------------------------
# Stap 3: Claude Code
# ---------------------------------------------------------------------------

def _claude() -> Optional[str]:
    for kandidaat in (vind("claude"), str(THUIS / ".local" / "bin" / "claude"),
                      str(THUIS / ".claude" / "local" / "claude")):
        if kandidaat and Path(kandidaat).exists():
            return kandidaat
    return None


def claude_ingelogd() -> Optional[dict]:
    # Alleen in de testmachines van /installer-test (Windows en Linux hebben daar geen Claude-account):
    # de test zet dit bestand neer zodra de inlogkaart verschijnt, zodat de rest van de route ook
    # getest wordt (13 okt 2026). Zonder MAINFRAME_INSTALLER_TEST telt het nooit.
    if os.environ.get("MAINFRAME_INSTALLER_TEST") and (WERKMAP / "test-claude-ingelogd").exists():
        return {"loggedIn": True, "email": "test@voorbeeld.nl", "subscriptionType": "max"}
    c = _claude()
    if not c:
        return None
    code, uit = stil([c, "auth", "status", "--json"], timeout=20)
    try:
        d = json.loads(uit[uit.index("{"):])
    except (ValueError, json.JSONDecodeError):
        return None
    return d if d.get("loggedIn") else None


def check_claude() -> dict:
    if not _claude():
        return open_("Claude Code staat er nog niet op.", geinstalleerd=False, ingelogd=False)
    info = claude_ingelogd()
    if not info:
        return open_("Claude Code staat erop. Nog inloggen.", geinstalleerd=True, ingelogd=False)
    abo = {"max": "Max", "pro": "Pro", "team": "Team", "enterprise": "Enterprise"}.get(
        str(info.get("subscriptionType", "")).lower(), "")
    wie = info.get("email") or "je account"
    return klaar(f"Ingelogd als {wie}" + (f" ({abo})" if abo else "") + ".",
                 geinstalleerd=True, ingelogd=True)


def _onboarding_klaar() -> None:
    """Sla de eerste-keer-vragen van Claude Code over (thema, uitleg)."""
    pad = THUIS / ".claude.json"
    try:
        data = json.loads(pad.read_text()) if pad.exists() else {}
    except (OSError, ValueError):
        return
    gewijzigd = False
    for k, v in (("hasCompletedOnboarding", True), ("theme", "dark")):
        if k not in data:
            data[k] = v
            gewijzigd = True
    if gewijzigd:
        pad.write_text(json.dumps(data, indent=2))


def vertrouw_map(map_: Path) -> None:
    """Claude Code vraagt anders bij de eerste start of je deze map vertrouwt."""
    pad = THUIS / ".claude.json"
    try:
        data = json.loads(pad.read_text()) if pad.exists() else {}
    except (OSError, ValueError):
        return
    projecten = data.setdefault("projects", {})
    p = projecten.setdefault(str(map_), {})
    p["hasTrustDialogAccepted"] = True
    p.setdefault("hasCompletedProjectOnboarding", True)
    pad.write_text(json.dumps(data, indent=2))


def doe_claude(invoer: dict, log: Log) -> dict:
    actie = invoer.get("actie", "installeer")
    if not _claude():
        log("Claude Code installeren met de officiële installer van Anthropic...")
        url = "https://claude.ai/install.ps1" if systeem() == "windows" else "https://claude.ai/install.sh"
        # Anthropic's download hapert soms even (gezien 4 okt 2026 op Windows: ECONNRESET
        # bij downloads.claude.ai). Drie pogingen voordat de klant een foutkaart ziet.
        for poging in range(1, 4):
            if poging > 1:
                time.sleep(15 * (poging - 1))
                log(f"Claude Code opnieuw ophalen (poging {poging} van 3)...")
            shell_script(url, log, timeout=1800)
            if _claude():
                break
        if not _claude():
            raise Fout("Claude Code kon niet geinstalleerd worden.", "Kijk of de wifi aan staat en probeer het opnieuw.")
        log("Claude Code staat erop.")
    _onboarding_klaar()
    if claude_ingelogd():
        log("Je bent al ingelogd.")
        return {}
    if actie in ("installeer", "login"):
        return _claude_login(log)
    # "alleen_installeren": voor tests op een computer zonder browser.
    return {}


_LOGIN: Dict[str, object] = {}


def claude_code_invoer(code: str) -> bool:
    """De code die Claude na het inloggen laat zien, doorgeven aan het lopende inloggen."""
    proces = _LOGIN.get("proces")
    code = re.sub(r"\s+", "", code or "")
    if not proces or not code or getattr(proces, "poll")() is not None:
        return False
    try:
        proces.stdin.write((code + "\n").encode())  # type: ignore[attr-defined]
        proces.stdin.flush()  # type: ignore[attr-defined]
        return True
    except OSError:
        return False


def _claude_login(log: Log) -> dict:
    """Inloggen zonder terminal: Claude opent zelf de browser. Lukt dat terugkoppelen
    niet vanzelf, dan laat de wizard de link zien en plakt de gebruiker de code."""
    import subprocess
    import threading
    c = _claude()
    oud = _LOGIN.get("proces")
    if oud and getattr(oud, "poll")() is None:
        oud.kill()  # type: ignore[attr-defined]
    vlaggen = getattr(subprocess, "CREATE_NO_WINDOW", 0) if systeem() == "windows" else 0
    proces = subprocess.Popen([c, "auth", "login", "--claudeai"], stdin=subprocess.PIPE,
                              stdout=subprocess.PIPE, stderr=subprocess.STDOUT, creationflags=vlaggen)
    _LOGIN["proces"] = proces
    uitvoer: List[str] = []

    def lees():
        for ruw in iter(proces.stdout.readline, b""):  # type: ignore[union-attr]
            regel = ruw.decode("utf-8", "replace").strip()
            uitvoer.append(regel)
            m = re.search(r"https://\S+oauth/authorize\S+", regel)
            if m:
                log("§login " + m.group(0))

    threading.Thread(target=lees, daemon=True).start()
    log("Je browser opent de inlogpagina van Claude. Log daar in met je eigen account.")
    einde = time.time() + 20 * 60
    while time.time() < einde:
        time.sleep(2)
        if claude_ingelogd():
            if proces.poll() is None:
                proces.terminate()
            log("Ingelogd.")
            return {}
        if proces.poll() is not None and not claude_ingelogd():
            fout = " ".join(uitvoer).lower()
            if "failed" in fout or "invalid" in fout or "400" in fout:
                raise Fout("Claude accepteerde de code niet.",
                           "Klik opnieuw en plak de hele code die Claude laat zien, zonder spaties ervoor of erachter.")
            raise Fout("Het inloggen lukte niet.", "Klik opnieuw om het nog eens te proberen.")
    proces.kill()
    raise Fout("Het inloggen is nog niet afgerond.", "Klik opnieuw om het nog eens te proberen.")


# ---------------------------------------------------------------------------
# Stap 4: Orca
# ---------------------------------------------------------------------------

def orca_app() -> Optional[Path]:
    s = systeem()
    if s == "mac":
        for p in (Path("/Applications/Orca.app"), THUIS / "Applications" / "Orca.app"):
            if p.exists():
                return p
    elif s == "windows":
        local = Path(os.environ.get("LOCALAPPDATA", THUIS / "AppData" / "Local"))
        for p in (local / "Programs" / "Orca" / "Orca.exe", local / "Programs" / "orca" / "Orca.exe",
                  Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Orca" / "Orca.exe"):
            if p.exists():
                return p
    else:
        p = THUIS / "Applications" / "Orca.AppImage"
        if p.exists():
            return p
        if vind("orca"):
            return Path(vind("orca"))
    return None


def orca_cli() -> Optional[str]:
    g = vind("orca")
    if g:
        return g
    app = orca_app()
    if app and systeem() == "mac":
        p = app / "Contents" / "Resources" / "bin" / "orca"
        return str(p) if p.exists() else None
    if app and systeem() == "windows":
        for p in (app.parent / "resources" / "bin" / "orca.cmd", app.parent / "resources" / "bin" / "orca.exe"):
            if p.exists():
                return str(p)
    return None


def check_orca() -> dict:
    if orca_app():
        return klaar("Orca staat erop.")
    return open_("Orca staat er nog niet op.")


def doe_orca(invoer: dict, log: Log) -> dict:
    s = systeem()
    tmp = WERKMAP / "downloads"
    if not orca_app():
        if s == "mac":
            naam = "orca-macos-arm64.dmg" if is_arm() else "orca-macos-x64.dmg"
            dmg = download(ORCA_DOWNLOAD + naam, tmp / naam, log, "Orca")
            koppel = Path(tempfile.mkdtemp(prefix="orca-"))
            code, uit = draai(["hdiutil", "attach", "-nobrowse", "-quiet", "-mountpoint", str(koppel), str(dmg)], log)
            if code != 0:
                raise Fout("Het Orca-bestand kon niet geopend worden.", "Probeer het opnieuw; dan download ik hem opnieuw.")
            try:
                bron = next(koppel.glob("*.app"))
                doel = Path("/Applications") if os.access("/Applications", os.W_OK) else THUIS / "Applications"
                doel.mkdir(exist_ok=True)
                log(f"Orca naar {doel} zetten...")
                draai(["ditto", str(bron), str(doel / "Orca.app")], log)
                stil(["xattr", "-dr", "com.apple.quarantine", str(doel / "Orca.app")])
            finally:
                stil(["hdiutil", "detach", "-quiet", str(koppel)], timeout=60)
            dmg.unlink(missing_ok=True)
        elif s == "windows":
            exe = download(ORCA_DOWNLOAD + "orca-windows-setup.exe", tmp / "orca-setup.exe", log, "Orca")
            log("Orca installeren...")
            draai([str(exe), "/S"], log, timeout=900)
            time.sleep(3)
        else:
            naam = "orca-linux-arm64.AppImage" if is_arm() else "orca-linux.AppImage"
            doel = THUIS / "Applications" / "Orca.AppImage"
            download(ORCA_DOWNLOAD + naam, doel, log, "Orca")
            doel.chmod(0o755)
        if not orca_app():
            raise Fout("Orca kon niet geinstalleerd worden.", "Probeer het opnieuw.")
    log("Orca staat erop.")
    # De opdrachtregel van Orca bereikbaar maken voor de app (Jarvis start daar zijn klussen).
    cli = orca_cli()
    if cli and systeem() != "windows" and not vind("orca"):
        bin_ = THUIS / ".local" / "bin"
        bin_.mkdir(parents=True, exist_ok=True)
        link = bin_ / "orca"
        if not link.exists():
            link.symlink_to(cli)
        log("Orca-opdrachten klaargezet.")
    return {}


# ---------------------------------------------------------------------------
# VS Code (Bart, 13 okt 2026): daar staat het lesmateriaal; staat het er al, dan niets doen.
# Installeren zonder beheerdersrechten: Mac in Programma's (anders ~/Applications), Windows met de
# gebruikersinstaller, Linux uit het tar-pakket in je thuismap.
# ---------------------------------------------------------------------------

VSCODE_URL = {
    "mac": "https://update.code.visualstudio.com/latest/darwin-universal/stable",
    "windows": "https://update.code.visualstudio.com/latest/win32-x64-user/stable",
    "linux": "https://update.code.visualstudio.com/latest/linux-x64/stable",
}


def vscode_pad() -> Optional[Path]:
    s = systeem()
    kandidaten: List[Path] = []
    if s == "mac":
        kandidaten = [Path("/Applications/Visual Studio Code.app"), THUIS / "Applications" / "Visual Studio Code.app"]
    elif s == "windows":
        local = Path(os.environ.get("LOCALAPPDATA", THUIS / "AppData" / "Local"))
        kandidaten = [local / "Programs" / "Microsoft VS Code" / "Code.exe",
                      Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Microsoft VS Code" / "Code.exe"]
    else:
        kandidaten = [THUIS / ".local" / "share" / "vscode" / "code", Path("/usr/share/code/code"), Path("/snap/bin/code")]
    for k in kandidaten:
        if k.exists():
            return k
    c = vind("code")
    return Path(c) if c else None


def check_vscode() -> dict:
    p = vscode_pad()
    return klaar("VS Code staat erop.", pad=str(p)) if p else open_("VS Code staat er nog niet.")


def doe_vscode(invoer: dict, log: Log) -> dict:
    if vscode_pad():
        log("VS Code staat er al.")
        return {}
    s = systeem()
    tmp = WERKMAP / "downloads"
    if s == "mac":
        zip_ = download(VSCODE_URL["mac"], tmp / "vscode.zip", log, "VS Code")
        for doel in (Path("/Applications"), THUIS / "Applications"):
            try:
                doel.mkdir(parents=True, exist_ok=True)
                code, uit = stil(["ditto", "-x", "-k", str(zip_), str(doel)], timeout=600)
                if code == 0 and (doel / "Visual Studio Code.app").exists():
                    log(f"VS Code staat in {doel}.")
                    break
            except OSError:
                continue
        zip_.unlink(missing_ok=True)
    elif s == "windows":
        exe = download(VSCODE_URL["windows"], tmp / "vscode-setup.exe", log, "VS Code")
        draai([str(exe), "/VERYSILENT", "/NORESTART", "/MERGETASKS=!runcode,addtopath"], log, timeout=900)
        exe.unlink(missing_ok=True)
    else:
        tar = download(VSCODE_URL["linux"], tmp / "vscode.tar.gz", log, "VS Code")
        doel = THUIS / ".local" / "share"
        doel.mkdir(parents=True, exist_ok=True)
        draai(["tar", "-xzf", str(tar), "-C", str(doel)], log, timeout=600)
        uitgepakt = doel / "VSCode-linux-x64"
        if uitgepakt.exists():
            shutil.rmtree(doel / "vscode", ignore_errors=True)
            uitgepakt.rename(doel / "vscode")
        bin_ = THUIS / ".local" / "bin"
        bin_.mkdir(parents=True, exist_ok=True)
        link = bin_ / "code"
        if not link.exists():
            link.symlink_to(doel / "vscode" / "bin" / "code")
        tar.unlink(missing_ok=True)
    if not vscode_pad():
        raise Fout("VS Code kon niet geïnstalleerd worden.",
                   "Download het zelf op code.visualstudio.com en klik daarna opnieuw; dan ga ik verder.")
    log("VS Code staat erop.")
    return {}


def open_in_vscode(map_: Path, log: Log) -> None:
    """Aan het eind: VS Code met de Mainframe-map, zodat lessen en bestanden naast elkaar staan."""
    if os.environ.get("MAINFRAME_INSTALLER_TEST"):
        return
    p = vscode_pad()
    if not p:
        return
    try:
        if systeem() == "mac":
            # -g: op de achtergrond, zodat Ontmoet Jarvis in de browser voor blijft (zoals Orca).
            subprocess.Popen(["open", "-g", "-a", str(p) if p.suffix == ".app" else "Visual Studio Code", str(map_)])
        else:
            subprocess.Popen([str(p), str(map_)], start_new_session=True)
        log("VS Code geopend met je Mainframe.")
    except Exception as e:
        log(f"VS Code openen lukte niet ({e}). Open het zelf en kies je Mainframe-map.")


ORCA_STAP_MAXIMAAL = 90  # seconden; daarna gaat de wizard door zonder Orca (21 okt 2026, Fabian op Windows)
ORCA_LATER = "Orca reageerde nog niet. Open Orca straks zelf en kies Open project, dan je Mainframe-map."


def _orca_starten(cli: str) -> None:
    """Orca op de achtergrond starten, zonder dat de wizard aan zijn pijpen blijft hangen."""
    if systeem() == "mac":
        # -g: niet naar voren, -j: verborgen. Bart, 13 okt 2026: Orca niet in beeld laten springen.
        stil(["open", "-gj", "-a", "Orca"], timeout=30)
        time.sleep(4)
        return
    app = orca_app()
    if systeem() == "windows" and app:
        # Niet via `orca open` met opgevangen uitvoer: de Orca-app erft dan de pijpen van de
        # cmd-wrapper, en subprocess.run wacht op Windows tot die dichtgaan, dus zolang Orca
        # draait (21 okt 2026, Fabian: een kwartier stil op "in Orca zetten"). Los starten,
        # zonder pijpen; daarna kijkt de opdrachtregel of hij luistert.
        vlaggen = getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        try:
            subprocess.Popen([str(app)], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL, creationflags=vlaggen, close_fds=True)
        except OSError:
            pass
        time.sleep(8)
        return
    stil([cli, "open", "--json"], timeout=60)  # Linux: start Orca en wacht tot hij luistert


def _orca_project_zetten(cli: str, map_: Path) -> str:
    """Het echte werk; geeft de regel voor het logboek terug."""
    _orca_starten(cli)

    def alles_zichtbaar() -> None:
        # Ook werkmappen die buiten Orca gemaakt zijn tonen (Bart, 19 okt 2026); de app controleert dit
        # daarna bij elke start opnieuw (orca-gezond.ts).
        stil([cli, "repo", "set", "--repo", f"path:{map_}", "--external-worktree-visibility", "show", "--json"], timeout=20)

    for _ in range(3):
        code, uit = stil([cli, "repo", "list", "--json"], timeout=20)
        if code == 0 and str(map_) in uit:
            alles_zichtbaar()
            return "Je Mainframe staat in Orca."
        if code == 0:
            code, _ = stil([cli, "repo", "add", "--path", str(map_), "--json"], timeout=30)
            if code == 0:
                alles_zichtbaar()
                return "Je Mainframe staat nu in Orca."
        time.sleep(5)
    return ORCA_LATER


def orca_project_toevoegen(map_: Path, log: Log) -> None:
    """Zet de Mainframe-map als project in Orca, zodat Jarvis' klussen daar als tabblad komen.

    Nooit ten koste van de installatie: het werk draait op een achtergronddraad en na
    ORCA_STAP_MAXIMAAL seconden gaat de wizard door, ook als Orca of zijn opdrachtregel niet
    loslaat (21 okt 2026: op Windows bleef de wizard een kwartier stil op deze regel)."""
    cli = orca_cli()
    if not cli or os.environ.get("MAINFRAME_INSTALLER_TEST"):
        return
    log("Je Mainframe in Orca zetten (Orca blijft op de achtergrond)...")
    klaar = threading.Event()
    uitkomst: Dict[str, str] = {}

    def werk() -> None:
        try:
            uitkomst["regel"] = _orca_project_zetten(cli, map_)
        except Exception as e:  # noqa: BLE001
            uitkomst["regel"] = f"Orca reageerde niet ({e}). Open Orca straks zelf en kies Open project, dan je Mainframe-map."
        finally:
            klaar.set()

    threading.Thread(target=werk, daemon=True, name="orca-project").start()
    if klaar.wait(ORCA_STAP_MAXIMAAL):
        log(uitkomst.get("regel") or ORCA_LATER)
    else:
        log("Orca laat niet los; ik ga alvast door. Open Orca straks zelf en kies Open project, dan je Mainframe-map.")


# ---------------------------------------------------------------------------
# Stap 5: je Mainframe (map, code, motor)
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Waar komt de Mainframe-map (Bart, 12 okt 2026): zelf kiezen, nooit in een gedeelde map
# ---------------------------------------------------------------------------

GEDEELD_UITLEG = ("Je Mainframe mag niet in een gedeelde of gesynchroniseerde map staan, zoals OneDrive, "
                  "iCloud Drive, Dropbox, Google Drive of een netwerkschijf. Die programma's synchroniseren "
                  "terwijl Claude werkt; dan raken bestanden kapot of komen ze dubbel. Kies een map op deze computer zelf.")
_SYNC_NAMEN = ("onedrive", "icloud", "clouddocs", "dropbox", "google drive", "googledrive", "my drive",
               "mijn drive", "box sync", "pcloud", "sync.com", "nextcloud", "owncloud", "mega")


def _netwerk_mounts() -> List[str]:
    """Koppelpunten van netwerkschijven (smb, afp, nfs, webdav, cifs)."""
    uit: List[str] = []
    try:
        if systeem() == "linux":
            for regel in Path("/proc/mounts").read_text().splitlines():
                delen = regel.split()
                if len(delen) > 2 and re.match(r"(nfs|cifs|smb|fuse\.sshfs|davfs)", delen[2]):
                    uit.append(delen[1])
        elif systeem() == "mac":
            r = subprocess.run(["mount"], capture_output=True, text=True, timeout=10)
            for regel in r.stdout.splitlines():
                m = re.match(r".+ on (.+) \((smbfs|afpfs|nfs|webdav)", regel)
                if m:
                    uit.append(m.group(1))
    except Exception:
        pass
    return uit


def gedeelde_map(pad: Path) -> Optional[str]:
    """Waarom deze plek een gedeelde map is (korte naam), of None als hij op deze computer zelf staat."""
    try:
        p = pad.expanduser().resolve()
    except OSError:
        p = pad.expanduser()
    tekst = str(p).lower().replace("\\", "/")
    if str(p).startswith("\\\\") or tekst.startswith("//"):
        return "een netwerkschijf"
    for naam in _SYNC_NAMEN:
        if naam in tekst:
            return {"clouddocs": "iCloud Drive", "icloud": "iCloud Drive", "onedrive": "OneDrive",
                    "googledrive": "Google Drive", "google drive": "Google Drive", "my drive": "Google Drive",
                    "mijn drive": "Google Drive"}.get(naam, naam.title())
    if "/library/cloudstorage/" in tekst or "/library/mobile documents/" in tekst:
        return "een cloudmap"
    # Mac met "Bureaublad en Documenten in iCloud": dan synchroniseert iCloud die twee mappen.
    if systeem() == "mac" and (THUIS / "Library" / "Mobile Documents" / "com~apple~CloudDocs" / "Documents").is_dir():
        for map_ in (THUIS / "Documents", THUIS / "Desktop"):
            try:
                p.relative_to(map_.resolve())
                return "iCloud Drive (Bureaublad en Documenten staan in iCloud)"
            except ValueError:
                pass
    for koppel in _netwerk_mounts():
        if tekst == koppel.lower() or tekst.startswith(koppel.lower().rstrip("/") + "/"):
            return "een netwerkschijf"
    if systeem() == "windows" and len(str(p)) > 2 and str(p)[1] == ":":
        try:
            import ctypes
            if ctypes.windll.kernel32.GetDriveTypeW(str(p)[:3]) == 4:  # DRIVE_REMOTE
                return "een netwerkschijf"
        except Exception:
            pass
    return None


def is_oud_mainframe(map_: Path) -> bool:
    """Een Mainframe van voor 2.0: zelf opgebouwd in de cursus, zonder licentie van de installer."""
    return not _licentie(map_) and is_eigen_mainframe(map_)


def verhuis_doel(oud: Optional[Path] = None) -> Path:
    """De logische plek voor Mainframe 2.0 als er een oude Mainframe verhuist: ~/Mainframe, of
    ~/Mainframe-2 als daar al iets anders staat."""
    for naam in ("Mainframe", "Mainframe-2", "Mainframe-3"):
        p = THUIS / naam
        if oud and p.resolve() == oud.resolve():
            continue
        try:
            if not p.exists() or not any(x for x in p.iterdir() if not x.name.startswith(".")) or _licentie(p):
                return p
        except OSError:
            continue
    return THUIS / "Mainframe-2"


def map_voorstel() -> Dict:
    """Wat het startscherm voorstelt (niet in Documenten: die map synchroniseert op veel Macs en pc's
    met iCloud of OneDrive).

    - Al Mainframe 2.0 (licentie): die map, de installer werkt hem bij.
    - Een oude Mainframe (Bart, 20 okt 2026): Mainframe 2.0 komt op de logische plek en de oude gaat
      daarna in de kennismaking veilig mee ("oud"). Ook als de oude in ~/Mainframe staat: dan komt 2.0
      in ~/Mainframe-2 (Bart, 21 okt 2026: de oude map wordt nooit aangeraakt).
    - Anders ~/Mainframe.
    """
    s = lees_staat()
    if s.get("map"):
        m = Path(s["map"])
        return {"map": str(m), "bestaand": bool(_licentie(m) or is_eigen_mainframe(m)), "gedeeld": gedeelde_map(m),
                "oud": s.get("oude_map") or None}
    vondsten = zoek_bestaande_mainframes()
    for p in vondsten:
        if _licentie(p) and not gedeelde_map(p):
            return {"map": str(p), "bestaand": True, "gedeeld": None, "oud": None}
    oud = next((p for p in vondsten if is_oud_mainframe(p)), None)
    m = verhuis_doel(oud) if oud else THUIS / "Mainframe"
    return {"map": str(m), "bestaand": bool(_licentie(m)), "gedeeld": gedeelde_map(m), "oud": str(oud) if oud else None}


def map_antwoord(m: Path) -> Dict:
    """Wat het startscherm over een gekozen map hoort. Is het een oude Mainframe, dan wordt dat de map om
    mee te nemen en komt 2.0 ernaast: in een oude Mainframe installeren we nooit (Bart, 21 okt 2026)."""
    if is_oud_mainframe(m):
        doel = verhuis_doel(m)
        return {"map": str(doel), "bestaand": False, "gedeeld": gedeelde_map(doel), "oud": str(m), "fout": ""}
    waarom = gedeelde_map(m)
    return {"map": str(m), "bestaand": bool(_licentie(m)), "gedeeld": waarom,
            "fout": (f"Die map staat in {waarom}. " + GEDEELD_UITLEG) if waarom else ""}


def onthoud_oude_mainframe(map_: Path) -> None:
    """Zet in het nieuwe Mainframe waar de oude staat; de kennismaking in de app biedt hem dan aan
    om te verhuizen (scripts/mainframe/importeren.ts, oudMainframe). Met het vinkje "neem alles mee"
    (staat standaard aan) start de app die import vanzelf."""
    oud = lees_staat().get("oude_map")
    if not oud:
        return
    o = Path(oud)
    try:
        if o.resolve() == map_.resolve() or not is_eigen_mainframe(o):
            return
    except OSError:
        return
    (map_ / ".mainframe").mkdir(parents=True, exist_ok=True)
    meenemen = lees_staat().get("meenemen", "ja") != "nee"
    (map_ / ".mainframe" / "oude-mainframe.json").write_text(json.dumps({"pad": str(o), "meenemen": meenemen}, indent=2))


def kies_map_dialoog() -> Optional[str]:
    """Het gewone mapkeuzevenster van de computer. None = geannuleerd of geen venster mogelijk."""
    vraag = "Kies waar je Mainframe komt"
    try:
        if systeem() == "mac":
            r = subprocess.run(["osascript", "-e", f'POSIX path of (choose folder with prompt "{vraag}")'],
                               capture_output=True, text=True, timeout=600)
        elif systeem() == "windows":
            ps = ("Add-Type -AssemblyName System.Windows.Forms; $d = New-Object System.Windows.Forms.FolderBrowserDialog; "
                  f"$d.Description = '{vraag}'; if ($d.ShowDialog() -eq 'OK') {{ $d.SelectedPath }}")
            r = subprocess.run(["powershell", "-NoProfile", "-STA", "-Command", ps], capture_output=True, text=True, timeout=600)
        else:
            for cmd in (["zenity", "--file-selection", "--directory", f"--title={vraag}"],
                        ["kdialog", "--getexistingdirectory", str(THUIS)]):
                if vind(cmd[0]):
                    r = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
                    break
            else:
                return None
    except Exception:
        MAPVENSTER_KAPOT[0] = True
        return None
    pad = (r.stdout or "").strip()
    if r.returncode != 0:
        # Afgebroken door de gebruiker is gewoon geen keuze; elke andere fout: het venster werkte niet.
        if not re.search(r"-128|cancel", (r.stderr or ""), re.I) and not (systeem() != "mac" and not r.stderr):
            MAPVENSTER_KAPOT[0] = True
        return None
    return pad.rstrip("/\\") or None


MAPVENSTER_KAPOT = [False]


def heeft_mapvenster() -> bool:
    if MAPVENSTER_KAPOT[0]:
        return False
    return systeem() in ("mac", "windows") or bool(vind("zenity") or vind("kdialog"))


def map_uit_keuze(gekozen: str) -> Path:
    """Een gekozen map: is het een lege map of een Mainframe, dan die; anders een map Mainframe erin."""
    p = Path(gekozen).expanduser()
    if p.name.lower() == "mainframe" or _licentie(p) or is_eigen_mainframe(p):
        return p
    try:
        leeg = p.is_dir() and not any(x for x in p.iterdir() if not x.name.startswith("."))
    except OSError:
        leeg = False
    return p if leeg else p / "Mainframe"


def is_eigen_mainframe(map_: Path) -> bool:
    """Een Mainframe die iemand zelf opbouwde (in de cursus): CLAUDE.md en een .claude-map, maar nog
    geen licentie van de installer."""
    return (map_ / "CLAUDE.md").is_file() and (map_ / ".claude").is_dir()


def zoek_bestaande_mainframes() -> List[Path]:
    """Zoekt op de gewone plekken naar een Mainframe die er al staat (11 okt 2026, Bart: ook voor
    wie al een Mainframe heeft). Kijkt een of twee mappen diep; nooit in de map van de installer."""
    plekken = [THUIS, THUIS / "Documents", THUIS / "Documenten", THUIS / "Desktop", THUIS / "Bureaublad",
               THUIS / "Library" / "Mobile Documents" / "com~apple~CloudDocs"]
    plekken += [p / "Documents" for p in THUIS.glob("OneDrive*")] + list(THUIS.glob("OneDrive*"))
    # OneDrive, Dropbox en Google Drive staan op een Mac in ~/Library/CloudStorage, Dropbox soms in ~/Dropbox.
    wolk = sorted((THUIS / "Library" / "CloudStorage").glob("*"))
    plekken += wolk + [p / "Documents" for p in wolk] + [p / "My Drive" for p in wolk] + [THUIS / "Dropbox"]
    gezien: Dict[str, Path] = {}
    for plek in plekken:
        try:
            kinderen = [k for k in plek.iterdir() if k.is_dir() and not k.name.startswith(".")]
        except OSError:
            continue
        for kind in kinderen:
            if kind == WERKMAP:
                continue
            # Niet elk Claude-project is een Mainframe: de naam zegt het, of het heeft de opbouw uit de
            # cursus (kennis en skills), of een licentie of versielogboek van Mainframe OS.
            lijkt = ("mainframe" in kind.name.lower() or (kind / "VERSIES.md").exists()
                     or ((kind / "kennis").is_dir() and (kind / ".claude" / "skills").is_dir()))
            if _licentie(kind) or (is_eigen_mainframe(kind) and lijkt):
                gezien[str(kind.resolve())] = kind
    def tijd(p: Path) -> float:
        try:
            return (p / "CLAUDE.md").stat().st_mtime
        except OSError:
            return 0.0
    return sorted(gezien.values(), key=tijd, reverse=True)[:5]


def _licentie(map_: Path) -> dict:
    """De licentie van een Mainframe 2.0. Het updatescript van 1.2 en 1.3 bewaart zijn licentie op
    dezelfde plek, dus alleen het bestand bewijst niets (melding Hans, 21 okt 2026: zijn 1.x-map werd
    voor 2.0 aangezien en zou in zijn eigen map worden aangevuld). Telt alleen als de installer hem
    schreef (bron) of als de app er staat."""
    try:
        lic = json.loads((map_ / ".mainframe" / "licentie.json").read_text())
    except (OSError, ValueError):
        return {}
    if lic.get("bron") == "installer-2":
        return lic
    # De app (Jarvis) bestaat alleen in 2.0; ook een oude 2.0-proef zonder .versie telt dus mee.
    if (map_ / ".mainframe" / "app" / "package.json").exists():
        return lic
    return {}


def check_mainframe() -> dict:
    m = mainframe_map()
    s = lees_staat()
    standaard = str(THUIS / "Mainframe")
    ingevuld = str(s.get("code") or "").upper()
    if (m and (m / "VERSIES.md").exists() and _licentie(m).get("code")
            and (not ingevuld or _licentie(m).get("code", "").upper() == ingevuld)):
        return klaar(f"Je Mainframe staat in {m}.", map=str(m), code=_licentie(m).get("code"),
                     email=_licentie(m).get("email"))
    return open_("Nog geen Mainframe.", map=s.get("map") or standaard, code=s.get("code", ""),
                 email=s.get("email", ""))


REDENEN = {
    "onbekende_code": ("Deze code ken ik niet.", "Kijk of je hem goed hebt overgenomen. Hij begint met MF-."),
    "email_mismatch": ("Dit e-mailadres hoort niet bij deze code.", "Gebruik het adres waarmee je hebt gekocht."),
    "max_bereikt": ("Deze code is al op het maximale aantal computers gebruikt.",
                    "Mail Bart, dan zet hij er een computer bij."),
    "ingetrokken": ("Deze code is niet meer geldig.", "Neem contact op met Bart."),
    "geen_motor_beschikbaar": ("De server heeft op dit moment geen pakket klaarstaan.",
                               "Probeer het over een paar minuten opnieuw."),
}


def activeer(code: str, email: str, herhaal: bool) -> dict:
    antwoord = http_json(f"{SERVER}/licentie/installeer", {
        "code": code, "email": email, "apparaat_label": socket.gethostname()[:60], "herhaal": herhaal,
    })
    if not antwoord.get("ok"):
        uitleg, wat_nu = REDENEN.get(antwoord.get("reden", ""), (
            "De code kon niet gecontroleerd worden.", "Probeer het zo opnieuw."))
        raise Fout(uitleg, wat_nu)
    return antwoord


def _echt_van_slim_werken(pad: Path, antwoord: dict, soort: str) -> None:
    """Weigert een download die niet aantoonbaar van Slim Werken komt (handtekening, zie handtekening.py)."""
    from handtekening import controleer_release
    reden = controleer_release(pad.read_bytes(), antwoord, soort, str(antwoord.get(f"{soort}_version", "")))
    if reden:
        pad.unlink(missing_ok=True)
        raise Fout(f"Ik heb de download niet geïnstalleerd: {reden}",
                   "Probeer het over een paar minuten opnieuw. Blijft dit staan, stuur dan de details naar Bart.")


def _schrijf_motor(map_: Path, motor: dict, log: Log) -> int:
    import base64
    n = 0
    for rel, blob in motor["files"].items():
        pad = map_ / rel
        if ".." in Path(rel).parts or Path(rel).is_absolute():
            continue
        pad.parent.mkdir(parents=True, exist_ok=True)
        if "text" in blob:
            # Precies de bytes van het pakket. write_text maakte op Windows van elke \n een \r\n;
            # daarna hield de updater alles voor eigen werk (test b26 op Windows 11, 23 okt 2026).
            pad.write_bytes(blob["text"].encode("utf-8"))
        else:
            pad.write_bytes(base64.b64decode(blob["b64"]))
        if rel.endswith((".sh", ".py")):
            pad.chmod(0o755)
        n += 1
    return n


GITIGNORE_EXTRA = [".env", ".env.*", "!.env.example", ".mainframe/app/", ".mainframe/licentie.json",
                   "node_modules/", ".DS_Store"]


def zet_sleutels(antwoord: dict, map_: Path, log: Log) -> None:
    """Sleutels die Slim Werken voor deze klant regelt, in zijn .env (en die van de app).

    Een sleutel die de klant zelf al had ingevuld blijft staan.
    """
    sleutels = antwoord.get("sleutels") or {}
    gezet = []
    for naam, waarde in sleutels.items():
        if not re.fullmatch(r"[A-Z][A-Z0-9_]{1,60}", str(naam)) or not waarde:
            continue
        if not lees_env(map_ / ".env", naam):
            zet_env(map_ / ".env", naam, str(waarde))
        app_env = map_ / ".mainframe" / "app" / ".env.local"
        if (map_ / ".mainframe" / "app").exists() and not lees_env(app_env, naam):
            zet_env(app_env, naam, lees_env(map_ / ".env", naam))
        gezet.append(naam)
    if gezet:
        zet_staat(sleutels_geregeld=sorted(set(gezet) | set(lees_staat().get("sleutels_geregeld") or [])))
        if "GEMINI_API_KEY" in gezet:
            log("De stem van Jarvis is door Slim Werken voor je geregeld.")


def doe_mainframe(invoer: dict, log: Log) -> dict:
    code = re.sub(r"\s+", "", str(invoer.get("code", ""))).upper()
    email = str(invoer.get("email", "")).strip().lower()
    map_ = Path(str(invoer.get("map") or THUIS / "Mainframe")).expanduser()
    if not re.fullmatch(r"MF-[A-Z0-9]{4}-[A-Z0-9]{4}", code):
        raise Fout("Dat lijkt geen licentiecode.", "Een code ziet eruit als MF-ABCD-1234.")
    if "@" not in email:
        raise Fout("Vul het e-mailadres in waarmee je hebt gekocht.")
    waarom = gedeelde_map(map_)
    if waarom:
        raise Fout(f"{map_} staat in {waarom}.", GEDEELD_UITLEG)
    bestaand = _licentie(map_)
    if not bestaand and is_eigen_mainframe(map_):
        # Een oude Mainframe raken we nooit aan (Bart, 21 okt 2026): 2.0 komt ernaast en alles gaat via een kopie mee.
        raise Fout(f"In {map_} staat je oude Mainframe. Die laten we precies zoals hij is.",
                   f"Kies een nieuwe map, bijvoorbeeld {verhuis_doel(map_)}. Je skills, instellingen en de rest nemen we daarna mee.")
    eigen = False
    if bestaand and str(bestaand.get("code", "")).upper() != code:
        # De map heeft een andere (oude, proef- of ongeldige) code: jouw code komt erin, en van de rest
        # komt alleen wat ontbreekt (12 okt 2026, Barts test op een proefmap met een nep-licentie).
        log("In deze map staat een andere licentie; die vervang ik door jouw code.")
        eigen, bestaand = True, {}
    had_git = (map_ / ".git").exists()
    if map_.exists() and any(map_.iterdir()) and not bestaand and not eigen and not (map_ / ".mainframe").exists():
        raise Fout(f"In {map_} staan al andere bestanden.", "Kies een lege of nieuwe map.")

    log("Je code controleren...")
    antwoord = activeer(code, email, herhaal=bool(bestaand) and bestaand.get("code") == code)
    log("Code klopt." + (f" Nog {antwoord.get('resterend')} computer(s) over op deze code."
                         if antwoord.get("geteld") else ""))
    zet_staat(map=str(map_), code=code, email=email, app_url=antwoord["app_url"],
              app_versie=antwoord["app_version"], vulling=antwoord.get("vulling") or {})

    map_.mkdir(parents=True, exist_ok=True)
    tmp = WERKMAP / "downloads"
    if not (map_ / "CLAUDE.md").exists():
        log("De basis van je Mainframe ophalen...")
        zip_ = download(STARTER_ZIP, tmp / "starter.zip", log, "de basis")
        with zipfile.ZipFile(zip_) as z:
            for naam in z.namelist():
                delen = Path(naam).parts[1:]
                if not delen or naam.endswith("/") or ".." in delen:
                    continue
                doel = map_.joinpath(*delen)
                if doel.exists():
                    continue
                doel.parent.mkdir(parents=True, exist_ok=True)
                doel.write_bytes(z.read(naam))

    log(f"Mainframe OS {antwoord['motor_version']} ophalen...")
    motor_pad = download(antwoord["motor_url"], tmp / "motor.json", None, "Mainframe OS")
    _echt_van_slim_werken(motor_pad, antwoord, "motor")
    motor = json.loads(motor_pad.read_text(encoding="utf-8"))
    motor_pad.unlink(missing_ok=True)
    if eigen:
        # Alleen wat er nog niet is; eigen skills, hooks, instellingen en teksten blijven zoals ze zijn.
        motor["files"] = {k: v for k, v in motor["files"].items() if not (map_ / k).exists()}
        log("Je eigen Mainframe blijft zoals hij is; alleen wat ontbreekt komt erbij.")
    elif bestaand:
        # Opnieuw draaien: niets overschrijven, alleen wat ontbreekt komt erbij (zoals het keuzevenster
        # belooft). Nieuwe versies van bestaande bestanden lopen via /update, dat een back-up maakt.
        motor["files"] = {k: v for k, v in motor["files"].items() if not (map_ / k).exists()}
    n = _schrijf_motor(map_, motor, log)
    log(f"{n} onderdelen neergezet: skills, hooks, kennisgidsen en de werkstructuur.")

    mf = map_ / ".mainframe"
    mf.mkdir(exist_ok=True)
    (mf / "licentie.json").write_text(json.dumps({"code": code, "email": email, "bron": "installer-2"}, indent=2))
    env = map_ / ".env"
    if not env.exists():
        voorbeeld = map_ / ".env.example"
        env.write_text(voorbeeld.read_text() if voorbeeld.exists() else "")
    if env.is_file():  # een map .env met losse sleutelbestanden laten we met rust (melding Hans)
        try:
            env.chmod(0o600)  # alleen jij mag je sleutels lezen
        except OSError:
            pass
    zet_sleutels(antwoord, map_, log)
    gi = map_ / ".gitignore"
    regels = gi.read_text().splitlines() if gi.exists() else []
    gi.write_text("\n".join(regels + [r for r in GITIGNORE_EXTRA if r not in regels]) + "\n")
    for sub in ("logboek", "docs/logs", "projecten", "klanten", "kennis"):
        (map_ / sub).mkdir(parents=True, exist_ok=True)

    git = vind("git")
    if git and not had_git:
        if not (map_ / ".git").exists():
            draai([git, "init", "-q", "-b", "main"], log, cwd=map_)
        naam = lees_staat().get("voornaam") or "Mainframe"
        draai([git, "add", "-A"], None, cwd=map_)
        draai([git, "-c", f"user.name={naam}", "-c", "user.email=mainframe@lokaal",
               "commit", "-q", "-m", "Mijn Mainframe neergezet"], None, cwd=map_)
        if stil([git, "config", "--global", "user.name"])[0] != 0:
            stil([git, "config", "--global", "user.name", naam])
            stil([git, "config", "--global", "user.email", email])
    vertrouw_map(map_)
    _installer_kopie(map_)
    onthoud_oude_mainframe(map_)
    log("Je Mainframe staat klaar.")
    return {}


WIZARD_SKILL = """---
name: wizard
description: Open de installatiewizard van je Mainframe opnieuw, om een stap alsnog of opnieuw te doen. Gebruik bij /wizard, "open de wizard", "koppel mijn Outlook alsnog", "koppel mijn mail of agenda", "zet Jarvis op mijn telefoon", "geef Jarvis een andere stem", "Claude opnieuw inloggen", "controleer of alles nog werkt".
---

# /wizard - de installatiewizard opnieuw openen

De wizard staat in `.mainframe/installer/`. Hij kijkt zelf wat er al staat: wat klaar is
krijgt een vinkje, de rest kun je alsnog doen. Er gaat niets kapot door hem opnieuw te openen.

## Zo open je hem

Start de wizard op de achtergrond, wacht twee seconden en lees het adres:

```bash
python3 .mainframe/installer/server.py --geen-browser     # Mac en Linux
py -3 .mainframe\\installer\\server.py --geen-browser       # Windows
```

Het adres staat daarna in `~/.mainframe-installer/adres.txt` (op Windows in je gebruikersmap).
Open het in de browser van deze computer (`open <adres>` op een Mac, `start <adres>` op Windows)
en geef het ook als klikbare link. Het adres werkt alleen op deze computer.

Wil de gebruiker de nieuwste versie van de wizard: dezelfde regel als bij de installatie,
`curl -fsSL https://slimwerken.ai/installeer/installeer.sh | sh` (Windows:
`irm https://slimwerken.ai/installeer/installeer.ps1 | iex`).

## Wat je NIET doet

- Geen sleutels of codes in de chat vragen: die vult de gebruiker in de wizard zelf in.
- De wizard niet zelf doorklikken namens de gebruiker. Jij opent hem, de gebruiker kiest.
"""


def _installer_kopie(map_: Path) -> None:
    """Zet de wizard zelf in de Mainframe-map, zodat je hem later opnieuw opent."""
    hier = Path(__file__).resolve().parent
    doel = map_ / ".mainframe" / "installer"
    if hier == doel:
        return
    if doel.exists():
        shutil.rmtree(doel, ignore_errors=True)
    shutil.copytree(hier, doel, ignore=shutil.ignore_patterns("__pycache__"))
    skill = map_ / ".claude" / "skills" / "wizard" / "SKILL.md"
    skill.parent.mkdir(parents=True, exist_ok=True)
    skill.write_text(WIZARD_SKILL, encoding="utf-8")
    if systeem() == "windows":
        (map_ / "Mainframe wizard.bat").write_text(
            '@echo off\r\ncd /d "%~dp0"\r\npy -3 .mainframe\\installer\\server.py || python .mainframe\\installer\\server.py\r\n')
    else:
        start = map_ / "Mainframe wizard.command"
        start.write_text('#!/bin/sh\ncd "$(dirname "$0")"\nexec python3 .mainframe/installer/server.py\n')
        start.chmod(0o755)


# ---------------------------------------------------------------------------
# Stap 6: over jou (CLAUDE.md en kennis persoonlijk maken)
# ---------------------------------------------------------------------------

def _placeholders(map_: Path) -> List[str]:
    gevonden = []
    for rel in ("CLAUDE.md", "kennis/over-mij.md"):
        try:
            gevonden += re.findall(r"\{\{([A-Z_]+)\}\}", (map_ / rel).read_text(encoding="utf-8"))
        except OSError:
            pass
    return gevonden


def check_overjou() -> dict:
    m = mainframe_map()
    if not m or not (m / "CLAUDE.md").exists():
        return wacht("Eerst je Mainframe neerzetten.")
    open_velden = {"WIE_BEN_IK", "WAT_DOE_IK"} & set(_placeholders(m))
    vulling = lees_staat().get("vulling") or {}
    if not open_velden:
        return klaar("Je Mainframe weet wie je bent.", vulling=vulling)
    return open_("Nog niet ingevuld.", vulling=vulling)


def _vervang(tekst: str, sleutel: str, waarde: str) -> str:
    waarde = waarde.strip()
    if not waarde:
        return tekst
    # De placeholder plus het uitlegcommentaar erachter of op de regel eronder.
    tekst = re.sub(r"\{\{" + sleutel + r"\}\}[ \t]*(<!--.*?-->)?", lambda _: waarde, tekst, count=1)
    return re.sub(re.escape(waarde) + r"\n<!--.*?-->\n", lambda _: waarde + "\n", tekst, count=1, flags=re.S)


def doe_overjou(invoer: dict, log: Log) -> dict:
    m = mainframe_map()
    if not m:
        raise Fout("Zet eerst je Mainframe neer.")
    wie = str(invoer.get("wie", "")).strip()
    wat = str(invoer.get("wat", "")).strip()
    stijl = str(invoer.get("stijl", "")).strip()
    klussen = [k.strip() for k in str(invoer.get("klussen", "")).splitlines() if k.strip()]
    bedrijf = str(invoer.get("bedrijf", "")).strip()
    if not wie or not wat:
        raise Fout("Vul in wie je bent en wat je doet. De rest mag leeg blijven.")
    routes = ""
    if klussen:
        routes = "Mijn terugkerende klussen:\n" + "\n".join(f"- {k}" for k in klussen[:8])
    vervangingen = {
        "CLAUDE.md": {"WIE_BEN_IK": wie, "WAT_DOE_IK": wat, "SCHRIJFSTIJL": stijl, "ROUTES": routes},
        "kennis/over-mij.md": {"OVER_MIJ_INTRO": wie, "WAT_DOE_IK_DETAIL": wat, "BEDRIJF": bedrijf},
        "kennis/schrijfstijl.md": {"TOON": stijl},
    }
    for rel, velden in vervangingen.items():
        pad = m / rel
        if not pad.exists():
            continue
        tekst = pad.read_text(encoding="utf-8")
        for k, v in velden.items():
            tekst = _vervang(tekst, k, v)
        pad.write_text(tekst, encoding="utf-8")
        log(f"{rel} bijgewerkt.")
    zet_staat(overjou={"wie": wie, "wat": wat, "stijl": stijl, "klussen": "\n".join(klussen), "bedrijf": bedrijf})
    git = vind("git")
    if git and (m / ".git").exists():
        draai([git, "add", "-A"], None, cwd=m)
        draai([git, "-c", "user.name=Mainframe", "-c", "user.email=mainframe@lokaal", "commit", "-q", "-m",
               "Over mij ingevuld"], None, cwd=m)
    return {}


# ---------------------------------------------------------------------------
# Stap 7: de app met Jarvis
# ---------------------------------------------------------------------------

def app_draait() -> Optional[str]:
    """Geeft de adres van de draaiende app van deze Mainframe, of None."""
    m = mainframe_map()
    if not m:
        return None
    script = m / "overig" / "scripts" / "mainframe_app.py"
    if not script.exists():
        return None
    code, uit = stil(python_cmd() + [str(script), "url"], timeout=20, cwd=m)
    gevonden = re.findall(r"MAINFRAME_URL=(\S+)", uit) or re.findall(r"(http://127\.0\.0\.1:\d+)", uit)
    if code == 0 and gevonden:
        return gevonden[-1].rstrip("/")
    return None


def app_get(pad: str, timeout: int = 10) -> Optional[dict]:
    url = app_draait()
    if not url:
        return None
    try:
        with urllib.request.urlopen(url + pad, timeout=timeout) as r:
            return json.loads(r.read().decode() or "{}")
    except Exception:
        return None


def app_post(pad: str, body: dict, timeout: int = 20) -> dict:
    url = app_draait()
    if not url:
        raise Fout("De app draait niet.", "Doe eerst de stap met de app.")
    with urllib.request.urlopen(url + "/__token", timeout=10) as r:
        token = json.loads(r.read().decode())["token"]
    req = urllib.request.Request(url + pad, data=json.dumps(body).encode(), method="POST",
                                 headers={"Content-Type": "application/json", "X-Claude-OS-Token": token})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode() or "{}")
    except urllib.error.HTTPError as e:
        try:
            fout = json.loads(e.read().decode()).get("error")
        except Exception:
            fout = None
        raise Fout(fout or "De app gaf een fout terug.", "Probeer het opnieuw.")



def zet_onderdelen(aan: Dict[str, bool], log: Optional[Log] = None) -> None:
    try:
        app_post("/__operator/settings", {"onderdelen": aan})
        if log:
            log("In de app aangezet: " + ", ".join(k for k, v in aan.items() if v) + ".")
    except Exception:
        if log:
            log("Onderdelen in de app konden nog niet aan; dat doe je later bij Instellingen.")


def check_app() -> dict:
    m = mainframe_map()
    if not m or not _licentie(m):
        return wacht("Eerst je Mainframe neerzetten.")
    a = m / ".mainframe" / "app"
    if not (a / "package.json").exists():
        return open_("De app staat er nog niet.")
    url = app_draait()
    if url:
        return klaar("De app draait.", url=url)
    return open_("De app staat erop maar draait niet.")


def _zet_app_zip(m: Path, data: bytes, versie: str, log: Log) -> int:
    doel = m / ".mainframe" / "app"
    blijft = ("node_modules/", "dist/", ".operator-data/")
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        namen = [n for n in z.namelist() if not n.endswith("/")]
        for n in namen:
            p = Path(n)
            if not n or p.is_absolute() or ".." in p.parts or "\\" in n or n.startswith(blijft):
                raise Fout("Het app-pakket bevat een onveilig pad. Er is niets veranderd.")
        tijdelijk = Path(tempfile.mkdtemp(prefix="app-", dir=m / ".mainframe"))
        try:
            z.extractall(tijdelijk)
            lijst = doel / ".bestanden.json"
            oud = set(json.loads(lijst.read_text())) if lijst.exists() else set()
            for rel in oud - set(namen):
                if not rel.startswith(blijft):
                    (doel / rel).unlink(missing_ok=True)
            for rel in namen:
                naar = doel / rel
                naar.parent.mkdir(parents=True, exist_ok=True)
                if naar.exists():
                    naar.unlink()
                shutil.move(str(tijdelijk / rel), str(naar))
                if rel.endswith((".sh", ".command", ".py")):
                    naar.chmod(0o755)
            lijst.write_text(json.dumps(sorted(namen)))
            (doel / ".versie").write_text(versie)
        finally:
            shutil.rmtree(tijdelijk, ignore_errors=True)
    # De skills (/app, /koppelingen) en hun scripts horen in de Mainframe-map zelf.
    extra = doel / "mainframe-extra"
    if (extra / "skills").exists():
        for bron in sorted(p for p in (extra / "skills").iterdir() if p.is_dir()):
            skill = m / ".claude" / "skills" / bron.name
            if skill.exists():
                shutil.rmtree(skill)
            shutil.copytree(bron, skill)
    if (extra / "scripts").exists():
        (m / "overig" / "scripts").mkdir(parents=True, exist_ok=True)
        for bron in sorted(p for p in (extra / "scripts").iterdir() if p.is_file()):
            naar = m / "overig" / "scripts" / bron.name
            shutil.copy2(bron, naar)
            if naar.suffix == ".py":
                naar.chmod(0o755)
    return len(namen)


def doe_app(invoer: dict, log: Log) -> dict:
    m = mainframe_map()
    if not m:
        raise Fout("Zet eerst je Mainframe neer.")
    s = lees_staat()
    a = m / ".mainframe" / "app"
    # Een app die er al staat maar ouder is dan de actieve versie (of zonder versie, van een oude
    # proef of installatie) wordt ook vervangen: anders past het startscript niet bij de installer
    # (12 okt 2026, Barts test op een oude proefmap: "Bun ontbreekt" terwijl Bun er stond).
    lic = _licentie(m)
    antwoord = None
    if not lic.get("code"):
        raise Fout("Deze Mainframe heeft nog geen licentie.", "Klik opnieuw; dan zet ik je code er eerst in.")
    if (a / "package.json").exists() and not invoer.get("vernieuw"):
        antwoord = activeer(lic["code"], lic["email"], herhaal=True)
        lokaal = (a / ".versie").read_text().strip() if (a / ".versie").exists() else ""
        zet_staat(app_versie=antwoord.get("app_version"))
        if lokaal != antwoord.get("app_version"):
            log(f"Er staat een oudere app ({lokaal or 'zonder versie'}); die vervang ik door {antwoord.get('app_version')}.")
            invoer = {**invoer, "vernieuw": True}
    if not (a / "package.json").exists() or invoer.get("vernieuw"):
        log("Toegang tot de app controleren...")
        antwoord = antwoord or activeer(lic["code"], lic["email"], herhaal=True)
        zet_staat(app_url=antwoord["app_url"], app_versie=antwoord["app_version"])
        script_oud = m / "overig" / "scripts" / "mainframe_app.py"
        if invoer.get("vernieuw") and script_oud.exists() and app_draait():
            log("De draaiende app eerst stoppen...")
            draai(python_cmd() + [str(script_oud), "stop"], log, cwd=m, timeout=120)
        log(f"De app met Jarvis ophalen (versie {antwoord['app_version']}, ongeveer 55 MB)...")
        zip_pad = download(antwoord["app_url"], WERKMAP / "downloads" / "app.zip", log, "de app")
        _echt_van_slim_werken(zip_pad, antwoord, "app")
        n = _zet_app_zip(m, zip_pad.read_bytes(), antwoord["app_version"], log)
        zip_pad.unlink(missing_ok=True)
        log(f"{n} bestanden van de app neergezet.")
    script = m / "overig" / "scripts" / "mainframe_app.py"
    log("De app klaarmaken en starten. De eerste keer duurt dit een paar minuten.")
    code, uit = draai(python_cmd() + [str(script), "start", "--geen-browser", "--hier"], log, cwd=m, timeout=2400)
    url = (re.findall(r"MAINFRAME_URL=(\S+)", uit) or [None])[-1]
    if code == 2 and "unrecognized arguments" in uit:
        raise Fout("Het startscript van de app is te oud.", "Klik opnieuw; dan zet ik de nieuwe app en het nieuwe startscript neer.")
    if code == 2:
        raise Fout("Bun ontbreekt nog.", "Doe eerst de stap Basisprogramma's.")
    if code != 0 or not url:
        raise Fout("De app wilde niet starten.", "Klik opnieuw. Lukt het dan nog niet, open de details en stuur ze naar Bart.")
    if not url.endswith(f":{APP_POORT}"):
        log(f"Let op: de app draait op {url}, niet op poort {APP_POORT}. "
            "Sluit een ander programma dat die poort gebruikt; de Outlook-koppeling verwacht hem.")
    zet_staat(app_adres=url)
    gemini = lees_env(m / ".env", "GEMINI_API_KEY")
    if gemini and not lees_env(a / ".env.local", "GEMINI_API_KEY"):
        zet_env(a / ".env.local", "GEMINI_API_KEY", gemini)
    # Een nieuw lid begint met alles uit. Jarvis, de agenda en de inbox zijn
    # precies waar deze installatie om draait, dus die gaan aan.
    zet_onderdelen({"jarvis": True, "agenda": True, "inbox": True}, log)
    orca_project_toevoegen(m, log)
    zet_vanzelf(log)
    log("De app draait.")
    return {"url": url}


def zet_vanzelf(log: Log) -> None:
    """Jarvis start vanzelf als de computer aangaat, tenzij het vinkje op het startscherm uit stond
    (Bart, 14 okt 2026: standaard aan). Zonder dit is Jarvis na een herstart weg tot iemand /app typt."""
    m = mainframe_map()
    script = m / "overig" / "scripts" / "mainframe_app.py" if m else None
    if not script or not script.exists():
        return
    aan = lees_staat().get("vanzelf") != "nee"
    code, uit = stil(python_cmd() + [str(script), "vanzelf", "aan" if aan else "uit"], timeout=120, cwd=m)
    if code == 0:
        log("Jarvis start voortaan vanzelf als je je computer aanzet." if aan
            else "Jarvis start niet vanzelf; na een herstart start je hem met /app in Claude Code.")
    else:
        log("Vanzelf starten instellen lukte niet; dat kan later in de app bij Instellingen.")


# ---------------------------------------------------------------------------
# Stap 8: Jarvis (stem en sleutel)
# ---------------------------------------------------------------------------

def _gemini_sleutel() -> str:
    m = mainframe_map()
    if not m:
        return ""
    return lees_env(m / ".env", "GEMINI_API_KEY") or lees_env(m / ".mainframe" / "app" / ".env.local", "GEMINI_API_KEY")


def sleutel_werkt(sleutel: str) -> bool:
    try:
        req = urllib.request.Request(
            "https://generativelanguage.googleapis.com/v1beta/models?pageSize=1",
            headers={"x-goog-api-key": sleutel, "User-Agent": "Mainframe-installer"})
        with urllib.request.urlopen(req, timeout=15) as r:
            return r.status == 200
    except Exception:
        return False


def check_jarvis() -> dict:
    if not check_app()["status"] == "klaar":
        return wacht("Eerst de app starten.")
    sleutel = _gemini_sleutel()
    geregeld = "GEMINI_API_KEY" in (lees_staat().get("sleutels_geregeld") or [])
    if not sleutel:
        return open_("Jarvis heeft nog geen stem.", sleutel=False, sleutel_geregeld=False)
    status = app_get("/__mainframe/voice/status") or {}
    extra = {"karakter": status.get("karakter"), "stem": (status.get("gemini") or {}).get("voice"),
             "sleutel": True, "sleutel_geregeld": geregeld}
    if not lees_staat().get("jarvis"):
        return open_("Kies nog hoe Jarvis klinkt.", **extra)
    return klaar("Jarvis heeft een stem.", **extra)


def doe_jarvis(invoer: dict, log: Log) -> dict:
    m = mainframe_map()
    sleutel = str(invoer.get("sleutel", "")).strip()
    if sleutel:
        if not re.fullmatch(r"(AQ\.[A-Za-z0-9_.\-]{20,200}|[A-Za-z0-9_\-]{30,60})", sleutel):
            raise Fout("Dat lijkt geen Gemini-sleutel.", "Kopieer de hele sleutel uit Google AI Studio. Hij begint met AQ. of AIza.")
        log("Sleutel testen bij Google...")
        if not sleutel_werkt(sleutel):
            raise Fout("Google accepteert deze sleutel niet.", "Maak in AI Studio een nieuwe sleutel en plak hem opnieuw.")
        zet_env(m / ".env", "GEMINI_API_KEY", sleutel)
        zet_env(m / ".mainframe" / "app" / ".env.local", "GEMINI_API_KEY", sleutel)
        log("Sleutel werkt en staat veilig op deze computer.")
    elif not _gemini_sleutel():
        raise Fout("Plak eerst je Gemini-sleutel.")
    naam = lees_staat().get("voornaam")
    if naam:
        try:
            app_post("/__operator/profile", {"name": naam, "aanspreek": lees_staat().get("aanspreek", "")})
        except Exception:
            log("Je naam kon nog niet naar de app.")
    patch = {}
    if invoer.get("karakter") in ("sparring", "klassiek", "coach"):
        patch["karakter"] = invoer["karakter"]
    if invoer.get("stem") in ("Kore", "Aoede", "Leda", "Charon", "Puck", "Orus"):
        patch["geminiVoice"] = invoer["stem"]
    if patch:
        app_post("/__mainframe/voice/settings", patch)
        zet_staat(jarvis=patch)
        log("Stem en karakter bewaard.")
    return {}


WELKOM_WAV = WERKMAP / "welkom.wav"
GROETEN = {
    "sparring": "{groet} {naam}. Daar ben ik. Ik ben Jarvis, en vanaf nu denk ik met je mee. Zullen we je Mainframe samen klaarzetten?",
    "klassiek": "{groet} {naam}. Ik ben Jarvis. Alles staat klaar. Zullen we je Mainframe samen inrichten?",
    "coach": "{groet} {naam}! Daar ben ik, Jarvis. Wat gaaf dat we beginnen. Zullen we je Mainframe samen klaarzetten?",
}


def maak_welkom(log: Log) -> bool:
    """Jarvis spreekt de begroeting voor de onthulling in, met zijn eigen stem."""
    import base64
    import wave
    sleutel = _gemini_sleutel()
    if not sleutel:
        return False
    status = app_get("/__mainframe/voice/status") or {}
    stem = (status.get("gemini") or {}).get("voice") or "Kore"
    karakter = status.get("karakter") or "sparring"
    uur = time.localtime().tm_hour
    groet = "Goedenacht" if uur < 6 else "Goedemorgen" if uur < 12 else "Goedemiddag" if uur < 18 else "Goedenavond"
    tekst = GROETEN.get(karakter, GROETEN["sparring"]).format(groet=groet, naam=lees_staat().get("voornaam", ""))
    body = json.dumps({
        "contents": [{"parts": [{"text": "Zeg warm en rustig, in het Nederlands: " + tekst}]}],
        "generationConfig": {"responseModalities": ["AUDIO"],
                             "speechConfig": {"voiceConfig": {"prebuiltVoiceConfig": {"voiceName": stem}}}},
    }).encode()
    for model in ("gemini-3.8-flash-tts", "gemini-2.5-flash-preview-tts"):
        try:
            req = urllib.request.Request(
                f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
                data=body, method="POST", headers={"x-goog-api-key": sleutel, "Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=40) as r:
                data = json.loads(r.read().decode())
            deel = data["candidates"][0]["content"]["parts"][0]["inlineData"]
            ruw = base64.b64decode(deel["data"])
            soort = str(deel.get("mimeType", "")).lower()
            WERKMAP.mkdir(parents=True, exist_ok=True)
            if ruw[:4] == b"RIFF":
                WELKOM_WAV.write_bytes(ruw)
            else:  # kale PCM: 16 bit, mono, de rate staat in het mime-type
                m = re.search(r"rate=(\d+)", soort)
                with wave.open(str(WELKOM_WAV), "wb") as w:
                    w.setnchannels(1)
                    w.setsampwidth(2)
                    w.setframerate(int(m.group(1)) if m else 24000)
                    w.writeframes(ruw)
            log("Jarvis heeft zijn begroeting ingesproken.")
            return True
        except Exception:
            continue
    return False


# ---------------------------------------------------------------------------
# Stap 9: mail en agenda
# ---------------------------------------------------------------------------

def aanbieder(email: str) -> str:
    domein = email.split("@")[-1].lower()
    if domein in ("gmail.com", "googlemail.com"):
        return "google"
    if domein in ("outlook.com", "hotmail.com", "live.com", "live.nl", "hotmail.nl", "msn.com"):
        return "outlook"
    mx = mx_van(domein)
    if "outlook.com" in mx or "microsoft" in mx:
        return "outlook"
    if "google" in mx:
        return "google"
    return "anders"


def check_mail() -> dict:
    if check_app()["status"] != "klaar":
        return wacht("Eerst de app starten.")
    s = lees_staat()
    verbindingen = app_get("/__operator/connections") or {}
    accounts = {a.get("id"): a for a in verbindingen.get("accounts", [])}
    for p in ("outlook", "google"):
        a = accounts.get(p) or {}
        if a.get("connected"):
            return klaar(f"{'Outlook' if p == 'outlook' else 'Google'} gekoppeld"
                         + (f" ({a.get('email')})." if a.get("email") else "."), aanbieder=p)
    mailboxen = verbindingen.get("mailboxen") or []
    if mailboxen:
        return klaar(f"Mail gekoppeld ({mailboxen[0].get('email', '')}).", aanbieder="anders")
    if s.get("mail_later"):
        return overgeslagen("Later doen. Open de wizard opnieuw als je zover bent.",
                            aanbieder=s.get("aanbieder", ""))
    email = s.get("email", "")
    p = s.get("aanbieder") or (aanbieder(email) if email else "anders")
    if p != s.get("aanbieder"):
        zet_staat(aanbieder=p)
    ingesteld = bool((accounts.get(p) or {}).get("configured"))
    redirect = (accounts.get(p) or {}).get("redirectUri") or \
        f"http://localhost:{APP_POORT}/__operator/connections/callback/{p}"
    # Inloggen moet op hetzelfde adres als het terugkeeradres (localhost), anders
    # herkent de app de inlog niet. ?koppel= laat de app het inloggen zelf starten.
    oorsprong = re.match(r"https?://[^/]+", redirect)
    koppel_url = (oorsprong.group(0) if oorsprong else app_draait() or "") + f"/inbox?connections=1&koppel={p}"
    return open_("Nog niet gekoppeld.", aanbieder=p, ingesteld=ingesteld, redirect=redirect,
                 app=app_draait(), koppel_url=koppel_url)


def doe_mail(invoer: dict, log: Log) -> dict:
    actie = invoer.get("actie")
    if actie == "later":
        zet_staat(mail_later=True)
        return {}
    if actie == "aanbieder":
        zet_staat(aanbieder=invoer.get("aanbieder"), mail_later=False)
        return {}
    p = invoer.get("aanbieder") or lees_staat().get("aanbieder")
    client_id = str(invoer.get("client_id", "")).strip()
    geheim = str(invoer.get("client_secret", "")).strip()
    if p == "outlook":
        if not re.fullmatch(r"[0-9a-fA-F-]{36}", client_id):
            raise Fout("Dat lijkt geen Application (client) ID.",
                       "Kopieer de code van de overzichtspagina van je app in Microsoft. Hij heeft 36 tekens.")
    elif p == "google":
        if not client_id.endswith(".apps.googleusercontent.com") or not geheim:
            raise Fout("Vul de Client ID en het Client secret van Google in.",
                       "Allebei staan ze in het venster dat Google laat zien na het aanmaken.")
    else:
        raise Fout("Kies eerst Outlook of Google.")
    app_post("/__operator/connections/configure", {"provider": p, "clientId": client_id, "clientSecret": geheim})
    zet_staat(mail_later=False)
    log("Koppeling ingesteld. Nu nog inloggen in de app.")
    return {}


# ---------------------------------------------------------------------------
# Stap 10: altijd bereikbaar en je telefoon
# ---------------------------------------------------------------------------

def _tailscale() -> Optional[str]:
    for p in (vind("tailscale"), "/Applications/Tailscale.app/Contents/MacOS/Tailscale"):
        if p and Path(p).exists():
            return p
    return None


def tailscale_status() -> dict:
    t = _tailscale()
    if not t:
        return {"geinstalleerd": False, "ingelogd": False}
    code, uit = stil([t, "status", "--json"], timeout=15)
    try:
        d = json.loads(uit[uit.index("{"):])
    except ValueError:
        return {"geinstalleerd": True, "ingelogd": False}
    zelf = d.get("Self") or {}
    return {"geinstalleerd": True, "ingelogd": d.get("BackendState") == "Running",
            "naam": (zelf.get("DNSName") or "").rstrip(".")}


def heeft_telefoonpagina(adres: Optional[str]) -> bool:
    """Kent de geinstalleerde app de pagina voor de Jarvis-app (/__telefoon/android)?"""
    if not adres:
        return False
    try:
        verzoek = urllib.request.Request(adres.rstrip("/") + "/__telefoon/android", method="HEAD")
        with urllib.request.urlopen(verzoek, timeout=8) as antwoord:
            return antwoord.status == 200 and "text/html" in (antwoord.headers.get("Content-Type") or "")
    except (OSError, ValueError):
        return False


def check_telefoon() -> dict:
    s = lees_staat()
    if check_app()["status"] != "klaar":
        return wacht("Eerst de app starten.")
    ts = tailscale_status()
    m = mainframe_map()
    altijd = False
    if m:
        code, uit = stil(python_cmd() + [str(m / "overig" / "scripts" / "mainframe_app.py"), "status"], timeout=20, cwd=m)
        altijd = "altijd" in uit.lower() and ("aan" in uit.lower() or "bereikbaar" in uit.lower()) and "uit" not in uit.lower().split("altijd")[-1][:20]
    if ts.get("ingelogd") and s.get("telefoon_klaar"):
        return klaar("Je telefoon kan bij Jarvis.", tailscale=ts, vaste_computer=s.get("vaste_computer"))
    if s.get("telefoon_later"):
        return overgeslagen("Later doen.", tailscale=ts, vaste_computer=s.get("vaste_computer"))
    return open_("Nog niet ingesteld.", tailscale=ts, vaste_computer=s.get("vaste_computer"), altijd=altijd)


def doe_telefoon(invoer: dict, log: Log) -> dict:
    actie = invoer.get("actie")
    if actie == "later":
        zet_staat(telefoon_later=True)
        return {}
    if actie == "tailscale":
        if _tailscale():
            log("Tailscale staat erop.")
        else:
            s = systeem()
            if s == "windows":
                draai(["winget", "install", "--id", "Tailscale.Tailscale", "-e", "--silent",
                       "--accept-package-agreements", "--accept-source-agreements"], log, timeout=900)
            elif s == "mac":
                pkg = download("https://pkgs.tailscale.com/stable/Tailscale-latest-macos.pkg",
                               WERKMAP / "downloads" / "Tailscale.pkg", log, "Tailscale")
                log("Het installatievenster van Tailscale gaat open. Klik door tot Installeer en vul je Mac-wachtwoord in.")
                stil(["open", str(pkg)])
                einde = time.time() + 15 * 60
                while time.time() < einde and not _tailscale():
                    time.sleep(5)
            else:
                raise Fout("Installeer Tailscale via tailscale.com/download/linux.", "Klik daarna opnieuw.")
            if not _tailscale():
                raise Fout("Tailscale staat er nog niet op.", "Rond de installatie af en klik opnieuw.")
        if systeem() == "mac":
            stil(["open", "-a", "Tailscale"])
        t = _tailscale()
        if not tailscale_status().get("ingelogd"):
            log("Log in bij Tailscale. Gebruik hetzelfde account als straks op je telefoon.")
            if systeem() != "mac":
                stil([t, "up"], timeout=5)
            einde = time.time() + 15 * 60
            while time.time() < einde and not tailscale_status().get("ingelogd"):
                time.sleep(4)
            if not tailscale_status().get("ingelogd"):
                raise Fout("Je bent nog niet ingelogd bij Tailscale.", "Log in via het Tailscale-icoon en klik opnieuw.")
        log("Tailscale is aan.")
        return {}
    if actie == "koppel":
        m = mainframe_map()
        script = m / "overig" / "scripts" / "mainframe_app.py"
        # Altijd bereikbaar: de app start mee met deze computer en is binnen je
        # eigen Tailscale-netwerk te openen. Ook op een laptop nodig voor de telefoon.
        log("Altijd bereikbaar aanzetten: de app start voortaan vanzelf met deze computer.")
        code, _ = draai(python_cmd() + [str(script), "altijd", "aan"], log, cwd=m, timeout=300)
        if code != 0:
            raise Fout("Altijd bereikbaar lukte niet.", "Kijk of Tailscale aan staat en klik opnieuw.")
        code, uit = draai(python_cmd() + [str(script), "start", "--elders", "--geen-browser"], log, cwd=m, timeout=600)
        zet_onderdelen({"telefoon": True}, log)
        link = (re.findall(r"MAINFRAME_KOPPELLINK=(\S+)", uit) or [None])[-1]
        adres = (re.findall(r"MAINFRAME_URL=(\S+)", uit) or [None])[-1]
        if not link:
            raise Fout("Ik kreeg geen koppellink.", "Kijk of Tailscale aan staat en klik opnieuw.")
        # Sinds 14 oktober 2026 heeft de app een telefoonpagina: op Android de Jarvis-app
        # (download en koppelen), op een iPhone gewoon de browser koppelen. Een oudere app
        # kent die pagina niet; dan blijft het de gewone koppellink.
        androidlink = link.replace("/__telefoon/koppelen#", "/__telefoon/android#")
        return {"koppellink": androidlink if heeft_telefoonpagina(adres) else link, "adres": adres}
    if actie == "gelukt":
        zet_staat(telefoon_klaar=True, telefoon_later=False)
        return {}
    return {}


# ---------------------------------------------------------------------------
# Stap 11: de eindcontrole
# ---------------------------------------------------------------------------

def check_klaar() -> dict:
    s = lees_staat()
    if s.get("eindcontrole", {}).get("ok"):
        return klaar("Alles gecontroleerd.", controles=s["eindcontrole"]["controles"])
    return open_("Nog niet gecontroleerd.")


def doe_klaar(invoer: dict, log: Log) -> dict:
    m = mainframe_map()
    controles = []

    def meet(naam: str, ok: bool, uitleg: str = "") -> None:
        controles.append({"naam": naam, "ok": bool(ok), "uitleg": uitleg})
        log(("Goed: " if ok else "Let op: ") + naam + (f" ({uitleg})" if uitleg and not ok else ""))

    meet("Claude Code ingelogd", bool(claude_ingelogd()))
    meet("Mainframe-map compleet", bool(m and (m / "VERSIES.md").exists() and (m / ".claude" / "settings.json").exists()))
    if m:
        test = m / "overig" / "scripts" / "setup" / "self_test.py"
        if test.exists():
            code, uit = draai(python_cmd() + [str(test)], None, cwd=m, timeout=180)
            meet("Zelftest van je Mainframe", code == 0, "een onderdeel gaf een waarschuwing" if code else "")
        veilig = m / "overig" / "scripts" / "setup" / "security_check.py"
        if veilig.exists():
            code, uit = draai(python_cmd() + [str(veilig)], None, cwd=m, timeout=300)
            echt = []
            try:
                rapport = json.loads(uit[uit.index("{"):])
                lijst = rapport.get("findings") or rapport.get("bevindingen") or []
                # Oudere versies van de check kijken ook in de pakketten van de app;
                # die treffers zijn geen sleutels van jou.
                echt = [f for f in lijst if f.get("level") == "fail"
                        and "node_modules" not in str(f.get("path") or "")]
                ok_veilig = not echt
            except (ValueError, AttributeError):
                ok_veilig = code == 0
            meet("Veiligheidscheck (geen sleutels op de verkeerde plek)", ok_veilig,
                 "; ".join(str(f.get("message")) for f in echt)[:120] if echt else "")
    meet("De app draait", bool(app_draait()))
    meet("Jarvis heeft een stem", bool(_gemini_sleutel()))
    mail = check_mail()
    meet("Mail en agenda gekoppeld", mail["status"] == "klaar", "nog te doen" if mail["status"] != "klaar" else "")
    if claude_ingelogd() and m:
        log("Claude een proefvraag stellen in je Mainframe...")
        code, uit = draai([_claude(), "-p", "Antwoord met precies dit woord: klaar", "--model", "sonnet"],
                          None, cwd=m, timeout=240)
        meet("Claude antwoordt vanuit je Mainframe", code == 0 and "klaar" in uit.lower())
    kern = [c for c in controles if c["naam"] in ("Claude Code ingelogd", "Mainframe-map compleet", "De app draait",
                                                     "Jarvis heeft een stem")]
    ok = all(c["ok"] for c in kern)
    zet_staat(eindcontrole={"ok": ok, "controles": controles, "tijd": time.time()})
    if ok:
        maak_welkom(log)
    if not ok:
        raise Fout("Niet alles is groen.", "Kijk welke regel rood is en open die stap opnieuw.")
    return {"controles": controles, "jarvis": (app_draait() or "") + "/jarvis"}


# ---------------------------------------------------------------------------
# De volgorde
# ---------------------------------------------------------------------------

STAPPEN = [
    {"id": "welkom", "titel": "Welkom", "check": check_welkom, "doe": doe_welkom},
    {"id": "basis", "titel": "De basis", "check": check_basis, "doe": doe_basis},
    {"id": "claude", "titel": "Claude", "check": check_claude, "doe": doe_claude},
    {"id": "orca", "titel": "Orca", "check": check_orca, "doe": doe_orca},
    {"id": "vscode", "titel": "VS Code", "check": check_vscode, "doe": doe_vscode},
    {"id": "mainframe", "titel": "Je Mainframe", "check": check_mainframe, "doe": doe_mainframe},
    {"id": "overjou", "titel": "Over jou", "check": check_overjou, "doe": doe_overjou},
    {"id": "app", "titel": "De app", "check": check_app, "doe": doe_app},
    {"id": "jarvis", "titel": "Jarvis' stem", "check": check_jarvis, "doe": doe_jarvis},
    {"id": "mail", "titel": "Mail en agenda", "check": check_mail, "doe": doe_mail},
    {"id": "telefoon", "titel": "Je telefoon", "check": check_telefoon, "doe": doe_telefoon},
    {"id": "klaar", "titel": "Jarvis ontmoeten", "check": check_klaar, "doe": doe_klaar},
]
PER_ID: Dict[str, dict] = {s["id"]: s for s in STAPPEN}
