"""Je bestaande Mainframe ophalen op een tweede computer (Bart, 11 november 2026).

Bart: "dat hun huidige Mainframe, waar al hun bestanden in staan en al hun kennis in staan, wordt
binnengehaald op hun eigen computer", en het installeren van de software moet "extreem makkelijk".
Zijn keuzes: een keuze op het startscherm van de installer, pas zichtbaar na week 1 van de groep;
de computers blijven daarna vanzelf gelijk; online zetten gaat vanzelf aan zodra er een tweede
computer is.

Hoe het loopt:
1. De GitHub-tool (gh) neerzetten als hij er niet is, van de officiele downloadpagina, met controle.
2. Inloggen met een code van acht tekens op github.com/login/device (dezelfde route als de app).
3. De back-up zoeken: prive-plekken op GitHub waar een Mainframe 2.0 in staat (CLAUDE.md plus
   .mainframe/). Plekken met de naam mijn-mainframe eerst.
4. Binnenhalen met git clone in de gekozen map. Daarna zet de gewone stap Je Mainframe er alleen
   bij wat ontbreekt (de licentie van deze computer, de motorbestanden die niet in git staan).
5. Deze computer aanmelden: .mainframe/deze-computer.json (alleen hier) en een kaartje in
   .mainframe/computers/ (gaat mee naar GitHub). Aan dat kaartje ziet de andere computer dat er
   een tweede bij is; dan gaat daar het gelijkhouden ook aan (twee-computers.ts in de app).

Alleen standaard-Python, net als de rest van de wizard.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import socket
import subprocess
import tarfile
import tempfile
import threading
import time
import uuid
import zipfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, List, Optional

from kern import THUIS, WERKMAP, Fout, Log, download, draai, http_json, stil, systeem, vind

DEVICE_URL = "https://github.com/login/device"
REPO_NAAM = "mijn-mainframe"
# Bart: "pas vanaf week 2". Vast schema voor alle groepen: week 1 de startdag om 11:00, week 2 de
# eerste vrijdag daarna op hetzelfde uur (overig/scripts/cohort_dripschema.py, v_sloten_regels.ts).
VRIJDAG = 4


# ---------------------------------------------------------------------------
# Mag de keuze op het startscherm staan?
# ---------------------------------------------------------------------------

def ophalen_mag(sloten: Optional[dict], nu: Optional[datetime] = None) -> bool:
    """Pas vanaf week 2 van de groep. Wie niet in een groep met weekritme zit (oud-lid, OS-koper,
    VIP, of de status kon niet opgehaald worden), ziet de keuze altijd. Voor een test (Bart met zijn
    testlid, voor de groep zover is): MF_OPHALEN=altijd bij het starten van de installer."""
    if os.environ.get("MF_OPHALEN") == "altijd":
        return True
    if not sloten or not sloten.get("met_sloten"):
        return True
    moment = week_2(str(sloten.get("start") or ""))
    if moment is None:
        return True
    return (nu or datetime.now(timezone.utc)) >= moment


def _amsterdam_offset(d: datetime) -> int:
    """Uren voor op UTC in Nederland: 2 in de zomertijd (laatste zondag maart tot laatste zondag
    oktober), anders 1. Zelf gerekend: zoneinfo mist op Windows vaak zijn tijdzonebestanden."""
    def laatste_zondag(maand: int) -> datetime:
        d0 = datetime(d.year, maand, 31)
        return d0 - timedelta(days=(d0.weekday() + 1) % 7)
    return 2 if laatste_zondag(3) <= d.replace(tzinfo=None) < laatste_zondag(10) else 1


def week_2(start: str) -> Optional[datetime]:
    """Het begin van week 2: de eerste vrijdag na de startdag om 11:00 Nederlandse tijd (in UTC)."""
    try:
        dag = datetime.fromisoformat(start[:10])
    except ValueError:
        return None
    vrijdag = dag + timedelta(days=(VRIJDAG - dag.weekday()) % 7 or 7)
    elf_uur = vrijdag.replace(hour=11)
    return (elf_uur - timedelta(hours=_amsterdam_offset(elf_uur))).replace(tzinfo=timezone.utc)


# ---------------------------------------------------------------------------
# De GitHub-tool
# ---------------------------------------------------------------------------

def _exe(naam: str) -> str:
    return naam + ".exe" if systeem() == "windows" else naam


def eigen_bin() -> Path:
    return THUIS / ".local" / "bin"


def vind_gh() -> Optional[str]:
    gevonden = vind("gh")
    if gevonden:
        return gevonden
    for p in (eigen_bin() / _exe("gh"), Path("/opt/homebrew/bin/gh"), Path("/usr/local/bin/gh"),
              Path("C:/Program Files/GitHub CLI/gh.exe"),
              THUIS / "AppData" / "Local" / "Programs" / "GitHub CLI" / "gh.exe"):
        if p.exists():
            return str(p)
    return None


def asset_voor(versie: str, sys_: Optional[str] = None, machine: Optional[str] = None) -> Optional[str]:
    """Hetzelfde downloadbestand als assetVoor in de app (verbinden/github.ts)."""
    import platform
    v = versie.lstrip("v")
    m = (machine or platform.machine()).lower()
    a = "arm64" if m in ("arm64", "aarch64") else "amd64" if m in ("x86_64", "amd64") else None
    if not a:
        return None
    s = sys_ or systeem()
    if s == "mac":
        return f"gh_{v}_macOS_{a}.zip"
    if s == "windows":
        return f"gh_{v}_windows_{a}.zip"
    if s == "linux":
        return f"gh_{v}_linux_{a}.tar.gz"
    return None


def controle_som(checksums: str, bestand: str) -> Optional[str]:
    for regel in checksums.splitlines():
        delen = regel.strip().split()
        if len(delen) == 2 and delen[1] == bestand and re.fullmatch(r"[0-9a-fA-F]{64}", delen[0]):
            return delen[0].lower()
    return None


def installeer_gh(log: Log) -> str:
    """Zet gh in ~/.local/bin, van de officiele releasepagina van gh, met controle van de checksum."""
    release = http_json("https://api.github.com/repos/cli/cli/releases/latest",
                        headers={"Accept": "application/vnd.github+json"}, timeout=30)
    naam = asset_voor(str(release.get("tag_name") or ""))
    assets = {a.get("name"): a.get("browser_download_url") for a in release.get("assets") or []}
    sommen_url = next((u for n, u in assets.items() if str(n).endswith("_checksums.txt")), None)
    if not naam or naam not in assets or not sommen_url:
        raise Fout("Voor deze computer kon ik de GitHub-tool niet vinden.",
                   "Druk op Opnieuw proberen. Blijft dit staan, stuur dan de details naar Bart.")
    tmp = Path(tempfile.mkdtemp(prefix="mainframe-gh-"))
    try:
        sommen = download(sommen_url, tmp / "sommen.txt", None, "controlebestand").read_text()
        archief = download(assets[naam], tmp / naam, log, "de GitHub-tool")
        som = controle_som(sommen, naam)
        if not som or hashlib.sha256(archief.read_bytes()).hexdigest() != som:
            raise Fout("De download van de GitHub-tool klopte niet.", "Druk op Opnieuw proberen.")
        uit = tmp / "uit"
        uit.mkdir()
        if naam.endswith(".zip"):
            with zipfile.ZipFile(archief) as z:
                for lid in z.namelist():
                    if ".." not in Path(lid).parts:
                        z.extract(lid, uit)
        else:
            with tarfile.open(archief) as t:
                t.extractall(uit, members=[m for m in t.getmembers() if ".." not in Path(m.name).parts])
        gh = next((p for p in uit.rglob(_exe("gh")) if p.is_file() and p.parent.name == "bin"), None)
        if not gh:
            raise Fout("Uitpakken van de GitHub-tool lukte niet.", "Druk op Opnieuw proberen.")
        doel = eigen_bin() / _exe("gh")
        doel.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(gh, doel)
        if systeem() != "windows":
            doel.chmod(0o755)
        log("De GitHub-tool staat erop.")
        return str(doel)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def gh_omgeving() -> Dict[str, str]:
    env = dict(os.environ)
    env.update({"GH_PROMPT_DISABLED": "1", "GIT_TERMINAL_PROMPT": "0", "GH_NO_UPDATE_NOTIFIER": "1"})
    return env


def ingelogd_als(gh: str) -> Optional[str]:
    code, uit = stil([gh, "auth", "status", "--hostname", "github.com"], timeout=20, env=gh_omgeving())
    if code != 0:
        return None
    m = re.search(r"Logged in to github\.com account (\S+)", uit) or re.search(r"Logged in to github\.com as (\S+)", uit)
    return m.group(1).strip("()") if m else "?"


def code_uit(tekst: str) -> Optional[str]:
    m = re.search(r"one-time code:\s*([A-Z0-9]{4}-[A-Z0-9]{4})", tekst, re.I)
    return m.group(1).upper() if m else None


class Inloggen:
    """`gh auth login --web` op de achtergrond. De code komt op een kaart in de wizard."""

    def __init__(self, gh: str) -> None:
        self.gh = gh
        self.tekst = ""
        self.code: Optional[str] = None
        vlaggen = getattr(subprocess, "CREATE_NO_WINDOW", 0) if systeem() == "windows" else 0
        self.proces = subprocess.Popen(
            [gh, "auth", "login", "--web", "--hostname", "github.com", "--git-protocol", "https", "--skip-ssh-key"],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=gh_omgeving(),
            creationflags=vlaggen)
        threading.Thread(target=self._lees, daemon=True).start()
        try:  # oudere gh vraagt om Enter voor de browser
            self.proces.stdin.write(b"\n")  # type: ignore[union-attr]
            self.proces.stdin.flush()  # type: ignore[union-attr]
        except OSError:
            pass

    def _lees(self) -> None:
        for ruw in iter(self.proces.stdout.readline, b""):  # type: ignore[union-attr]
            self.tekst += ruw.decode("utf-8", "replace")
            self.code = self.code or code_uit(self.tekst)

    def wacht_op_code(self, seconden: float = 25) -> Optional[str]:
        einde = time.time() + seconden
        while time.time() < einde and not self.code and self.proces.poll() is None:
            time.sleep(0.3)
        return self.code

    def klaar(self) -> bool:
        return self.proces.poll() is not None

    def stop(self) -> None:
        if self.proces.poll() is None:
            self.proces.terminate()


def zet_git_op_gh(gh: str) -> None:
    """git logt daarna via gh in bij GitHub: clone, pull en push zonder wachtwoord."""
    stil([gh, "auth", "setup-git", "--hostname", "github.com"], timeout=20, env=gh_omgeving())


# ---------------------------------------------------------------------------
# De back-up zoeken
# ---------------------------------------------------------------------------

def _heeft(gh: str, repo: str, pad: str) -> bool:
    code, _ = stil([gh, "api", f"repos/{repo}/contents/{pad}", "--silent"], timeout=20, env=gh_omgeving())
    return code == 0


def is_mainframe_repo(gh: str, repo: str) -> bool:
    return _heeft(gh, repo, "CLAUDE.md") and _heeft(gh, repo, ".mainframe")


def zoek_backups(gh: str, log: Optional[Log] = None, maximaal: int = 15) -> List[Dict[str, str]]:
    """Plekken op GitHub met een Mainframe 2.0 erin. mijn-mainframe eerst, daarna de nieuwste."""
    code, uit = stil([gh, "repo", "list", "--limit", "200", "--json", "nameWithOwner,url,updatedAt,name"],
                     timeout=60, env=gh_omgeving())
    if code != 0:
        raise Fout("Ik kon je plekken op GitHub niet bekijken.", "Kijk of je internet aan staat en druk op Opnieuw proberen.")
    try:
        lijst = json.loads(uit or "[]")
    except ValueError:
        lijst = []
    lijst.sort(key=lambda r: str(r.get("updatedAt") or ""), reverse=True)
    lijst.sort(key=lambda r: 0 if str(r.get("name") or "").startswith(REPO_NAAM) else 1)
    gevonden: List[Dict[str, str]] = []
    for r in lijst[:maximaal]:
        repo = str(r.get("nameWithOwner") or "")
        if repo and is_mainframe_repo(gh, repo):
            gevonden.append({"repo": repo, "url": str(r.get("url") or f"https://github.com/{repo}"),
                             "bijgewerkt": str(r.get("updatedAt") or "")})
    if log:
        log(f"Op GitHub: {len(gevonden)} Mainframe-back-up(s) gevonden.")
    return gevonden


def datum_tekst(iso: str) -> str:
    maanden = ("januari", "februari", "maart", "april", "mei", "juni", "juli", "augustus", "september",
               "oktober", "november", "december")
    try:
        d = datetime.fromisoformat(iso.replace("Z", "+00:00")).astimezone()
        return f"{d.day} {maanden[d.month - 1]}"
    except ValueError:
        return ""


# ---------------------------------------------------------------------------
# Binnenhalen en aanmelden
# ---------------------------------------------------------------------------

def kloon(url: str, map_: Path, log: Log) -> None:
    git = vind("git")
    if not git:
        raise Fout("Git staat er nog niet op.", "Druk op Opnieuw proberen.")
    if not map_uit_lege(map_):
        raise Fout(f"In {map_} staan al bestanden.", "Kies bij Waar komt je Mainframe een lege of nieuwe map.")
    map_.parent.mkdir(parents=True, exist_ok=True)
    log("Je Mainframe ophalen van GitHub...")
    code, uit = draai([git, "clone", "--quiet", url + ".git", str(map_)], None, timeout=3600,
                      env={"GIT_TERMINAL_PROMPT": "0"})
    if code != 0 or not (map_ / ".git").exists():
        regel = (uit or "").strip().splitlines()[-1:] or [""]
        log(f"git clone: {regel[0][:200]}")
        raise Fout("Het ophalen van je Mainframe lukte niet.",
                   "Kijk of je internet aan staat en druk op Opnieuw proberen. Blijft het misgaan, stuur dan de details naar Bart.")
    log("Je Mainframe is binnen.")


def map_uit_lege(map_: Path) -> bool:
    """Alleen een lege of nieuwe map; .DS_Store en .localized tellen niet."""
    if not map_.exists():
        return True
    rest = [x for x in map_.iterdir() if x.name not in (".DS_Store", ".localized")]
    if rest:
        return False
    for x in map_.iterdir():
        try:
            x.unlink()
        except OSError:
            pass
    return True


def deze_computer(map_: Path) -> Dict:
    try:
        return json.loads((map_ / ".mainframe" / "deze-computer.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def meld_aan(map_: Path, url: str, log: Log) -> Dict:
    """Deze computer als tweede computer: kaartje in git, eigen stand alleen hier. Daarna meteen
    online zetten, zodat de andere computer binnen een paar minuten ziet dat hij er niet alleen voor staat."""
    mf = map_ / ".mainframe"
    (mf / "computers").mkdir(parents=True, exist_ok=True)
    eigen = deze_computer(map_)
    cid = str(eigen.get("id") or uuid.uuid4().hex[:12])
    naam = socket.gethostname()[:60] or "computer"
    nu = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    eigen.update({"versie": 1, "id": cid, "naam": naam, "tweeComputers": True,
                  "opgehaaldVan": url, "sinds": eigen.get("sinds") or nu})
    (mf / "deze-computer.json").write_text(json.dumps(eigen, indent=2) + "\n", encoding="utf-8")
    kaart = {"versie": 1, "id": cid, "naam": naam, "systeem": systeem(), "sinds": eigen["sinds"]}
    kaart_pad = mf / "computers" / f"{cid}.json"
    kaart_pad.write_text(json.dumps(kaart, indent=2) + "\n", encoding="utf-8")
    git = vind("git")
    if git:
        rel = kaart_pad.relative_to(map_).as_posix()
        stil([git, "-C", str(map_), "add", "--", rel], timeout=30)
        wie = [] if stil([git, "config", "user.name"])[0] == 0 else ["-c", "user.name=Mainframe", "-c", "user.email=mainframe@lokaal"]
        stil([git, "-C", str(map_), *wie, "commit", "-q", "-m", f"Mainframe: computer {naam} erbij", "--", rel], timeout=60)
        code, _ = stil([git, "-C", str(map_), "push", "-q"], timeout=300, env={**os.environ, "GIT_TERMINAL_PROMPT": "0"})
        log("Je andere computer weet nu dat deze erbij is." if code == 0
            else "Je andere computer hoort straks vanzelf dat deze erbij is.")
    return eigen
